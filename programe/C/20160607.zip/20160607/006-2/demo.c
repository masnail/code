#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#define LEAP 366
#define NLEAP 365

/*
*
*����֮��Ĳ�ֵ
*
*/
int CountDay(int year, int month, int day)
{//1��1������ʱ�̵�ʱ��
	int sum = 0;
	int today[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	for (int i = 0; i < month - 1; i++)
	{
		sum += today[i];
	}

	if ((year % 4 == 0 && year % 100 != 0 || year % 400 == 0) && (month>2))
	{//ע����ŵ����ȼ�
		sum += 1;
	}
	sum += day;
	//printf("today is %d day\n", sum);
	return sum;
}
int ISLeapYear(int year)
{//is leap?
	if (year%4==0&&year%100!=0||year%400==0)
	{
		return 1;
	} 
	else
	{
		return 0;
	}
}
void TheDay(int fyear, int fmonth, int fday, int syear, int smonth, int sday)
{//�������絽����ʱ��Ĳ�ֵ
	int count = 0;//the day
	if (fyear == syear)
	{
		count = CountDay(syear, smonth, sday) - CountDay(fyear, fmonth, fday);
	}
	else{
		count = NLEAP + ISLeapYear(fyear) - CountDay(fyear, fmonth, fday) + CountDay(syear, smonth, sday);
	}

	//printf("****** %d%d%d---%d%d%d day is %d\n", fyear, fmonth, fday, syear, smonth, sday, count);
	for (int i = fyear + 1; i < syear; i++)
	{
		count += NLEAP + ISLeapYear(i);
	}


	printf("%d%d%d---%d%d%d day is %d\n", fyear, fmonth, fday, syear, smonth, sday, count);
}

int main()
{
	int fyear, fmonth, fday,syear,smonth,sday;
	char ch;//��������� �൱�ڿ���ʹ��
	while (printf("��ʼ������#��:"),scanf("%c", &ch) != EOF)
	{
		printf("input first:");
		scanf("%d%d%d", &fyear, &fmonth, &fday);

		printf("input second:");
		scanf("%d%d%d", &syear, &smonth, &sday);

		TheDay(fyear, fmonth, fday, syear, smonth, sday);

	}
	getchar();
	getchar();
	return 0;
}
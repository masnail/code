#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define M 103

int main()
{
	int n[M] = { 0 };

	int index = 0;

	for (int i = 0; i < M - 2; i++)
		n[i] = i % 50;
	n[100] = 50;
	n[101] = 51;
	n[102] = 53;

	for (int i = 0; i < M; i++)
	{
		index = 0;
		for (int j = 0; j < M; j++)
		{
			if (n[i] == n[j])
			{
				index++;
			}
		}
		if (index == 1)
		{
			printf("%d\n", n[i]);
		}

	}


	getchar();
	getchar();
	return 0;
}
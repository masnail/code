#include <iostream>
#include <string>

using namespace std;

void fun()
{
	double a = 1, b = 2,sum=0,index=0;
	while (index!=20)
	{
		sum += b / a;
		int temp = b;
		b = a + b;
		a = temp;
		index++;
	}
	cout << sum << endl;
}

int main()
{
	cout << "100-2-024" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
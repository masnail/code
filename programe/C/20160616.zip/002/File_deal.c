#include "head.h"



void list_word(wdlist head)
{
	wdlist p = head->next;
	while (p)
	{
		printf("%s:%d\n", p->name,p->cnt);
		p = p->next;
	}
	printf("\n");
}

/*
 *
 * �ļ�����  ��������������
 * ����
 * �ַ���
 * �����ĳ�ʼ������
 *
 */
void File_read(char FileReadname[], wdlist *head)
{
	FILE *fp;
	char word[MAX] = { 0 };

	if ((fp = fopen(FileReadname, "r")) != NULL)
	{
		/*fgets(word, MAX, fp);
		puts(word);*/
		while (fgets(word, MAX, fp))
		{//�������ֺ���
			(*head)->cnt += 1;
			word_div_func(head, word);
			count_chara(word);
			memset(word, 0, MAX);
		}
	}
	else{
		perror("���ļ�ʱ�����ļ�������\n");
		exit(-1);
	}
	fclose(fp);
}

/*
 *
 * ���ֵ���
 *
 */
void word_div_func(wdlist* head, char *word)
{
	int index = 0,chindex=0;
	char chw[CHMAX];
	memset(chw, 0, sizeof(CHMAX));
	
	while (*(word+index))
	{
		if (isalpha(*(word + index)) || isdigit(*(word + index)))
		{
			chw[chindex++] = *(word + index);
		}else{
			if (chindex!=0)
			{
				insert_wdlist(head, chw,chindex);
				chindex = 0;
				memset(chw,0,sizeof(CHMAX));
			}
		}
		index++;
	}
	if (chindex>0)
	{
		insert_wdlist(head, chw, chindex);
	}
}

/*
*
*  �������ӵ�������
*
*
*/
void insert_wdlist(wdlist* head, char *word,int length)
{
	wdlist p = (*head)->next,pre=(*head);

	wdlist q = (wdlist)malloc(sizeof(wd));
	memset(q, 0, sizeof(wd));
	memcpy(q->name, word,length);

	while (p)
	{
		if (strcmp(p->name ,q->name)==0)
		{
			p->cnt += 1;
			return;
		}
		pre = p;
		p = p->next;
	}
	q->next = pre->next;
	pre->next = q;
}

/*
*
* �ַ���ͳ��
*
*
*/
void count_chara(char *word)
{
	int index = 0;
	while (*(word + index))
	{
		if (isalpha(*(word + index)) || isdigit(*(word + index)))
		{
			characnt++;
		}
		index++;
	}
}

/*
*
* ��������
*
*
*/
int Get_col_count(wdlist head)
{
	return head->cnt;
}

/*
*
* �����ַ�����
*
*
*/
int Get_chara_count()
{
		return characnt;
}
/*
*
* ���ص�����
*
*
*/
int Get_word_count(wdlist head)
{
	int index=0;
	wdlist p = head->next;
	while (p)
	{
		index++;
		p = p->next;
	}
	return index;
}

/*
*
* ���ſ��ƺ���
*
*
*/
int compare(const void *q, const void *p)
{
	wdlist *qw = (wdlist*)q;
	wdlist *pw = (wdlist*)p;
	return (*pw)->cnt-(*qw)->cnt;
}

/*
*
* ��������
*
*
*/
void sort_word(wdlist* head)
{
	int cnt=Get_word_count(*head),index=0;
	
	wdlist *p = (wdlist *)malloc(sizeof(wd)* cnt);
	wdlist pw = (*head)->next;
	while (pw)
	{
		*(p+ index) = pw;
		index++;
		pw = pw->next;
	}
	
	qsort(p, cnt,sizeof(wdlist), compare);


	for (int i = 0; i < 10; i++)
	{
		printf("name:%s cnt:%d\n",p[i]->name, p[i]->cnt);
	}
}
#include <iostream>
#include <string>

using namespace std;

int GetStringLen(string s)
{
	int index = 0;
	while (s[index])
	{
		index++;
	}
	return index;
}

void fun(string s)
{
	int length = GetStringLen(s);
	string strtemp = "";
	bool choose = false;
	for (int i = 0; i != length; i++)
	{
		if (choose)
		{
				strtemp += s[i];
		}
		else
		{
			if (s[i] != '*')
			{
				choose = true;
				strtemp += s[i];
			}
			
		}
	}
	cout << strtemp << endl;
}

int main()
{
	cout << "100-1-094" << endl;
	cout << "input a string:" << endl;;
	string s;
	cin >> s;
	fun(s);
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <string>

using namespace std;

void fun(string s,char *t)
{
	int index = 0;
	while (s[index] != NULL&& index<s.length())
	{
		//cout << s[index] % 2 << endl;
		if (s[index] % 2 == 0 && index % 2 == 0)
		{
			//cout << s[index];
			*t = s[index];
			t++;
		}
		index++;
	}
	*t = '#';
}

int main()
{
	cout << "100-1-031" << endl;
	string s;
	char *t = new char;
	cin >> s;
	fun(s,t);
	
	while (*t!='#')
	{
		cout << *t;
		t++;
	}
	cin.get();
	cin.get();
	return 0;
}

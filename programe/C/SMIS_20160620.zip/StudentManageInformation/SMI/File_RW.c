#include "File_RW.h"

/*
 *
 *
 * �ļ��Ķ���д
 *
 */


char StuName[CHMAX] = { 0 }, UserName[CHMAX] = { 0 };


//ϵͳ��ʼ��
void Loading()
{
	FILE *fp;
	char word[CHMAX];

	memset(word, 0, CHMAX);
	int index = 0, cnt = 0, chindex=0;

	if ((fp = fopen(".\\info\\configure.txt", "r")) == NULL)
	{
		perror("\tError,read file is fail!\n\t");
		system("pause");
		exit(-1);
	}

	while (fgets(word, CHMAX, fp) != NULL)
	{
		while (NULL != *(word + index))
		{
			if (isalpha(*(word + index)) || isdigit(*(word + index)) || *(word + index) == '.' || *(word + index) == '\\' || *(word + index) == '_')
			{
				if (cnt==0){
					StuName[chindex++] = *(word + index);
				}
				else if (cnt==1){
					UserName[chindex++] = *(word + index);
				}
			}
			else{
				if (chindex != 0)
				{
					chindex = 0;
					cnt += 1;
				}
			}
			index++;
		}
		if (chindex>0)
		{
			UserName[chindex++] = *(word + index);
		}
		index = 0;
	}
	fclose(fp);
	
	if (cnt<1)
	{
		printf("\tthe loading is error!\n\t");
		system("pause");
		exit(-1);
	}
}

void File_System_Load()//��ʼ�����ص���Ϣ
{
	FILE *fp=NULL;
	FILE *fpw=NULL;

	if ((fp=fopen(".\\info\\Configure.txt","rb"))==NULL)
	{//�����ļ���ʼ��ʧ��
		if ((fpw = fopen(".\\info\\Configure.txt", "wb")) == NULL)
		{
			fflush;
			printf("\tthe file init is fail!\n\t");
			system("pause");
			exit(-1);
		}
		if (NULL != fpw)
		{
			fclose(fpw);
		}//fclose (fpw);
	}
	if (NULL != fp)
	{
		fclose(fp);
	}
	//fclose(fp);

	if ((fp = fopen(".\\info\\Usr_account.txt", "rb")) == NULL)
	{//�û��ļ���ʼ��ʧ��

		if ((fpw = fopen(".\\info\\Usr_account.txt", "wb")) == NULL)
		{
			fflush;
			printf("\tthe file init is fail!\n\t");
			system("pause");
			exit(-1);
		}
		if (NULL != fpw)
		{
			fclose(fpw);
		}//fclose(fpw);
	}
	if (NULL != fp)
	{
		fclose(fp);
	}//fclose(fp);

	if ((fp = fopen(".\\info\\Usr_infor.txt", "rb")) == NULL)
	{//ѧ���ļ���ʼ��ʧ��
		if ((fpw = fopen(".\\info\\Usr_infor.txt", "wb")) == NULL)
		{
			fflush;
			printf("\tthe file init is fail!\n\t");
			system("pause");
			exit(-1);
		}
		if (NULL != fpw)
		{
			fclose(fpw);
		}//fclose(fpw);
	}
	if (NULL != fp)
	{
		fclose(fp);
	}//fclose(fp);

	if ((fp = fopen(".\\info\\Log.txt", "rb")) == NULL)
	{
		fpw = fopen(".\\info\\Log.txt", "wb");//��½��־
		fflush;
	}
	if (NULL != fp)
	{
		fclose(fp);
	}
	
	if (NULL != fpw)
	{
		fclose(fpw);
	}
	Loading();
}

void File_Loging()//����������ʼ������
{
	stuHead = (stulist)malloc(sizeof(stu));
	userHead = (userlist)malloc(sizeof(user));

	memset(stuHead, 0, sizeof(stu));
	memset(userHead, 0, sizeof(user));

	File_Read_User();
	File_Read_Student();
}

stulist Get_stu_Head()
{
	return stuHead;
}

userlist Get_user_Head()
{
	return userHead;
}

//ѧ������Ϣ
void File_Read_Student()//��ȡѧ���ļ��е���Ϣ
{
	stulist *head = &stuHead;
	FILE *fp;
	char stuArr[MAX];
	memset(stuArr, 0, MAX);

	if ((fp=fopen(StuName,"rb"))==NULL)
	{
		perror("\tError,read file is fail!\n\t");
		system("pause");
		exit(-1);
	}
	while (fgets(stuArr, MAX, fp) != NULL)//
	{    
		Create_Student_Node(&stuArr,head);
		(*head)->num += 1;
		
		memset(stuArr, 0, MAX);
	}//while-end
	fclose(fp);
}

void File_Write_Student( )//д��ѧ����Ϣ�ļ��е���Ϣ
{
	FILE *fp;
	stulist head = stuHead;
	stulist p = head->next;

	if ((fp = fopen(StuName, "w")) == NULL)
	{
		perror("\tError,write file is fail!\n\t");
		system("pause");
		exit(-1);
	}
	while (p)
	{
		fprintf(fp, STU_FORMAT_IN, STU_FORMAT_OUT);
		fflush;
		p = p->next;
	}
	fclose(fp);
}

void Create_Student_Node(char *word,stulist *head)//�齨ѧ����Ϣ���
{
	char chw[CHMAX];
	int index = 0, chindex = 0,cnt=1;
	stulist p = (*head)->next, pre = (*head), q = (stulist)malloc(sizeof(stu));

	memset(q, 0, sizeof(stu));
	memset(chw, 0, CHMAX);

	while (NULL!=*(word + index)&&cnt<=11&&chindex<CHMAX)
	{
		if (isalpha(*(word + index)) || isdigit(*(word + index)) || *(word + index) == '.')
		{
			chw[chindex++] = *(word + index);
		}
		else{
			if (chindex != 0)
			{
				//�ṹ�帳ֵ
				switch (cnt)
				{
					case 1:q->num = atoi(chw); break;
					case 2:memcpy(q->name,&chw,chindex); break;
					case 3:q->sex=chw[0]; break;
					case 4:memcpy(q->age, &chw, chindex); break;
					case 5:memcpy(q->phone, &chw, chindex);break;
					case 6:memcpy(q->birth, &chw, chindex); break;
					case 7:q->score[0] = atof(chw); break;
					case 8:q->score[1] = atof(chw); break;
					case 9:q->score[2] = atof(chw); break;
					case 10:q->score[3] = atof(chw); break;
					case 11:q->score[4] = atof(chw); break;
				}
				chindex = 0;
				cnt += 1;
				memset(chw, 0, CHMAX);
			}
		}
		index++;
	}
	if (chindex>0)
	{
		q->score[4] = atof(chw);
		//printf("%s\n", chw);
	}

	while (NULL != p)
	{
		if (q->num<p->num)
		{
			break;
		}
		pre = p;
		p = p->next;
	}
	q->next = pre->next;
	pre->next = q;

}

////////////////////////////////////////////////////////////////////////////


//�û�����Ϣ
void File_Read_User()//��ȡ�û��ļ��е���Ϣ
{
	FILE *fp;
	userlist *head = &userHead;
	char stuArr[MAX];
	memset(stuArr, 0, MAX);

	if ((fp = fopen(UserName, "rb")) == NULL)
	{
		perror("Error,read file is fail!\n");
		return;
	}
	while (fgets(stuArr, MAX, fp) != NULL)//
	{
		Create_User_Node(&stuArr, head);

		memset(stuArr, 0, MAX);
	}//while-end
	fclose(fp);
}

void File_Write_User()//д���û��ļ��е���Ϣ
{
	FILE *fp;
	userlist head = userHead;
	userlist p = head->next;

	if ((fp = fopen(UserName, "w")) == NULL)
	{
		perror("\tError,write file is fail!\n\t");
		system("pause");
		exit(-1);
	}
	while (p)
	{
		fprintf(fp, USR_FORMAT_IN, USR_FORMAT_OUT);
		fflush;
		p = p->next;
	}
	fclose(fp);
}

void Create_User_Node(char* word, userlist* head)//�齨�û���Ϣ���
{
	char chw[CHMAX];
	int index = 0, chindex = 0, cnt = 1;
	userlist p = (*head)->next, pre = (*head), q = (userlist)malloc(sizeof(user));

	memset(q, 0, sizeof(user));
	memset(chw, 0, CHMAX);

	while (NULL != *(word + index)&&cnt<=3&&chindex<CHMAX)
	{
		if (isalpha(*(word + index)) || isdigit(*(word + index)))
		{
			chw[chindex++] = *(word + index);
		}
		else{
			if (chindex != 0)
			{
				//�ṹ�帳ֵ
				switch (cnt)
				{
				case 1:memcpy(q->name, &chw, chindex); break;
				case 2:memcpy(q->pwd, &chw, chindex); break;
				case 3:q->power = chw[0]; break;
				}
				//printf("%s\n", chw);
				chindex = 0;
				cnt += 1;
				memset(chw, 0, CHMAX);
			}
		}
		index++;
	}
	if (chindex > 0)
	{
		q->power = chw[0];
		//printf("%s\n", chw);
	}

	while (NULL != p)
	{
		if (-1==strcmp(q->name , p->name))
		{
			break;
		}
		pre = p;
		p = p->next;
	}
	q->next = pre->next;
	pre->next = q;
}
#ifndef HEAD_H
#define HEAD_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <setjmp.h>

#define N 5//ѧ���ĳɼ���Ŀ
#define MAX 256//����Ĵ�С
#define CHMAX 30//��������Ĵ�С

#define CNT 100//�Ǻŵĸ���

//�ļ���Ϣ--ѧ����ʽ��
#define STU_FORMAT_IN "\t%-16d%-24s%-17c%-8s%-16s%-13s%-8.2f%-9.2f%-9.2f%-9.2f%-9.2f\n"
#define STU_FORMAT_OUT p->num, p->name, p->sex, p->age, p->phone,p->birth, p->score[0], p->score[1], p->score[2], p->score[3], p->score[4]

#define STU_FORMAT p[i]->num, p[i]->name, p[i]->sex, p[i]->age, p[i]->phone,p[i]->birth, p[i]->score[0], p[i]->score[1], p[i]->score[2], p[i]->score[3], p[i]->score[4]

#define STU_HEAD "\tnum\t\tname\t\t\tsex(f/m)\tage\tphone\t\tbirth\t\t  score1\tscore2\tscore3\tscore4\tscore5\n"
#define STU_SCANF_IN &num,name,&sex,age,&phone,birth,&score1,&score2,&score3,&score4,&score5


//�ļ���Ϣ--�û���ʽ��
#define USR_FORMAT_IN "\t%-s\t\t%-s\t\t%c\n"
#define USR_FORMAT_OUT p->name, p->pwd, p->power

#define USER_HEAD "\tname\t\tpassword\tpower(4/7)\n"
#define USER_SCANF_IN name,password,&power


/*
 *
 * ѧ����Ϣ�ṹ��
 *
 */
typedef struct student{
	int num;
	char name[20];
	char sex;
	char age[4];
	char phone[12];
	char birth[10];
	float score[N];//�ɼ�
	struct student *next;
}stu, *stulist;

/*
*
* �û���Ϣ�ṹ��
*
*/
typedef struct user{
	char name[20];
	char pwd[20];
	char power;//�û���Ȩ��
	struct user *next;
}user, *userlist;

#endif
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/*
 *
 * copy
 *
 *
 */
void mystrcpy(char str1[], char str2[])
{
	int index = 0;
	while (str2[index])
	{
		str1[index] = str2[index];
		index++;
	}
	str1[index] = 0;
	printf("%s\n", str1);
}

int main()
{
	char str1[10] = { "4444" };
	char str2[6] = {"hello"};
	mystrcpy(str1,str2);
	getchar();
	getchar();
	return 0;
}
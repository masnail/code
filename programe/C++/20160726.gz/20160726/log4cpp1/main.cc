/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月26日 星期二 22时08分10秒
* File Name: main.cc
* Description: C++ file
************************************************************************/
#include "classlog4cpp.h"


int main(int argc,char *argv[])
{
    myLog *mylog=myLog::getInstance();
	
    mylog->error("sysytem");
    myLog::close();
    return 0;
}


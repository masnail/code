#include <iostream>
#include <string>

using namespace std;

typedef struct
{
	string num;
	double score;
}student;

double fun(student s[],student *b,int *count)
{
	double ave = 0,  sum = 0;
	int index = 0,c=0;

	while (index!=3)
	{
		sum+=s[index].score;
		index++;
	}
	ave = sum / 4;
	index = 0;
	while (index!=3)
	{
		if (s[index].score<ave)
		{
			*b = s[index];
			b++;
			c++;
		}
		index++;
	}
	//cout << c <<endl;
	*count = c;
	return ave;
}

int main()
{
	cout << "100-1-054" << endl;
	student stu[] = {
		{"2011",89},
		{"2012",69},
		{"2013",8},
		{"2014",78}
	};
	student *b = new student;
	int *count = new int;
	cout << fun(stu, b, count) << endl;
	cout << *count;
	cin.get();
	cin.get();
	return 0;
}
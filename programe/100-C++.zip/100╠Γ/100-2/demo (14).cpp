#include <iostream>
#include <string>

using namespace std;

/*
*@ 
*@ ����ָ�������    2016��6��4��20:46
*@
*@ ȥ��ָ�� 2016��6��4��20:48
*/
bool Primer(int n)
{
	bool bo = true;
	for (int i = 2; i < n / 2 + 1; i++)
	{
		if (n%i==0)
		{
			return false;
		}

	}
	return true;
}

void fun(int n)
{
	if (!Primer(n))
	{
		cout << n << "=";
		int index = 2;
		while (index != 1)
		{
			if (n%index == 0 && Primer(index))
			{
				cout << index;
				if (n / index == 1)
				{
					n /= index;
					index = 1;
				}
				else
				{
					n /= index;
					cout << "*";
					index = 2;
				}
			}
			else
			{
				index++;
			}
		}
	}
	else//primer
	{
		cout << n << "=" << 1 << "*" << n << endl;
	}
}

int main()
{
	cout << "100-2-014" << endl;
	int n;
	cout << "input a count:";
	cin >> n;
	fun(n);
	cin.get();
	return 0;
}

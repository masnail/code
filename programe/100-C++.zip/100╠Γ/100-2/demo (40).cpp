#include <iostream>
#include <string>

using namespace std;

void fun()
{
	int h[8] = { 55, 4, 5, 5, 59, 89, 55, 79 };
	for (int i = 7; i != -1;i--)
	{
		cout << h[i] << " ";
	}
}

int main()
{
	cout << "100-2-040" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

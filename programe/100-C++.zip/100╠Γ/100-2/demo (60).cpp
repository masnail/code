#include <iostream>
#include <string>

using namespace std;

typedef struct node
{
	int data;
	struct node *next;
}node, *linknode;

void fun()
{
	int index = 1;
	int  n = 10;
	linknode h = (linknode)malloc(sizeof(node)), p = h, q = h;
	h->next = NULL;
	while (index != n + 1)
	{
		p = (linknode)malloc(sizeof(node));
		p->data = index;
		p->next = q->next;
		q->next = p;
		q = p;
		//cout << p->data;
		index++;
	}

	linknode pp = (linknode)malloc(sizeof(node));
	pp->next = NULL;
	while (h->next)
	{
		p = (linknode)malloc(sizeof(node));
		p->data = h->data;
		p->next = pp->next;
		pp->next = p;
		h = h->next;
	}
	
	pp = pp->next;
	while (pp->next)
	{
		cout << pp->data << "  ";
		pp = pp->next;
	}
}

int main()
{
	cout << "100-2-072-73" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <string>

using namespace std;

void fun()
{
	int index = 0;
	for (int i = 1; i != 5;i++)
	{
		for (int j = 1; j != 5;j++)
		{
			for (int k = 1; k != 5;k++)
			{
				if (i!=j&&i!=k&&j!=k)
				{
					cout << i * 100 + j * 10 + k<<"\t";
					index++;
					if (index % 10 == 0)
					{
						cout << endl;
					}
				}
			}
		}
	}
}

int main()
{
	cout << "100-2-001" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
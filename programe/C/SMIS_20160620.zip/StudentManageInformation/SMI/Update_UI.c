#include "Update_UI.h"

//ѧ��
void Update_Student_Show()
{
	system("CLS");
	Print_Welcome();
	Search_Student_All();
	int num=0;
	char name[20] = { 0 }, sex = NULL, age[4] = { 0 },birth[10] = { 0 }, phone[11]={0} ;
	float score5=-1, score1=-1, score2=-1, score3=-1, score4=-1;

	printf("\tinput a student num:");
	scanf("%d", &num);

	system("CLS");
	Print_Welcome();

label_ret:	if (Search_StudentNum(num) == 1)
	{
		int getin = 0;
		printf("\t----------------update choose------------------\n");
		printf("\t1��name\n");
		printf("\t2��sex\n");
		printf("\t3��age\n");
		printf("\t4��phone\n");
		printf("\t5��birth\n");
		printf("\t6��score1\n");
		printf("\t7��score2\n");
		printf("\t8��score3\n");
		printf("\t9��score4\n");
		printf("\t10��score5\n");
		printf("\t11��all update\n");
		printf("\t12��return\n");
		printf("\t13��exit\n");
		printf("\tinput you choose:");
		scanf("%d", &getin);

		Print_Welcome();

		switch (getin)
		{
label_all:		case 1:printf("\tname:");
			scanf("%s", name); 
			if (getin!=11)
			{
				break;
			}
			
		case 2:printf("\tsex(f/m):"); fflush(stdin); scanf("%c", &sex);
			if (getin != 11)
			{
				break;
			}
		case 3:fflush(stdin); printf("\tage:"); scanf("%s", age);
			if (getin != 11)
			{
				break;
			}
		case 4:printf("\tphone:"); scanf("%s", phone); 
			if (getin != 11)
			{
				break;
			}
		case 5:printf("\tbirth:"); scanf("%s", birth); 
			if (getin != 11)
			{
				break;
			}
		case 6:printf("\tscore1:"); scanf("%f", &score1); 
			if (getin != 11)
			{
				break;
			}
		case 7:printf("\tscore2:"); scanf("%f", &score2); 
			if (getin != 11)
			{
				break;
			}
		case 8:printf("\tscore3:"); scanf("%f", &score3); 
			if (getin != 11)
			{
				break;
			}
		case 9:printf("\tscore4:"); scanf("%f", &score4); 
			if (getin != 11)
			{
				break;
			}
		case 10:printf("\tcore5:"); scanf("%f", &score5);
				break;
		case 11:printf("\tplease input all update information\n");goto label_all;
		case 12:Main_Show_User(); 
			break;
		case 13:exit(-1);
		default:
			printf("\terror,again!\n");
			Update_Student_Show();
			break;
		}
		Update_Student_Info(num, name, sex, age, phone, birth, score1, score2, score3, score4, score5);
	}
	else{
		printf("\tthe num is not exist!\n");
	}
	goto label_ret;
}


//�û�
void Update_User_Show()
{
	Print_Welcome();
	Search_User_All();

	char name[20], password[20] = { 0 }, power = { 0 };

	printf("\tinput a name:");
	scanf("%s", &name);

	Print_Welcome();

	if (Search_UserName(name) == 1)
	{
		int getin = 0;
		printf("\t------------------user update------------------\n");
		printf("\t1��password\n");
		printf("\t2��power\n");
		printf("\t3��all\n");
		printf("\t4��return\n");
		printf("\t5��exit\n");
		printf("\tinput you choose:");
		scanf("%d", &getin);

		Print_Welcome();

		switch (getin)
		{
		label_ret:		
		case 1:fflush(stdin); 	
			memcpy(password, Get_Password(), 20);
			if (getin != 3)
			{ 
				break;
			}
			 
		case 2:fflush(stdin); 
			printf("\tpower(4/7):");
			scanf("%c", &power);
				break;
		case 3:goto label_ret; printf("\tplease input all user information\n"); break;
		case 4: Main_Show_User(); break;
		case 5:exit(-1);
		default:
			Update_User_Show();
			break;
		}

		Update_User_Info(name, password, power);

		if (0 == strcmp(name,Get_Name()))
		{
			goto label_Login;
		}
	}
	else{
		printf("\tthe name is not exist!\n");
	}

	Search_User_All();

label_Login:system("CLS");
	printf("\n\tplease log in again\n");
	main();

}
#include <iostream>
#include <string>

using namespace std;

void fun(string s,int n,int h,int e)
{
	string str = "";
	for (int i = h; i != n - e;i++)
	{
		str += s[i];
	}
	cout << str;
}

int GetstringPre(string s, int length)
{
	int index = 0;
	for (int i = 0; i != length;i++)
	{
		if (s[i] == '*')
		{
			index++;
		}
		else
		{
			return index;
		}
	}
	return index;
}

int GetstringNext(string s, int length)
{
	int index = 0;
	for (int i = length-1; i != 0; i--)
	{
		if (s[i] == '*')
		{
			index++;
		}
		else
		{
			return index;
		}
	}
	return index;
}

int main()
{
	cout << "100-1-045" << endl;
	string s;
	cout << "input a string:";
	cin >> s;
	int length = 0, pre = 0, next = 0;
	while (s[length])
	{
		length++;
	}

	fun(s,length,GetstringPre(s,length),GetstringNext(s,length));
	cin.get();
	cin.get();
	return 0;
}
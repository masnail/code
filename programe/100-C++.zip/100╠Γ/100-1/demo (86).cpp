#include <iostream>
#include <string>
#include <numeric>

using namespace std;

void fun(double a[])
{
	int length = 0;
	double sum = 0;
	while (a[length]!=-1)
	{
		length++;
	}
	//cout << length << endl;
	double ave = accumulate(a, a + length, 0)/(double)length;
	/*for (int i = 0; i != length;i++)
	{
		sum += a[i];
	}
	double ave = sum / length;*/
	cout << ave << endl;
	sum = 0;
	for (int i = 0; i != length;i++)
	{
		cout << a[i] << endl;
		sum += pow(a[i] - ave, 2);
	}
	cout << sqrt(sum / length) << endl;
}

int main()
{
	cout << "100-1-086" << endl;
	double a[] = { 95.0,89.0,76.0,65.0,88.0,72.0,85.0,81.0,90.0,56.0,-1 };
	fun(a);
	cin.get();
	cin.get();
	return 0;
}

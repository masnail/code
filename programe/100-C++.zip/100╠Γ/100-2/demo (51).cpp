#include <iostream>
#include <string>

using namespace std;

void fun()
{

}

int main()
{
	cout << "100-2-056-57-58-59-60" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <string>
#include <cmath>
#include <iomanip>

using namespace std;

void fun(double x)
{
	double sump = 0,sum=1.0,index = 0,up=1,low=1;//up ����||low ��ĸ||sump ǰ||sum ��
	while (fabs(sum-sump)>0.000001)
	{
		sump = sum;
		index += 1;
		up *=(0.5 - index+1);
		low *= index;
		sum = sum + up / low*pow(x,index);
	}
	cout <<setprecision(6)<<fixed<< sum << endl;
}

int main()
{
	cout << "100-1-076" << endl;
	double x;
	cout << "input a double(<0.97):";
	cin >> x;
	fun(x);
	cin.get();
	cin.get();
	return 0;
}

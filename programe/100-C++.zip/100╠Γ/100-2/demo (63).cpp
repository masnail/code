#include <iostream>
#include <string>

using namespace std;

void fun(int n)
{
	double sum = 0,index;
	if (n % 2 == 0)
	{
		index = 2;
	}
	else
	{
		index = 1;
	}
	while (index != n + 2)
	{
		sum += 1 / index;
		index += 2;
	}
	cout << sum << endl;
}

int main()
{
	cout << "100-2-076" << endl;
	cout << "input a count:";
	int n;
	cin >> n;
	fun(n);
	cin.get();
	cin.get();
	return 0;
}
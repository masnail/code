#include <iostream>
#include <string>

using namespace std;

string fun(string s)
{
	string st = "";
	for (int i = 0; i != s.length();i++)
	{
		if (s[i]%2!=1)
		{
			st += s[i];
		}
	}
	return st;
}

int main()
{
	cout << "100-1-064" << endl;
	string s,t;
	cin >> s;
	t=fun(s);
	cout << t;
	cin.get();
	cin.get();
	return 0;
}
#include <iostream>
#include <string>

using namespace std;

void fun(int h[])
{
	for (int i = 0; i != 10;i++)
	{
		int temp=h[i],index=i;
		for (int j = i+1; j != 10;j++)
		{
			if (temp> h[j])
			{
				temp = h[j];
				index = j;
			}
		}
		h[index] = h[i];
		h[i] = temp;
	}

	for (int i = 0; i != 10; i++)
		cout << h[i] << "\t";
}

int main()
{
	cout << "100-2-037" << endl;
	int a[10] = { 5, 8, 98, 56, 45, 2, 1, 52, 2, 4 };
	fun(a);
	cin.get();
	cin.get();
	return 0;
}
#include <iostream>
#include <string>

using namespace std;

void fun(int a[][3],int *b,int *nn)
{
	int index = 0;
	for (int i = 0; i != 3;i++)
	{
		for (int j = 0; j != 3;j++)
		{
			*b = a[i][j];
			b++;
			index++;
		}
	}
	*nn = index;
}

int main()
{
	cout << "100-1-055" << endl;
	int a[][3] = {
		{ 212, 15, 21 },
		{ 15, 15, 485 },
		{ 999, 774, 1 }
	};
	int *n = new int;
	int	*b=new int;
	fun(a,b,n);
	//����
	cout << *n << endl;
	cin.get();
	cin.get();
	return 0;
}
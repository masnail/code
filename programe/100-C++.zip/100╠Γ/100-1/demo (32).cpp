#include <iostream>
#include <string>

using namespace std;

void fun(string s, char *t)
{
	int index = 1;
	while (s[index] != NULL&& index<s.length())
	{
		cout << s[index] << endl;
		if (s[index] % 2 == 1 )
		{
			*t = s[index];
			t++;
		}
		index += 2;
	}
}

int main()
{
	cout << "100-1-032" << endl;
	string s;
	char *t = new char;
	cin >> s;
	fun(s, t);

	/*while (*t)
	{
		cout << *t;
		t++;
	}*/
	cin.get();
	cin.get();
	return 0;
}

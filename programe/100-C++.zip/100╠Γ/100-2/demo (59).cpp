#include <iostream>
#include <string>

using namespace std;

void input(int h[5][2])
{
	for (int i = 0; i != 5;i++)
	{
		cin >> h[i][0] >> h[i][1];
	}
}

void output(int h[5][2])
{
	for (int i = 0; i != 5; i++)
	{
		cout<< h[i][0]<<":" << h[i][1]<<endl;
	}
}

int main()
{
	cout << "100-2-071" << endl;
	int h[5][2];
	input(h);
	output(h);
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <string>

using namespace std;

int GetStringLen(string s)
{
	int count = 0;
	while (s[count])
	{
		count++;
	}

	return count;
}

int GetStringFinChar(string str)
{
	int index = GetStringLen(str);
	while (str[index-1]=='*')
	{
		index--;
	}
	return index;
}
string fun(string str)
{
	int length = GetStringLen(str);
	int finchar = GetStringFinChar(str);
	string stemp = "";
	for (int i = 0; i != length;i++)
	{
		if (i<finchar&&str[i] != '*')
		{
			stemp += str[i];
		}
		else if (i>finchar)
		{
			stemp += str[i];
		}
	}
	return stemp;

}

int main()
{
	cout << "100-1-056" << endl;
	cout << "input a string:";
	string str;
	cin >> str;
	cout<<fun(str);
	cin.get();
	cin.get();
	return 0;
}

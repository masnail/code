/*************************************************************************
* Author: MASnail
* Created Time: 2016年08月01日 星期一 20时07分28秒
* File Name: singleton_v1.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

/*
 *
 * 单例模式
 *
 * 自动释放版本V0.0
 *
 * 实现形式：无
 */
class Factory
{
    public:
	static Factory* getInstance()
	{
	    if(_fac==NULL)
		_fac=new Factory;
	    return _fac;
	}
	
	static void destroy() 
	{
	    delete _fac;
	}
	void create_a()
	{
	    cout<<"A CPU"<<endl;
	}
    private:
	Factory()
	{ 
	    cout<<"Factory"<<endl;
	}
	~Factory()
	{ cout<<"~Factory"<<endl;}
    private:
	static Factory * _fac;
};
Factory*  Factory::_fac=NULL;

int main(int argc,char *argv[])
{
    Factory::getInstance()->create_a();
    Factory::getInstance()->create_a();
    Factory::destroy();
    return 0;


    
}


/*************************************************************************
 Author:0054
 Created Time: 2016年07月12日 星期二 15时33分09秒
 File Name: server.c
 Description: 
 ************************************************************************/
#include "../include/head.h"
#include "../include/func_socket.h"
#include "../include/file_socket.h"

void sendFile(int fd)
{
	int client_fd=0,flag=0,ret;
	while(1)
	{
		recv_msg(fd,&client_fd);
		send_file(client_fd,PATH);
		write(fd,&flag,4);
	}
}
void  create_proc(proc *p)
{
	int pid,fds[2];
	for(int i=0;i<SIZE_PROC;i++)
	{
		socketpair(AF_LOCAL,SOCK_STREAM,0,fds);
		pid=fork();
		/* child */
		if(!pid)
		{
			close(fds[1]);
			sendFile(fds[0]);
		}
		/* parent */
		close(fds[0]);
		p[i].pid=pid;
		p[i].busy=0;
		p[i].fdw=fds[1];
	}
}

int main()
{
	int ret;
	int sock_fd;
	int port;
	char ip[16],buff[21];
	memset(ip,0,sizeof(ip));
	memset(buff,0,sizeof(buff));
	int file_fd=open(PATH_CONFIGURE,O_RDONLY);
	if(-1 == file_fd)
	{
		perror("config error");
		return -1;
	}
	ret = read(file_fd,buff,sizeof(buff));
	if(-1 == ret)
	{
		perror("configi file error");
		close(file_fd);
		return -1;
	}
	char *pch=strtok(buff,"|");
	port=atoi(pch);
	pch=strtok(NULL,"|");
	strcpy(ip,pch);
	close(file_fd);

	proc *p=(proc*)calloc(SIZE_PROC,sizeof(proc));
	create_proc(p);

	socket_server_tcp(&sock_fd,port,ip,SIZE_CONNECT);
	int epfd=epoll_create(1);
	if(-1 == epfd)
	{
		perror("epoll_create");
		close(sock_fd);
		return -1;
	}
	
	struct epoll_event evt;
	memset(&evt,0,sizeof(struct epoll_event));
	evt.events=EPOLLIN;
	evt.data.fd=sock_fd;
	ret = epoll_ctl(epfd,EPOLL_CTL_ADD,sock_fd,&evt);
	if(-1 == ret)
	{
		perror("epoll_ctl");
		close(sock_fd);
		close(epfd);
		return -1;
	}
	for(int i=0;i<SIZE_PROC;i++)
	{
		memset(&evt,0,sizeof(struct epoll_event));
		evt.events=EPOLLIN;
		evt.data.fd=p[i].fdw;
		ret = epoll_ctl(epfd,EPOLL_CTL_ADD,p[i].fdw,&evt);
		if(-1 == ret)
		{
			perror("epoll_ctl");
			close(sock_fd);
			close(epfd);
			return -1;
		}
	}
	struct epoll_event *evts=(struct epoll_event*)calloc(SIZE_PROC+1,sizeof(struct epoll_event));
	int client_fd,flag;
	while(1)
	{
		ret = epoll_wait(epfd,evts,SIZE_PROC+1,-1);
		if(-1 == ret)
		{
			perror("epoll_wait");
			close(sock_fd);
			close(epfd);
			return -1;
		}else if(ret>0){
		for(int i=0;i<SIZE_PROC+1;i++)
		{
			if(sock_fd == evts[i].data.fd)
			{
				client_fd=accept(sock_fd,NULL,NULL);
				for(int j=0;j<SIZE_PROC;j++)
				{
					if(p[j].busy==0)
					{
						send_msg(p[j].fdw,client_fd);
						close(client_fd);
						p[j].busy=1;
						break;
					}
				}
			}//for-client end 

				for(int k=0;k<SIZE_PROC;k++)
				{
					if(p[k].fdw == evts[i].data.fd)
					{
						read(p[k].fdw,&flag,4);
						p[k].busy=0;
					}
				}
			}
		}//if -end
	}
	close(sock_fd);
	return 0;
}

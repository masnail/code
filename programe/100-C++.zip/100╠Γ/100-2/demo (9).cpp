﻿#include <iostream>
#include <string>

using namespace std;

void fun()
{
	for (int i = 0; i != 9;i++)
	{
		for (int j = 0; j != 9;j++)
		{
			if ((i + j)%2==0)
			{
				cout << char(4);
			}
			else
			{
				cout << "  ";
			}
		}
		cout << endl;
	}
}

int main()
{
	cout << "100-2-009" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <string>

using namespace std;

void fun()
{
	cout << "        "
		<<char(1)
		<<"        "
		<< char(1)
		<<endl;
	for (int i = 0; i != 11;i++)
	{
		for (int j = 0; j != i ; j++)
			cout << " ";

		for (int j = 0; j != 8; j++)
			cout << "����";
		cout << endl;
	}
}

int main()
{
	cout << "100-2-0" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

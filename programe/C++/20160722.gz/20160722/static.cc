/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月22日 星期五 19时41分41秒
* File Name: computer.cc
* Description: C++ file
************************************************************************/

#include <string.h>
#include <stdio.h>

#include <iostream>

using std::cout;
using std::cin;
using std::endl;

class computer
{
public:
    computer(const char *brand,float fprice);
#if 0   //浅拷贝
    computer(const computer &rhs)
	:_brand(rhs._brand)
	 ,_fprice(_fprice)
    {	}
#endif

    //深拷贝
    computer(const computer &rhs);
    ~computer();
    void print();
    float getPrice();
    void setBrand(const char *brand);
    void setPrice(float price);
    static void showStatic();
private:
    char *_brand;
    float _fprice;
    static int cnt;
};

int computer::cnt=0;//静态变量在类的外面初始化，被类的对象共享

computer::computer(const char *brand,float fprice)
	:_fprice(fprice)
    {
	_brand=new char[strlen(brand)+1];
	strcpy(_brand,brand);
	cnt+=1;
    }
#if 0   //浅拷贝
computer::computer(const computer &rhs)
	:_brand(rhs._brand)
	 ,_fprice(_fprice)
    {	}
#endif

    //深拷贝
computer:: computer(const computer &rhs)
	:_fprice(rhs._fprice)
    {
	_brand=new char[strlen(rhs._brand)+1];
	strcpy(_brand,rhs._brand);
	cnt+=1;
    }
    
computer:: ~computer()
    {
	delete [] _brand;
    }
void computer::print()
{
    cout<<"brand="<<_brand<<endl;
    cout<<"price="<<_fprice<<endl;
    cout<<"cnt="<<cnt<<endl;
}

float  computer::getPrice()
{
    return _fprice;
}

void computer::setBrand(const char *brand)
{
    _brand=new char[strlen(brand)+1];
    strcpy(_brand,brand);
}

void computer::setPrice(float price)
{
    _fprice=price;
}
 void computer::showStatic()//static function 不含有this指针，不能直接访问非静态变量
{
    cout<<"this is a static function"<<endl;
    cout<<"static cnt="<<cnt<<endl;
}
int main(int argc,char *argv[])
{
    computer pc1("LENOVO",4999);
    pc1.showStatic();
    pc1.print();
    cout<<endl;

    computer pc2=pc1;
    pc2.setBrand("LENOVO_y470");
    pc2.setPrice(pc2.getPrice()-500);
    pc2.print();
    pc2.showStatic();
   return 0; 
}


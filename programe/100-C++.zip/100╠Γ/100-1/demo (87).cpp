#include <iostream>
#include <string>

using namespace std;

int fun(int a,int b)
{
	return a / 10 * 1000 + a % 10 * 10 + b / 10 + b % 10 * 100;
}

int main()
{
	cout << "100-1-087" << endl;
	cout << "input two int  count:";
	int a, b;
	cin >> a >> b;
	cout<<fun(a,b)<<endl;
	cin.get();
	cin.get();
	return 0;
}

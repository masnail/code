/*************************************************************************
 Author:MASnail
 Created Time: 2016年07月08日 星期五 13时55分42秒
 File Name: client.c
 Description: 
 ************************************************************************/

#include "head.h"

void set_nonb(int fd)
{
	int old_arr=fcntl(fd,F_GETFL);
	old_arr=old_arr|O_NONBLOCK;
	int ret=fcntl(fd,F_SETFL,old_arr);
	if(-1 == ret)
	{
		perror("fcntl");
		return;
	}
}

int main()
{
	int ret;
	int sock_client;
	sock_client = socket(AF_INET,SOCK_STREAM,0);
	if(-1 == sock_client)
	{
		perror("socket");
		return -1;
	}

	struct sockaddr_in ip_serve;
	memset(&ip_serve,0,sizeof(ip_serve));
	ip_serve.sin_family=AF_INET;
	ip_serve.sin_port=htons(2016);
	ip_serve.sin_addr.s_addr=inet_addr("192.168.1.92");//INADDR_ANY;
	
	ret = connect(sock_client,(struct sockaddr*)&ip_serve,sizeof(ip_serve));
	if(-1 == ret)
	{
		perror("connect");
		close(sock_client);
		return -1;
	}

	//seting more thread array
	int ret_serve;
	char buff[MAX];
	
	int index=0;//count epfd
	int epfd=epoll_create(1);
	struct epoll_event evt;
	struct epoll_event *evts=(struct epoll_event*)malloc(2*sizeof(struct epoll_event));
	memset(&evt,0,sizeof(struct epoll_event));
	memset(evts,0,sizeof(struct epoll_event)*2);
	set_nonb(sock_client);//nonblock
	evt.events=EPOLLIN|EPOLLET;
	evt.data.fd=sock_client;
	ret_serve=epoll_ctl(epfd,EPOLL_CTL_ADD,sock_client,&evt);
	evt.events=EPOLLIN;
	evt.data.fd=0;
	ret_serve=epoll_ctl(epfd,EPOLL_CTL_ADD,0,&evt);
	while(1)
	{
		ret = epoll_wait(epfd,evts,2,-1);
		for(index=0;index<ret;index++)
		{
			//recv
			if(evts[index].events==EPOLLIN&&evts[index].data.fd==sock_client)
			{
				while(1)
				{
					memset(&buff,0,sizeof(buff));
					ret_serve = recv(sock_client,buff,sizeof(buff)-1,0);
					if(ret_serve > 0)
						printf("%s",buff);
				/* client end */ 
					else if(0 == ret_serve){
						close(sock_client);
						goto ret;
					}else{
						break;
					}

				}
				 printf("\n");
			}

			//send
			if(evts[index].events==EPOLLIN&&evts[index].data.fd==0)
			{
				memset(&buff,0,sizeof(buff));
				read(0,buff,sizeof(buff));
				ret_serve = send(sock_client,buff,strlen(buff)-1,0);
				
				/* client end */
				if(-1 == ret_serve){
					close(sock_client);
					break;
				}
			}
		}
	}
ret:	close(epfd);
	return 0;
}

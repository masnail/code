#include <iostream>
#include <string>


using namespace std;

string fun(string str1, string str2)
{
	int index = 0;

	while (str1[index] && str2[index])
	{
		index++;
	}

	if (!str2[index])
	{
		return str1;
	}
	else 
	{
		return str2;
	}
}

int main()
{
	string s1, s2;
	cout << "100-1-025" << endl;
	cout << "�����������ַ���" << endl;
	cin >> s1 >>s2;
	cout<<fun(s1, s2);
	cin.get();
	cin.get();
	return 0;
}
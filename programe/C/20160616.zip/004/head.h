#ifndef HEAD_H
#define HEAD_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 50

typedef struct student
{
	char num[10];
	char name[20];
	char sex;
	float score1;
	float score2;
	float score3;
	
}stu;

typedef struct stuinfo
{
	struct student s[1];
	struct stuinfo *next;
}studinfo,*stuinfolist;

static int stucnt = 0;

void stulist_show(stuinfolist);
void File_Read(char[],stuinfolist*);
void File_Write(char[], stu);
int compare(const void*, const void*);
int Get_stulist_length(stuinfolist);
void sort_stuinfo(char[],stuinfolist);

#endif
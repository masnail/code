#include <iostream>

using namespace std;

void fun(char *s)
{
	while (*s)
	{
		*s = 'A';
		++s;
	}
}

int main()
{
	cout << "100-1-016" << endl;
	char s[] = "ghfghfghfghfgh";
	fun(s);
	char *ss = s;
	while (*ss)
	{
		cout << *ss << endl;
		ss+=1;
	}
	getchar();
	return 0;
}
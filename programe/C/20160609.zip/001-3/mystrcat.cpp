#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/*
*
* copy
*
*
*/
void mystrcat(char str1[], char str2[])
{
	int index = 0, temp = 0;
	while (str1[index]){
		index++;
	}
	
	while (str2[temp])
	{
		str1[index] = str2[temp];
		index++;
		temp++;
	}
	str1[index] = 0;

	printf("%s\n", str1);
}

int main()
{
	char str1[] = { "1234" };
	char str2[] = { "123456" };
	mystrcat(str1, str2);

	getchar();
	getchar();
	return 0;
}
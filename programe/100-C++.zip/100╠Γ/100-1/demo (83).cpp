#include <iostream>
#include <string>

using namespace std;

int GetStringLen(string s)
{
	int index = 0;
	while (s[index])
	{
		index++;
	}
	return index;
}

string fun(string s)
{
	int length = GetStringLen(s);
	bool choose = false;
	string stemp = "";
	for (int i = length-1; i != -1; i--)
	{
		if (choose)
		{
			stemp = s[i] + stemp;
		}
		else 
		{
			if (s[i] != '*')
			{
				choose = true;
				stemp = s[i] + stemp;
			}
		}
	}
	return stemp;
}

int main()
{
	cout << "100-1-083" << endl;
	string s;
	cout << "input a string:" << endl;
	cin >> s;
	cout<<fun(s);
	cin.get();
	cin.get();
	return 0;
}

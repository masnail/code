#include "test.h"


using namespace std;

void fun()
{
	cout << "The test of include !" << endl;
}

int main()
{
	cout << "100-2-050" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

/*************************************************************************
* Author: MASnail
* Created Time: 2016年08月03日 星期三 23时06分46秒
* File Name: queue_test.cc
* Description: C++ file
************************************************************************/
#include <iostream>
#include "queue_template.h"
using std::cout;
using std::cin;
using std::endl;

int main(int argc,char *argv[])
{
    Queue<int,10> que;
    cout<<"queue full:"<<que.full()<<endl;
    cout<<"queue.empty:"<<que.empty()<<endl;
    for(int i=0;i<1;i++)
    {
	que.enqueue(i);
    }
    //que.enqueue(45);
   // que.enqueue(78);
    cout<<"queue full:"<<que.full()<<endl;
    cout<<"queue.empty:"<<que.empty()<<endl;

    cout<<"delqueue:"<<endl;

    int temp;
    for(int i=0;i<11;i++)
    {
	if(que.delqueue(temp))
	     cout<<temp<<" ";
    }
    cout<<endl;


    return 0;
}


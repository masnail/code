#ifndef HEAD_H
#define HEAD_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 1024

void File_read(char[]);
void File_write(char[]);
void Word_deal(char*);


#endif
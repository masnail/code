#include <iostream>
#include <string>

using namespace std;

void fun()
{
	int index = 0, sum = 0, count = 1;
	while (index!=20)
	{
		sum += count;
		count = count*(count + 1);
		index += 1;
	}
	cout << sum << endl;
}

int main()
{
	cout << "100-2-025" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
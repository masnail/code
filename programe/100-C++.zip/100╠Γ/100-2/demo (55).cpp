#include <iostream>
#include <string>

using namespace std;

void fun(int a[])
{
	int max =a[0],maxindex=0,min = a[0],minindex=0;
	for (int i = 0; i != 10;i++)
	{
		if (a[i]>max)
		{
			max = a[i];
			maxindex = i;
		}
		else if (a[i]<min)
		{
			min = a[i];
			minindex = i;
		}
	}
	int temp;
	temp = a[0];
	a[0] = max;
	a[maxindex] = temp;

	temp = a[9];
	a[9] = min;
	a[minindex] = temp;

	for (int i = 0; i != 10;i++)
	{
		cout << a[i] << "\t";
	}
}

int main()
{
	cout << "100-2-067" << endl;
	int h[10] = { 44, 44, 656, 442, 855, 02, 5, 3, 9, 0 };
	fun(h);
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <string>

using namespace std;

int fun(int n)
{
	if (n==0)
	{
		return 0;
	}
	else if (n==1)
	{
		return 1;
	}
	else
	{
		return fun(n - 1) + fun(n - 2);
	}
}

int main()
{
	cout << "100-1-069" << endl;
	int n;
	cout << "input a  int:";
	cin >> n;
	cout<<fun(n);
	cin.get();
	cin.get();
	return 0;
}
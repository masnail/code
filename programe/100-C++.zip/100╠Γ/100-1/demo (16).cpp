#include <iostream>

using namespace std;

float fun(double h)
{
	cout.setf(ios::fixed);
	cout.precision(2);
	return h;
}

int main()
{
	cout << "100-1-015" << endl;

	float h;
	cin >> h;
	cout << fun(h);
	getchar();
	return 0;
}
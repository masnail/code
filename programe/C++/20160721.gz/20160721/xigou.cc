/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月21日 星期四 16时53分04秒
* File Name: xigou.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

class point
{ 
public:
    point()
    {
	cout<<"point( )"<<endl;
    }
    
    void show( )
    {
	cout<<"the function point"<<endl;
    }

    ~point( )
    { 
	cout<<"~point( )"<<endl;
    }
private:
};

int main(int argc,char *argv[])
{
    point p; 
   // p.show( );
    return 0;
}


#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

void* func_pth(void *p)
{
	printf("child thread get a return value:%d\n",(int)p);
	p+=1;
	pthread_exit(p);
}

int main()
{

	pthread_t pth;
	pthread_create(&pth,NULL,func_pth,(void*)1);
	int *q;
	pthread_join(pth,(void**)q);
	printf("main thread get a ret:%d\n",*q);
	return 0;
}

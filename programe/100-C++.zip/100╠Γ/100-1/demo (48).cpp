#include <iostream>
#include <string>

using namespace std;

void fun(int first,int second)
{
	int c = first / 10 * 1000 + first % 10 * 10 + second / 10 * 100 + second % 10;
	cout << c;
}

int main()
{
	cout << "100-1-048" << endl;
	int a, b;
	cout << "input two count:";
	cin >> a >> b;
	fun(a,b);
	cin.get();
	cin.get();
	return 0;
}
#include <iostream>

#define N 256

using namespace std;

void fun(int a[5][5])
{
	for (int i = 0; i < 5;i++)
	{
		for (int j = 0; j < 5;j++)
		{
			if (i>j)
			{
				a[i][j] = 0;
			}
		}
	}
}
int main()
{
	int arr[5][5] = {
		{ 1, 1, 1, 1, 1 },
		{ 1, 1, 1, 1, 1 },
		{ 1, 1, 1, 1, 1 },
		{ 1, 1, 1, 1, 1 },
		{ 1, 1, 1, 1, 1 },
	};
	fun(arr);
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			
			cout<<arr[i][j];
		}
		cout << endl;
	}
	getchar();
	return 0;
}
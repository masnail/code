#include <iostream>
#include <string>
#include <cmath>

using namespace std;

double fun(double m)
{
	double index = 1,s=0;
	while (index!=m+1)
	{
		s += log(index);
		index += 1;
	}
	return sqrt(s);
}

int main()
{
	cout << "100-1-092" << endl;
	cout << "input a count:";
	double m;
	cin >> m;
	cout<<fun(m)<<endl;
	cin.get();
	cin.get();
	return 0;
}

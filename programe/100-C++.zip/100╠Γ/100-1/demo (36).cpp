#include <iostream>
#include <string>

using namespace std;

void fun(string s)
{
	string str = "";
	int index = 0;//index->��¼*�ĸ���
	for (int i = 0; i !=s.length();i++)
	{
		if (s[i]!='*')
		{
			str += s[i];
		}
		else
		{
			index++;
		}
	}
	while (index)
	{
		str += '*';
		index--;
	}
	cout<< str;
}
int main()
{
	cout << "100-1-036" << endl;
	string s;
	cin >> s;
	fun(s);
	cin.get();
	cin.get();
	return 0;
}

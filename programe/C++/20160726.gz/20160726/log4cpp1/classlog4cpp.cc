/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月26日 星期二 19时55分06秒
* File Name: classlog4cpp.cc
* Description: C++ file
************************************************************************/
#include "classlog4cpp.h"

myLog * myLog::_mylog=NULL;

myLog * myLog::getInstance()
{
    if(!_mylog)
	_mylog=new myLog;
    return _mylog;
}

myLog::myLog()
    :_root(Category::getRoot())
{
    OstreamAppender *osApender=new OstreamAppender("osApender",&cout);
    PatternLayout *pLayout=new PatternLayout();
    pLayout->setConversionPattern("%d:%p %c %x:%m%n");
    PatternLayout *pLayoutf=new PatternLayout();
    pLayoutf->setConversionPattern("%d:%p %c %x:%m%n");

    RollingFileAppender *rfAppender=new RollingFileAppender("rfAppender","rflog-1",5*1024,1);
    osApender->setLayout(pLayout);
    rfAppender->setLayout(pLayoutf);
    _root.addAppender(osApender);  
    _root.addAppender(rfAppender);
    _root.setPriority(Priority::DEBUG);
}

void myLog::close()
{
    delete _mylog;
    Category::shutdown();
}

void myLog::warn(const char *msg)
{
    _root.warn(msg);
}

void myLog::error(const char *msg)
{
    _root.error(msg);
}

void myLog::debug(const char *msg)
{
    _root.debug(msg);
}

void myLog::info(const char *msg)
{
    _root.info(msg);
}

void myLog::fatal(const char *msg)
{
    _root.fatal(msg);
}

void myLog::alert(const char *msg)
{
    _root.alert(msg);
}



#include <iostream>
#include <string>

using namespace std;

void fun(string s)
{
	int index = 0;
	while (s[index])
	{
		index++;
	}

	cout << s << " length is :" << index << endl;
}

int main()
{
	cout << "100-2-070" << endl;
	cout << "input a string:";
	string s;
	cin >> s;
	fun(s);
	cin.get();
	cin.get();
	return 0;
}

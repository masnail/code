#include <iostream>
#include <string>

using namespace std;

/*
void fun(string *s,string *m)
{
	int length = 0,index=0;
	while (s)
	{
		if (s[index].length()>length)
		{
			length = s[index].length();
			m = s;
		}
		s++;
	}
}*/

void fun(string s,string *m,int *length)
{
	if (*length < s.length())
	{
		*m = s;
	}
}

int main()
{
	cout << "100-1-043" << endl;
	string str,*max=new string;
	int *length = new int;
	*length = 0;
	getline(cin, str);
	while (str!="****")
	{
// 		*ss = str;
		fun(str,max,length);
		getline(cin, str);
// 		ss++;
	}
	//fun(ss,max);
	cout << max<<":"<<*max << endl;
	cin.get();
	cin.get();
	return 0;
}
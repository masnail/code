#include <iostream>
#include <string>

using namespace std;

void fun(int n)
{
	int a = n %10;
	int b = n % 100 / 10;
	int c = n % 1000 / 100;
	int d = n / 1000;
	a = (a + 5) % 10;
	b = (b + 5) % 10;
	c = (c + 5) % 10;
	d = (d + 5) % 10;
	cout << a * 1000 + d + b * 100 + c * 10 << endl;
}

int main()
{
	cout << "100-2-089" << endl;
	cout << "input a count:";
	int n;
	cin >> n;
	fun(n);
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <string>

using namespace std;

void fun()
{
	for (int i = 1; i != 10;i++)
	{
		for (int j = 1; j != i + 1;j++)
		{
			cout << i << "X" << j << "=" << i*j << "\t";
		}
		cout << endl;
	}
}

int main()
{
	cout << "100-2-008" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
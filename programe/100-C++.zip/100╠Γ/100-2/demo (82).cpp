#include <iostream>
#include <string>
#include <fstream>

using namespace std;

void fun(string s)
{
	ofstream fout("upper.txt");
	for (int i = 0; i != s.length();i++)
	{
		fout << char(toupper(s[i]));
	}

	cout << "������ɡ���" << endl;
}

int main()
{
	cout << "100-2-098" << endl;
	cout << "input a string" << endl;
	string s;
	cin >> s;
	fun(s);
	cin.get();
	cin.get();
	return 0;
}

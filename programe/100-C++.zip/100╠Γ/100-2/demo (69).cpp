#include <iostream>
#include <string>
#include <regex>

using namespace std;

typedef struct node
{
	int data;
	struct node *next;
}node,*nodelink;

void Bin(int n,node *p)
{
	//β�����ӷ�
	while (n)
	{
		node *q = (nodelink)malloc(sizeof(node));
		q->data = n % 2;

		q->next = p->next;
		p->next = q;
		p = q;

		n /= 2;
	}
}

void fun(string str)
{
	int sum = 0, index = 0, arr[3] = { 0 };
	for (int i = 0; i != str.length();i++)
	{
		if (!isdigit(str[i])||str[i]<'0'||str[i]> '7')
		{
			cout << "�������ȷ���ǰ˽�����?" << endl;
			return;
		}
	}

	node *head = (nodelink)malloc(sizeof(node));
	head->data = 0;
	head->next = NULL;
	node *p =head;

	for (int i = 0; i != str.length();i++)
	{
		//Bin(str[i] - 48,p);

		int n = str[i] - 48;
		node *q = (nodelink)malloc(sizeof(node)),*pp;
		q->data = n % 2;
		n /= 2;
		head->data += 1;
		q->next = p->next;
		p->next = q;
		pp = q;
		for (int i = 1; i != -1;i--)
		{
			node *q = (nodelink)malloc(sizeof(node));
			q->data = n % 2;
			n /= 2;
			head->data += 1;
			q->next = p->next;
			p->next = q;
		}
		p = pp;
	}

	p = head->next;
	index = head->data-1;
	while (p)
	{
		cout << p->data;
		sum += (p->data)*pow(2, index);
		index--;
		p = p->next;
	}
	cout << endl;
	cout << sum << endl;
}

int main()
{
	cout << "100-2-082" << endl;
	cout << "input a count(�˽���): ";
	string str;
	cin >> str;
	if (str != "*")
	{
		fun(str);
		main();
	}
	else
	{
		cout << "������" << endl;
	}
	cin.get();
	cin.get();
	return 0;
}
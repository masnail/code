/*************************************************************************
 Author:MASnail
 Created Time: 2016年07月04日 星期一 17时33分25秒
 File Name: a.c
 Description: 
 ************************************************************************/
#ifndef HEAD_H
#define HEAD_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/sem.h>
#include <stdlib.h>
#include <time.h>


#define MAX 512 //the array length
#define SIZE_MEM 4096 //memory
#define TIME_MEM 20 //time malloc

#endif

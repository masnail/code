#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define M 256
#define N 16

/*
*
*С��û�п��ǵ�
*/

int main()
{
	int n;
	char ch[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
	int count[M], index = 0;
	while (scanf("%d", &n) != EOF)
	{
		index = 0;
		while (n != 0)
		{
			count[index] = n % N;
			n /= N;
			index++;
		}
		if (index < M)
		{
			for (int i = index - 1; i >= 0; i--)
			{
				printf("ת����Ϊ��%c", ch[count[i]]);
			}
			printf("\n");
		}
		else{
			printf("��Ҫת���ɵ�16������̫���ˣ�\n");
		}
	}
	getchar();
	getchar();
	return 0;
}
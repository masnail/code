/*************************************************************************
* Author: MASnail
* Created Time: 2016年08月03日 星期三 10时44分38秒
* File Name: template.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

template < typename Ta,typename Tb>
double add(Ta a,Tb b)
{
    return a+b;
}

int main(int argc,char *argv[])
{
    cout<<add(3.8,8)<<endl;
    cout<<add(348,8)<<endl;
    cout<<add(3.8,8.5)<<endl;

    return 0;
}


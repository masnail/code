#include "Update_Student_User.h"

/*
*
* ѧ����Ϣ�ĸ���
*
*
*/

void Update_Student_Info( int num,char* name, char sex, char *age, char* phone, char * birth, float score0, float score1, float score2, float score3, float score4)//������Ϣ�����Ұ���Ϣ���浽�ļ���
{
	stulist head = Get_stu_Head();
	stulist p = head->next;

	while (p)
	{
		if (num == p->num)
		{
			break;
		}
		p = p->next;
	}

	if (0!=strcmp(p->name,name)&&*name!=NULL)
	{
		memcpy(p->name, name, 20);
	}
	if (p->sex != sex&&sex!='\0')
	{
		p->sex = sex;
	}
	if (0 != strcmp(p->age, age) && *age!=NULL)
	{
		memcpy(p->age, age, 2);
	}
	if (0 != strcmp(p->phone, phone) && *phone != NULL)
	{
		memcpy(p->phone, phone, 11);
	}
	if (0 != strcmp(p->birth, birth) && *birth!=NULL)
	{
		memcpy(p->birth, birth, 10);
	}
	if (p->score[0] != score0&&-1!=score0)
	{
		p->score[0] = score0;
	}
	if (p->score[1] != score1&&-1!=score1)
	{
		p->score[1] = score1;
	}
	if (p->score[2] != score2&&-1!=score2)
	{
		p->score[2] = score2;
	}
	if (p->score[3] != score3&&-1!=score3)
	{
		p->score[3] = score3;
	}
	if (p->score[4] != score4&&-1!=score4)
	{
		p->score[4] = score4;
	}
	File_Write_Student();
	//memcpy(p->name, ptemp,sizeof(stu));
}
/*
*
* �û���Ϣ�ĸ���
*
*
*/

void Update_User_Info( char* name,char *pwd,char power)//������Ϣ�����Ұ���Ϣ���浽�ļ���  �ַ�����/f  �������޸�
{
	userlist p = Get_user_Head()->next;

	while (p)
	{
		if (0 == strcmp(p->name,name))
		{
			break;
		}
		p = p->next;
	}
	if ('\0' != power&&p->power!=power)
	{
		p->power = power;
	}
	else if (NULL!= *pwd &&pwd!=p->pwd)
	{
		memcpy(p->pwd, pwd, 20);
	}
	File_Write_User();
}
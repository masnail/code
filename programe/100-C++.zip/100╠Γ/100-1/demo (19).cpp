#include <iostream>

using namespace std;

void fun(char *s,char ch)
{
	while (*s)
	{
		if (*s==ch)
		{
			char *p = s;
			while (*p)
			{
				*p = *(p+1);
					p++;
			}
		}
		else
		{
			s++;
		}
	}
}

int main()
{
	cout << "100-1-019"<<endl;
	char s[] = "ddfsdfsdfasadfwertjknasdgZMXbhjoiawwuid";
	fun(s,'d');
	char *p = s;
	while (*p)
	{
		cout << *p;
		p++;
	}
	getchar();
	return 0;
}
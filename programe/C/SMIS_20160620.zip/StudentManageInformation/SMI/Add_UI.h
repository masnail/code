#include "head.h"
#include "Add_Student_User.h"
//#include "Search_Student.h"

//ѧ��
void Add_Student_Show();


//�û�
void Add_Student_Show();
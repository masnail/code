#include <iostream>
#include <string>

using namespace std;

void fun()
{
	cout << "Hello world!" << endl;
}

int main()
{
	cout << "100-2-034" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
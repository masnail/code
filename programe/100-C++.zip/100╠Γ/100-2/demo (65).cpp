#include <iostream>
#include <string>

#define N 4

using namespace std;

static struct man
{
	char name[20];
	int age;
} person[N] = { 
	{ "li", 18 }, 
{ "wang", 156 }, 
{ "zhang", 20 },
{ "sun", 92 }
};

void fun()
{
	struct man *q=new struct man, *p=new struct man;
	int i, m = 0;
	p = person;
	for (i = 0; i < N; i++)
	{
		if (m < p->age)
		{
			m = p->age;
			q = p;
		}
		p++;
	}
	printf("%s,%d", (*q).name, (*q).age);
}

int main()
{
	cout << "100-2-078" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
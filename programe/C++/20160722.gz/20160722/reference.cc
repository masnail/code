/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月22日 星期五 20时39分44秒
* File Name: reference.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;


/*
 * 引用数据成员必须要放在初始化的列表中
 *
 * 引用的时候，传入的是变量名，不是数据，
 * 因为引用是在地址的级别上操作
 *
 */
class swap
{
public:
    swap(int &ix,int &iy);
    void swapc();
    void print();
    ~swap();
private:
    int &_ix;
    int &_iy;
};

swap::swap(int &ix,int &iy)
    :_ix(ix)
     ,_iy(iy)
{ }
void swap::swapc()
{
    int temp=_ix;
    _ix=_iy;
    _iy=temp;
}

void swap::print()
{
    cout<<"a="<<_ix<<endl;
    cout<<"b="<<_iy<<endl;
}
swap::~swap()
{
    cout<<"swap count end"<<endl;
}
int main(int argc,char *argv[])
{
    int a=2,b=5;
    cout<<"swap before"<<endl;
    swap s(a,b);
    s.print();
    cout<<"swap after"<<endl;
    s.swapc();
    s.print();
    return 0;
}


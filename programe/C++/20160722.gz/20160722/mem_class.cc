/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月22日 星期五 20时05分49秒
* File Name: mem_class.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

class cell
{
private:
	int a;
	char b;
	char *p;
	float &d;
	double &g;
	short h;
	static int hh;//不在函数栈，位于全局静态区
public :	
    void print();
};

class empty
{};
//字节对齐
int main(int argc,char *argv[])
{
    cout<<"sizeof(empty)="<<sizeof(empty)<<endl;
    cout<<"sizeof(cell)="<<sizeof(cell)<<endl;
    return 0;
}


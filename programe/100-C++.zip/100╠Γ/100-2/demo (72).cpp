#include <iostream>
#include <string>

using namespace std;

void fun(int n)
{
	int s = 9,index=0;
	while (s<=n)
	{
		if (n%9==0)
		{
			index++;
		}
		s += s * 10;
	}
	cout << index << endl;
}

int main()
{
	cout << "100-2-085" << endl;
	cout << "input a primer count:";
	int n;
	cin >> n;
	fun(n);
	cin.get();
	cin.get();
	return 0;
}

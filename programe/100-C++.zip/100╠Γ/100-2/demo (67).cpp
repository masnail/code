#include <iostream>
#include <string>

#define MAX 10000

using namespace std;

void fun()
{
	for (int i = 6; i != MAX;i++)
	{
		if (i%5==1)//1
		{
			int temp = (i - 1) * 4 / 5;
			if (temp%5==1)//2
			{
				temp = (temp - 1) * 4 / 5;
				if (temp % 5 == 1)//3
				{
					temp = (temp - 1) * 4 / 5;
					if (temp % 5 == 1)//4
					{
						temp = (temp - 1) * 4 / 5;
						if (temp % 5 == 1)//5
						{
							cout << i << endl;
						}
					}
				}
			}
		}
	}
}

int main()
{
	cout << "100-2-080" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
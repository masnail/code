#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#define MAX 256

/*
*
*�ּ𵥴�
*
*
*
*/
int ISWord(char ch)
{
	if (ch >= 'a'&&ch <= 'z' || ch >= 'A'&&ch <= 'Z' || ch >= '0'&&ch <= '9')
	{

		return 1;
	}

	return 0;
}

void ReverWord(char ch[],int start,int end)
{
	for (int i = 0; i < (end -start)/2; i++)
	{
		char temp = ch[i+start];
		ch[i + start] = ch[end-i-1];
		ch[end-i-1] = temp;
	}
}

int main()
{
	char ch[MAX] = { 0 };
	int pre = 0, next = pre;
	while (gets(ch) != EOF){
		ReverWord(ch, 0, strlen(ch));
		pre = 0;
		while (next<strlen(ch))
		{
			while (!ISWord(ch[pre]))//�ҵ�word��ʼ
			{
				pre++;
			}

			next = pre;

			while (ISWord(ch[next]))//�ҵ�word����
			{
				next++;
			}

			ReverWord(ch, pre, next);

			pre = next;
			//index = next;
		}

		printf("Output:");
		puts(ch);
		printf("\n");
	}

	getchar();
	getchar();
	return 0;
}
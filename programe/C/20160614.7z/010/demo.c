#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct node
{
	int data;
	struct node *next;
}nd, *nodelist;

void list_insert_tail(nodelist *head, nodelist *tail, int i)
{
	//for (int i = 0; i < 10; i++)
	{
		nodelist q = (nd*)malloc(sizeof(nd));
		memset(q, 0, sizeof(nd));
		q->data = i + 1;
		q->next = (*tail)->next;
		(*tail)->next = q;
		(*tail) = q;
		(*head)->data += 1;
	}
}

void list_show(nodelist head)
{
	nodelist p = head->next;
	while (p)
	{
		printf("%d\t", p->data);
		p = p->next;
	}
	printf("\n");
}

void list_find_mid(nodelist head)
{
	nodelist p = head->next;
	int index = 0;

	while (p)
	{
		p = p->next;
		index++;
	}
	p = head->next;
	index /= 2;
	while (index!=0)
	{
		p = p->next;
		index--;
	}
	printf("%d\t", p->data);
}

int main()
{
	srand((unsigned)(time(NULL)));

	nodelist phead = (nodelist)malloc(sizeof(nd)), ptail = phead;
	memset(phead, 0, sizeof(nd));
	for (int i = 0; i < 11; i++)
	{
		list_insert_tail(&phead, &ptail, rand() % 100);
	}
	list_show(phead);
	list_find_mid(phead);

	getchar();
	return 0;

}
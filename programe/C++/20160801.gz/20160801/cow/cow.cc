/*************************************************************************
* Author: MASnail
* Created Time: 2016年08月01日 星期一 21时29分30秒
* File Name: /home/lzf/c++/20160801/cow.cc
* Description: C++ file
************************************************************************/
#include "cow.h"

String::String()
    :_pstr(new char[2])
{
    _pstr[0]='\0';
    initRefCnt();
}

String::~String()
{
    descRefCnt();
    if(getRefCnt()==0)
	delete [] _pstr;
}

String::String(const char * rhc)
    :_pstr(new char[strlen(rhc)+1])
{
    strcpy(_pstr,rhc);
    initRefCnt();

}

String::String(const char rhc)
{
   // _pstr[]
}

String::String(const String & rhs)
    :_pstr(rhs._pstr)
{
    increaseRefCnt();
}


String & String::operator=(const String &rhs)
{
    if(this!=&rhs)
    {
	descRefCnt();//清除自己的计数器，使用共享的计数器
	if(0 == getRefCnt())
	    delete [] _pstr;
	_pstr=rhs._pstr;
	increaseRefCnt();
    }
    return *this;
}

#if 1 
char & String::operator[](int idx)
{
   if(idx >= 0 && idx < length()) 
   {
       if(1 == getRefCnt())
	   return _pstr[idx];
       else if(getRefCnt() > 1)
       {
	   descRefCnt();
	   char *tmp=new char[length()+1];
	 ///  strcpy(_pstr,tmp);
	    _pstr=tmp;
	   initRefCnt();
	   return _pstr[idx];
       }
   }
   else
   {
       static char null='\0';
       return null;
   }
}
#endif

#if 1
char & String::operator[](int idx)const
{
   if(idx >= 0 && idx < length()) 
   {
       	return _pstr[idx];   
   }
   else
   {
       static char null='\0';
       return null;
   }
}
#endif

//char * String::c_str()
//{
// return _pstr;
//}

ostream & operator<<(ostream &os,const String &rhs)
{
    return os<<rhs._pstr;
}

void String::initRefCnt()
{
    _pstr[length()+1]=1;
}

void String::descRefCnt()
{
   --_pstr[length()+1];
}

void String::increaseRefCnt()
{
   ++_pstr[length()+1];
}

int String::length()const
{
    return strlen(_pstr);
}

int String::getRefCnt()const
{
    return _pstr[length()+1];
}

#include <iostream>
#include <string>

using namespace std;

void fun(int n)
{
	int index = 0;
	bool ch = true;
	while (n)
	{
		if (n%10)
		{
			cout << n%10;
		}
		n /=10;
		index++;
	}
	cout << endl;
	cout << "The length:" << index << endl;
}

int main()
{
	cout << "100-2-029" << endl;
	cout << "input a count:";
	int a;
	cin >> a;
	fun(a);
	cin.get();
	cin.get();
	return 0;
}
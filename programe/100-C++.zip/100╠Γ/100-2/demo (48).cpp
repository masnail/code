#include <iostream>
#include <string>

using namespace std;

void fun()
{
	cout << "use & (0 & 1: " << (0 & 1) << endl;
	cout << "use | (0 | 1): " << (0 | 1) << endl;
	cout << "use ^ (0 ^ 1): " << (0 ^ 1) << endl;
}

int main()
{
	cout << "100-2-051-52-53" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

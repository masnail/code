#include <iostream>
#include <string>

using namespace std;

void fun(int n)
{
	double sum = 0;
	for (int i = 1; i != n + 1; i++)
	{
		if (i%5==0||i%9==0)
		{
			sum += 1 / (double)i;
		}
	}
	cout << sum << endl;
}

int main()
{
	cout << "100-1-098" << endl;
	cout << "input a count(1-100):";
	int n;
	cin >> n;
	fun(n);
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <string>

using namespace std;

void fun()
{
	int n;
	for (int i = 0; i != 5;i++)
	{
		n = 0;
		if (i==0)
		{
			n = n + 1;
		}
		if (i == 1)
		{
			n = n + 1;
		}
		if (i == 2)
		{
			n = n + 1;
		}
		if (i == 3)
		{
			n = n + 1;
		}
		if (i == 4)
		{
			n = n + 1;
		}
		cout << char(64 + i) << endl;
	}

}

int main()
{
	cout << "100-2-075" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
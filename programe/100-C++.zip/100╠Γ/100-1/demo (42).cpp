#include <iostream>
#include <string>

using namespace std;

void fun(int s[][5],int m)
{
	for (int i = 1; i != 5; i++)
	{
		for (int j = i; j != 5; j++)
		{
			s[i][j]*= m;
		}
	}
}

int main()
{
	cout << "100-1-042" << endl;
	int a[5][5];
	for (int i = 1; i != 5;i++)
	{
		for (int j = 1; j != 5;j++)
		{
			a[i][j] = 1;
		}
	}
	int m;
	cout << "input a m:";
	cin >> m;
	fun(a,m);
	for (int i = 1; i != 5; i++)
	{
		for (int j = 1; j != 5; j++)
		{
			cout<<a[i][j] <<"\t";
		}
		cout << endl;
	}
	cin.get();
	cin.get();
	return 0;
}
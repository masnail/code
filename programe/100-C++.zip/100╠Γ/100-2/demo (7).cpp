#include <iostream>
#include <string>

using namespace std;

void fun()
{
	for (int i = 0; i !=128;i++)
	{
		if (isprint(char(i)))
		cout << char(i) << endl;
	}
}

int main()
{
	cout << "100-2-007" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
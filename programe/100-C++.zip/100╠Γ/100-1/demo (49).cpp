#include <iostream>
#include <string>

using namespace std;

void fun(string s,char *t)
{
	int index = 0;
	while (s[index] != NULL&&index<s.length())
	{
		if (/*index%2==0&&s[index]%2==0||*/index%2==1)
		{
			*t = s[index];
			t++;
		}
		index++;
	}
}

int main()
{
	cout << "100-1-049" << endl;
	cout << "input a string:";
	string s;
	char *t = new char;
	cin >> s;
	fun(s,t);
	while (*t)
	{
		cout << *t;
		t++;
	}
	cin.get();
	cin.get();
	return 0;
}
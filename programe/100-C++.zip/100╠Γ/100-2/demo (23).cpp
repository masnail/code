#include <iostream>
#include <string>

using namespace std;

void fun()
{
	for (int i = 4; i != -1;i--)
	{
		for (int j = i; j != 0;j--)
		{
			cout << " ";
		}
		for (int k = 0; k != (5 - i)*2-1;k++)
		{
			cout << "*";
		}
		cout << endl;
	}
	for (int i = 0; i != 4; i++)
	{
		for (int j = i; j != -1; j--)
		{
			cout << " ";
		}
		for (int k = 0; k != (4 - i) * 2 - 1; k++)
		{
			cout << "*";
		}
		cout << endl;
	}
}

int main()
{
	cout << "100-2-023" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
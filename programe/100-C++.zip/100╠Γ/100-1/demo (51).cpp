#include <iostream>
#include <string>

using namespace std;

bool Primer(int p)
{

	for (int i = 2; i < p / 2; i++)
	{
		if (p%i == 0)
		{
			return false;
		}
	}
	return true;
}

int fun(int mc, int *xx)
{
	int count = 0, index = 1;
	while (index != mc)
	{
		//cout << Primer(index) << endl;
		if (Primer(index))
		{
			*xx = index;
			xx++;
			count++;
			//cout << index << endl;
		}
		index++;
	}
	return count;
}

int main()
{
	cout << "100-1-051" << endl;
	cout << "input a count:";
	int m, *xx = new int, k;
	cin >> m;
	k=fun(m, xx);
	cout << k;

	cin.get();
	cin.get();
	return 0;

}
#include <iostream>
#include <string>

using namespace std;

void fun()
{
	int bo = 1;
	for (int i = 101; i != 201;i++)
	{
		bo = 1;
		for (int j = 2; j != i / 2 + 1;j++)
		{
			if (i%j==0)
			{
				bo = 0;
				break;
			}
		}
		if (bo)
		{
			cout << i << endl;
		}
	}
}

int main()
{
	cout << "100-2-012" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <string>

using namespace std;

void fun()
{
	double high = 100,route=100;
	for (int i = 1; i != 10;i++)
	{
		high /= 2;
		route += high*2;
	}
	cout << "all route:" << route << endl;
	cout << "tenth high:" << high << endl;
}

int main()
{
	cout << "100-2-020" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

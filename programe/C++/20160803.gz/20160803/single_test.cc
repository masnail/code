/*************************************************************************
* Author: MASnail
* Created Time: 2016年08月03日 星期三 23时50分12秒
* File Name: single_test.cc
* Description: C++ file
************************************************************************/
#include <iostream>
#include "singleton_template.h"
using std::cout;
using std::cin;
using std::endl;

class A
{
    public:
	void show()
	{cout<<"AAAAAAAAAA"<<endl;}
	A()
	{cout<<"A()"<<endl;}
	~A()
	{cout<<"~A()"<<endl;}
};

int main(int argc,char *argv[])
{
    //Earth<A> A;
     A  *p=Earth<A>::getInstance();
     A  *p1=Earth<A>::getInstance();
     A  *p2=Earth<A>::getInstance();

     cout<<"p="<<p<<endl;
     cout<<"p1="<<p1<<endl;
     cout<<"p2="<<p2<<endl;

	
     p->show();

    return 0;
}


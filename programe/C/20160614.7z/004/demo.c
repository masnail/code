#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node
{
	int num;
	struct node *next;
}node,*nodelist;

void list_show(nodelist head)
{
	nodelist p = head->next;
	while (p)
	{
		printf("%d ", p->num);
		p = p->next;
	}
}

void list_insert_head(nodelist *head, int num)
{
	nodelist p = (nodelist)malloc(sizeof(node));
	memset(p, 0, sizeof(node));
	p->num = num;
	p->next = (*head)->next;
	(*head)->next = p;
	(*head)->num += 1;
}

int main()
{
	nodelist head = (node *)malloc(sizeof(node)), tail = head;//ͷ���
	head->num = 0;
	head->next = NULL;

	for (int i = 0; i < 10; i++)
		list_insert_head(&head,i);

	list_show(head);

	getchar();
	getchar();
	return 0;
}
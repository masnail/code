#include <iostream>
#include <string>

using namespace std;

void fun()
{

}

int main()
{
	cout << "100-2-062-63-64-65" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

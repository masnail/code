#include <iostream>
#include <string>

using namespace std;

int fun(string s,char index)
{
	int count = 0;
	for (int i = 0; i != s.length();i++)
	{
		if (s[i]==index)
		{
			count++;
		}
	}
	return count;
}

int main()
{
	cout << "100-1-038" << endl;
	char indexchar;
	string ss;
	cout << "input a string:";
	cin >> ss;
	cout << "input a index char:";
	cin>> indexchar;
	cout<<fun(ss, indexchar);
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>

using namespace std;

int main()
{
	int inArr[5][5] = {
		{ 45, 45, 744, 54, 7 },
		{ 2, 12, 45, 6, 3 },
		{ 45, 45, 74, 56, 7 },
		{ 4, 9, 98, 3, 14 },
		{ 6, 56, 68, 5, 68 }
	};
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < i; j++)
		{
			int temp = inArr[i][j];
			inArr[i][j] = inArr[j][i];
			inArr[j][i] = temp;
		}
	}

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			cout<< inArr[i][j]<<"\t";
		}
		cout << endl;
	}
	getchar();
	return 0;
}
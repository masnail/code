#include <iostream>
#include <string>

#include <fstream>

using namespace std;

typedef struct stu
{
	char name[10];
	char num[11];
	int score[3];
	struct stu *next;
}stu,*student;

void fun()
{
	stu *s = (student)malloc(sizeof(stu));
	s->next = NULL;
	student p = s;
	for (int i = 1; i != 6;i++)
	{
		stu *st = (student)malloc(sizeof(stu));
		cout << "input " << i << " student information" << endl;
		cin >> st->name >> st->num;
		for (int j = 0; j != 3;j++)
		{
			cin >> st->score[j];
		}
		st->next = p->next;
		p->next = st;
		p = st;
	}

	ofstream fout("student.txt");

	s = s->next;
	while (s)
	{
		fout << s->num << "||" << s->name << endl;
		for (int j = 0; j != 3; j++)
		{
			fout<<s->score[j]<<endl;
		}
		s = s->next;
	}
}

int main()
{
	cout << "100-2-100" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

/*************************************************************************
* Author: MASnail
* Created Time: 2016年08月01日 星期一 20时07分28秒
* File Name: singleton_v1.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

/*
 *
 * 单例模式
 *
 * 自动释放版本V1.0
 *
 * 实现形式：嵌套类
 *
 * 原理：析构函数的调用条件
 *
 * 栈对象/全局变量/静态变量/堆的时候使用delete或free
 *
 */
class Factory
{
    public:
	static Factory* getInstance()
	{
	    if(_fac==NULL)
		_fac=new Factory;
	    return _fac;
	}
	
    	void create_a()
	{
	    cout<<"A CPU"<<endl;
	}
    class AutoRealse
    {
	public:
	    AutoRealse()
	    {
		cout<<"AutoRealse"<<endl;
	    }
	    ~AutoRealse()
	    {
		cout<<"~AutoRealse()"<<endl;
		if(_fac!=NULL)
		    delete _fac;
	    }
    };
    private:
	Factory()
	{  cout<<"Factory"<<endl; }

	~Factory()
	{ cout<<"~Factory"<<endl;}
    private:
	static Factory * _fac;
	static AutoRealse _autoReal;
};
Factory*  Factory::_fac=NULL;
Factory::AutoRealse Factory::_autoReal;//嵌套类的访问方式
//Factory::AutoRealse(作用域) Factory::_autoReal;(对象)
int main(int argc,char *argv[])
{
    Factory::getInstance()->create_a();
    Factory::getInstance()->create_a();
    
    return 0;


    
}


#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

int Random(int start, int end)
{
	return start + rand() % (end - start + 1);
}

void fun(int a[],int p[])
{
	int index = 0;
	while (index!=1000)
	{
		p[a[index] / 10]++;
		index++;
	}
}


int main()
{
	cout << "100-1-061" << endl;
	srand((unsigned)(time(NULL)));
	int age[1000] = {0};
	for (int i = 0; i != 1000;i++)
	{
		age[i] = Random(0, 130);
		//cout << Random(0, 130) << endl;
	}
	int peolple[11] = {0};
	fun(age,peolple);

	for (int i = 0; i != 11;i++)
	{
		cout << peolple[i] << endl;
	}

	cin.get();
	cin.get();
	return 0;
}
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>

int main()
{

	
	pid_t ret=fork();
//	while(1)
	{
		
		if(ret==0)
		{
			printf("child pid=%d\n",getpid());
		}else
		{
			printf("father pid=%d\n",getpid());
			sleep(1);
		}
	}
	while(1);
	return 0;
}


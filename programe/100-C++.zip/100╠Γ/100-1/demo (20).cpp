#include <iostream>
#define max 256

using namespace std;

bool Primer(int p)
{
	for (int i = 2; i < p / 2;p++)
	{
		if (p%i == 0)
		{
			return false;
		}
	}
	return true;
}

int fun(int lim, int aa[max])
{
	int index = 1,count=0;
	while (index<=lim)
	{
		if (Primer(index))
		{
			aa[count]=index;
			count++;
		}
		index++;
	}
	return count;
}

int main()
{
	cout << "100-1-020" << endl;
	cout << "input min lim:";
	int lim, aa[max] = { 0 };
	cin >> lim;
	fun(lim,aa);
	getchar();
	return 0;
}
/*************************************************************************
 Author:MASnail
 Created Time: 2016年07月05日 星期二 00时05分46秒
 File Name: func_sem.c
 Description: 
 ************************************************************************/
#include "func_sem.h"

int create_sema()
{
	union semun
	{
		int val;
		struct semid_ds *buf;
		unsigned short *array;
	}arg;

	int ret;
	ret = semget(1234,2,IPC_CREAT|0666);
	if(-1 == ret)
	{
		perror("sem_a");
		exit(0);
	}

	unsigned short sem_array[2];
	sem_array[0]=0;
	sem_array[1]=0;
	arg.array=sem_array;
	if(0 != semctl(ret,0,SETALL,arg))
	{
		perror("semctl");
		exit(0);
	}
	return ret;
}

int create_sema_mutex()
{
	union semun
	{
		int val;
		struct semid_ds *buf;
		unsigned short *array;
	}arg;

	int ret;
	ret = semget(1235,1,IPC_CREAT|0666);
	if(-1 == ret)
	{
		perror("sem_a_mutex");
		exit(0);
	}
	unsigned short sem_array[1];
	sem_array[0]=1;
	arg.array=sem_array;
	if(0 != semctl(ret,0,SETALL,arg))
	{
		perror("semctl_mutex");
		exit(0);
	}

	return ret;
}

int create_semb()
{
	union semun
	{
		int val;
		struct semid_ds *buf;
		unsigned short *array;
	}arg;

	int ret;
	ret = semget(4567,2,IPC_CREAT|0666);
	if(-1 == ret)
	{
		perror("sem_b");
		exit(0);
	}
	
	unsigned short sem_array[2];
	sem_array[0]=0;
	sem_array[1]=0;
	arg.array=sem_array;
	if(0 != semctl(ret,0,SETALL,arg))
	{
		perror("semctl");
		exit(0);
	}
	return ret;
}

int create_semb_mutex()
{
	union semun
	{
		int val;
		struct semid_ds *buf;
		unsigned short *array;
	}arg;

	int ret;
	ret = semget(4568,1,IPC_CREAT|0666);
	if(-1 == ret)
	{
		perror("sem_b_mutex");
		exit(0);
	}
	
	unsigned short sem_array[1];
	sem_array[0]=1;
	arg.array=sem_array;
	if(0 != semctl(ret,0,SETALL,arg))
	{
		perror("semctl_mutex");
		exit(0);
	}
	return ret;
}

void create_sembufp(struct sembuf *soppr,struct sembuf *soppw)
{

	(*soppr).sem_op=-1;
	(*soppr).sem_flg=SEM_UNDO;
	(*soppr).sem_num=0;

	(*soppw).sem_op=-1;
	(*soppw).sem_flg=SEM_UNDO;
	(*soppw).sem_num=1;

}

void create_sembufv(struct sembuf *sopvr,struct sembuf *sopvw)
{

	(*sopvr).sem_op=1;
	(*sopvr).sem_flg=SEM_UNDO;
	(*sopvr).sem_num=0;

	(*sopvw).sem_op=1;
	(*sopvw).sem_flg=SEM_UNDO;
	(*sopvw).sem_num=1;

}

void create_sembufpv(struct sembuf *sopp,struct sembuf *sopv)
{

	(*sopp).sem_op=-1;
	(*sopp).sem_flg=SEM_UNDO;
	(*sopp).sem_num=0;

	(*sopv).sem_op=1;
	(*sopv).sem_flg=SEM_UNDO;
	(*sopv).sem_num=0;
}

void delete_sem(int semid)
{
	int ret;
	ret = semctl(semid,0,IPC_RMID);
	if(-1 == ret)
	{
		perror("semctl");
		exit(0);
	}
}


#include <iostream>
#include <string>

using namespace std;

typedef struct node 
{
	double score;
	struct node *next;
}node,*linknode;

double fun(linknode h)
{
	double count = 0, sum = 0;
	linknode p = h->next;
	while (p)
	{
		sum += p->score;
		p = p->next;
		count++;
	}
	//cout << sum << endl;
	if (count==0)
	{
		return 0;
	}
	return sum / count;
}

int main()
{
	cout << "100-1-085" << endl;
	linknode h = (linknode)malloc(sizeof(node));
	h->next = NULL;
	double score[] = { 85, 76, 69, 85, 91, 72, 64, 87,-1};
	int index = 0;
	while (score[index]!=-1)
	{
		//cout << score[index] <<endl;;
		linknode p = (linknode)malloc(sizeof(node));
		p->score=score[index];
		p->next = h->next;
		h->next = p;
		index++;
	}
	//fun(h);
	cout<<fun(h);
	cin.get();
	cin.get();
	return 0;
}

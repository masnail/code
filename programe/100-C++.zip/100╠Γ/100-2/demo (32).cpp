#include <iostream>
#include <string>

using namespace std;

void fun()
{
	system("color 01");
}

int main()
{
	cout << "100-2-032" << endl;
	cout << "Press any key to change color, do you want to try it. Please hurry up!" << endl;
	cin.get();
	fun();
	cin.get();
	cin.get();
	return 0;
}
/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月21日 星期四 19时40分50秒
* File Name: struct.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

struct struct_st
{ 
    int num;
    
    void show()
    { 
	cout<<"struct function"<<endl;
	cout<<"struct the num="
	    <<num<<endl;
    }
};

int main(int argc,char *argv[])
{
    struct_st st;
    st.show();

    st.num=89;
    st.show();
    return 0;
}


/*************************************************************************
 Author:0054
 Created Time: 2016年07月12日 星期二 15时26分31秒
 File Name: head.h
 Description: 
 ************************************************************************/
#ifndef HEAD_H
#define HEAD_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/epoll.h>
#include <fcntl.h>
#include <string.h>
#include <sys/epoll.h>

#define SIZE_BUFF 512
#define SIZE_CONNECT 3 
#define SIZE_PROC 1 
#define SIZE_PATH_NAME 50

#define PATH "test"
#define PATH_CONFIGURE "./config"

typedef struct 
{
	int pid;
	int busy;
	int fdw;
}proc;

int send_msg(int,int);

int recv_msg(int,int*);

#endif

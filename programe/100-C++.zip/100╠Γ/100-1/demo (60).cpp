#include <iostream>
#include <string>

using namespace std;

int fun(int arr[])
{
	int data=0,count=0,index=0;
	int *ch=new int,*p=ch;
	*ch = arr[index];
	while (index<11)
	{
		if (arr[data]!=arr[index])
		{
			ch++;
			*ch = arr[index];
			count++;
			data = index;
		}
		else
		{
			index++;
		}
	}

	index = 0;
	while (index!=count+1)
	{
		cout << *p<<" ";
		p++;
		index++;

	}

	cout << endl;
	return count+1;
}

int main()
{
	cout << "100-1-060" << endl;
	int arr[] = {11,55,55,87,88,88,90,90,90,90,91};
	cout<<fun(arr);
	cin.get();
	cin.get();
	return 0;
}

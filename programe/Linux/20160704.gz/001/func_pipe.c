/*************************************************************************
 Author:MASnail
 Created Time: 2016年07月04日 星期一 18时48分42秒
 File Name: func_pipe.c
 Description: 
 ************************************************************************/
#ifndef FUNC_PIPE_H
#define FUNC_PIPE_H

#include "func_pipe.h"

void create_pipe()
{
	int ret;
	ret = mkfifo("1",0666);
	/*if(-1 == ret)
	{
		perror("mkfifo");
		return ;
	}*/

	ret = mkfifo("2",0666);
	/*	if(-1 == ret)
	{
		perror("mkfifo");
		return ;
	}*/

}

void delete_pipe()
{
	int ret;
	ret = unlink("1");
	if(-1 == ret)
	{
		perror("unlink");
	}
	ret = unlink("2");
	if(-1 == ret)
	{
		perror("unlink");
	}
}

void create_timebuff(char **buff)
{
	//get send data time
	time_t timer;
	struct tm *timerinfo;
	char time_buff[20];
	memset(time_buff,0,sizeof(time_buff));

	time(&timer);
	timerinfo = localtime(&timer);
	
	strftime(time_buff,sizeof(time_buff),"%H:%M:%S",timerinfo);
	
	memcpy(*buff,time_buff,strlen(time_buff));
}

#endif

/*************************************************************************
 Author:MASnail
 Created Time: 2016年07月04日 星期一 19时26分10秒
 File Name: func_pipe.h
 Description: 
 ************************************************************************/
#include "head.h"

void create_pipe();

void delete_pipe();

void delete_pipe();

void create_timebuff(char**);

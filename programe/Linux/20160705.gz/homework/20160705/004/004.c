#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

pthread_cond_t cond;
pthread_mutex_t mutex;

void* func_pth(void *p)
{
	printf("come child waiting ....\n");
	printf("three seconds wake up child!\n");
	pthread_cond_wait(&cond,&mutex);
	printf("now,child thread not run\n");
	pthread_exit(NULL);
}

int main()
{
	pthread_t pth;
	pthread_mutex_init(&mutex,NULL);
	pthread_cond_init(&cond,NULL);
	pthread_create(&pth,NULL,func_pth,NULL);
	
	sleep(3);
	pthread_cond_signal(&cond);
	printf("child thread wake up now!\n");

	return 0;
}


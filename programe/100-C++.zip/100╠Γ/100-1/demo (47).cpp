#include <iostream>
#include <string>

using namespace std;

void fun(char *ss)
{
	int index=0;
	while (*ss)
	{
		if (isalpha(*ss)&&index%2==1)
		{ 
			*ss =toupper(*ss);
		}
		index ++;
		ss++;
	}
}

int main()
{
	cout << "100-1-047" << endl;
	char ss[] = "awesssd0ppoimlmsdfij-*-54464*66546-45645643--mvdnnkjdzfniuaskiujkweuijkcsdnjk";
	
	fun(ss);

	int index = 0;
	while (ss[index])
	{
		cout << ss[index];
		index++;
	}
	cin.get();
	cin.get();
	return 0;
}
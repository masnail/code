#include <iostream>

using namespace std;

int fun(int m,int *p)
{
	int count = 0,index=1;
	while (index <= m)
	{
		if (index % 7 == 0||index%11==0)
		{
			*p = index;
			p++;
			count++;
		}
		index++;
	}

	return count;
}

int main()
{
	cout << "100-1-027" << endl;
	cout << "input:";
	int m, *p = new int;
	cin >> m;
	cout<<fun(m, p);
	cin.get();
	cin.get();
	return 0;
}
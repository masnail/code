#include <iostream>
#include <windows.h>
#include <conio.h>

using namespace std;

HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
HANDLE hIn = GetStdHandle(STD_INPUT_HANDLE);
void gotoxy(int x, int y)
{
	COORD pos = { x, y };
	SetConsoleCursorPosition(hOut, pos);
}

void fun()
{
	int a;
	cout << "-*********                    *********- ";
	gotoxy(15,1);
	cin >> a;
}

int main()
{
	cout << "100-2-033" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>

using namespace std;

void fun()
{
	ifstream fa("A.txt");
	ifstream fb("B.txt");

	ofstream fout("AB.txt");

	string sa, sb;
	fa >> sa;
	fb >> sb;

	int indexa = 0, indexb = 0;

	for (int i = 0; i != sa.length();i++)
	{
		indexa = i;
		for (int j = i+1; j != sa.length();j++)
		{
			if (sa[indexa]>sa[j])
			{
				indexa = j;
			}
		}
		char st=sa[indexa];
		sa[indexa] = sa[i];
		sa[i] = st;
	}

	for (int i = 0; i != sb.length(); i++)
	{
		indexb = i;
		for (int j = i + 1; j != sb.length(); j++)
		{
			if (sb[indexb] > sb[j])
			{
				indexb = j;
			}
		}
		char st = sb[indexb];
		sb[indexb] = sb[i];
		sb[i] = st;
	}
	
	indexa = 0, indexb = 0;
	while (sa[indexa]&&sb[indexb])
	{
		if (sa[indexa]<sb[indexb])
		{
			fout << sa[indexa];
			indexa++;
		}
		else
		{
			fout << sb[indexb];
			indexb++;
		}
	}
	cout << indexa << ":" << indexb;
	if (sa[indexa])
	{
		for (int i = indexa; i != sa.length();i++)
		{
			fout << sa[i];
		}
	}

	if (sb[indexb])
	{
		for (int i = indexb; i != sb.length(); i++)
		{
			fout << sb[i];
		}
	}

	cout << "������ɡ���" << endl;
}

int main()
{
	cout << "100-2-099" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

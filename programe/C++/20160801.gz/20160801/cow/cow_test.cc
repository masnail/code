/*************************************************************************
* Author: MASnail
* Created Time: 2016年08月01日 星期一 22时09分18秒
* File Name: /home/lzf/c++/20160801/cow_test.cc
* Description: C++ file
************************************************************************/
#include "cow.h" 

int test()
{
    String s="hello";
    String s1=s;
    const String s2=s;
    String s3=s;
    cout<<"s ="<<s<<":"<<s.getRefCnt()<<endl;
    cout<<"s1="<<s1<<":"<<s1.getRefCnt()<<endl;
    cout<<"s2="<<s2<<":"<<s2.getRefCnt()<<endl;
    cout<<"s3="<<s3<<":"<<s3.getRefCnt()<<endl;
    cout<<"**************************************"<<endl;
    s2[2];
    s3[3]='H';
    cout<<"s2 :"<<s2.getRefCnt()<<endl;
    cout<<"s3 :"<<s3.getRefCnt()<<endl;
    cout<<"s  :"<<s.getRefCnt()<<endl;
    String s5;
    cout<<s5.length()<<endl;

    return 0;
}

int main()
{
    test();
    return 0;
}

/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月22日 星期五 19时41分41秒
* File Name: computer.cc
* Description: C++ file
************************************************************************/

#include <string.h>
#include <stdio.h>

#include <iostream>

using std::cout;
using std::cin;
using std::endl;

class computer
{
public:
    computer(const char *brand,float fprice);
#if 0   //浅拷贝
    computer(const computer &rhs)
	:_brand(rhs._brand)
	 ,_fprice(_fprice)
    {	}
#endif

    //深拷贝
    computer(const computer &rhs);
    ~computer();
    void print();
    float getPrice();
    void setBrand(const char *brand);
    void setPrice(float price);
private:
    char *_brand;
    float _fprice;
};

computer::computer(const char *brand,float fprice)
	:_fprice(fprice)
    {
	_brand=new char[strlen(brand)+1];
	strcpy(_brand,brand);
    }
#if 0   //浅拷贝
computer::computer(const computer &rhs)
	:_brand(rhs._brand)
	 ,_fprice(_fprice)
    {	}
#endif

    //深拷贝
computer:: computer(const computer &rhs)
	:_fprice(rhs._fprice)
    {
	_brand=new char[strlen(rhs._brand)+1];
	strcpy(_brand,rhs._brand);
    }
    
computer:: ~computer()
    {
	delete [] _brand;
    }
void computer::print()
{
    cout<<"brand="<<_brand<<endl;
    cout<<"price="<<_fprice<<endl;
}

float  computer::getPrice()
{
    return _fprice;
}

void computer::setBrand(const char *brand)
{
    _brand=new char[strlen(brand)+1];
    strcpy(_brand,brand);
}

void computer::setPrice(float price)
{
    _fprice=price;
}

int main(int argc,char *argv[])
{
    computer pc1("LENOVO",4999);
    pc1.print();

    computer pc2=pc1;
    pc2.setBrand("LENOVO_y470");
    pc2.setPrice(pc2.getPrice()-500);
    pc2.print();
   return 0; 
}


/*************************************************************************
 Author:MASnail
 Created Time: 2016�?7�?4�?星期一 17�?3�?0�?
 File Name: b_input.c
 Description: 
 ***********************************************************************/
#include "head.h"
#include "func_shm.h"
#include "func_pipe.h"
#include "func_sem.h"

int fdr,fdw;
unsigned int a_pid;
//process exit SIGINT
void func_exit()
{
	//clean buff
	//close file open
	close(fdr);
	close(fdw);
	//delete shm
	int shmid;
	char *p;
	create_shmb(&shmid,&p);
	int ret = shmctl(shmid,IPC_RMID,NULL);
	if(-1 == ret)
	{
		perror("shmctl");
	}
	int semid=create_semb();
	delete_sem(semid);
	semid=create_semb_mutex();
	delete_sem(semid);


	//kill process
	kill(a_pid,SIGINT);
	exit(0);
}
int main()
{
	//signal
	signal(SIGINT,func_exit);

	//getpid
	unsigned int b_pid=getpid();
	//create pipe
	create_pipe();

	//create shm
	int shmid;
	char *p;
	create_shmb(&shmid,&p);

	//sem init
	int semid = create_semb();
	struct sembuf sopvw,sopvr;
	create_sembufv(&sopvr,&sopvw);

	int semid_mutex = create_semb_mutex();
	struct sembuf sopp,sopv;
	create_sembufpv(&sopp,&sopv);
	//	printf("B semid=%d-semid_mutex=%d:sem0 %d|sem1 %d|mutex %d\n",semid,semid_mutex,semctl(semid,0,GETVAL),semctl(semid,0,GETVAL),semctl(semid_mutex,0,GETVAL));

	//open pipe
	int ret;
	fdw = open("1",O_WRONLY);
	if(-1 == fdw)
	{
		perror("open_1");
		exit(0);
	}
	fdr = open("2",O_RDONLY);
	if(-1 == fdr)
	{
		perror("open_2");
		exit(0);
	}

	//swap pid
	char buff[MAX];
	memset(buff,0,sizeof(buff));
	sprintf(buff,"%u",b_pid);
	write(fdw,buff,strlen(buff));
	memset(buff,0,sizeof(buff));
	read(fdr,buff,sizeof(buff));
	a_pid=(unsigned)atoi(buff);

	//link a_input from pipe
	fd_set set;

	while(1)
	{
	FD_ZERO(&set);
	FD_SET(0,&set);
	FD_SET(fdr,&set);
	ret = select(fdr+1,&set,NULL,NULL,0);
	if(-1 == ret)
	{
		//write read error
		break;
	}
	if(FD_ISSET(fdr,&set))
	{
		//receive data
		memset(buff,0,sizeof(buff));
		read(fdr,buff,sizeof(buff));
		//push b_push
		semop(semid_mutex,&sopp,1);//mutex shm
		semop(semid,&sopvr,1);
		memset(p,0,SIZE_MEM);
		memcpy(p,buff,strlen(buff)-1);
	//	printf("B-write semid=%d-semid_mutex=%d:sem0 %d|sem1 %d|mutex %d\n",semid,semid_mutex,semctl(semid,0,GETVAL),semctl(semid,0,GETVAL),semctl(semid_mutex,0,GETVAL));
	//	semop(semid_mutex,&sopv,1);//mutex shm
	}
	if(FD_ISSET(0,&set))
	{
		//send data
		memset(buff,0,sizeof(buff));
		read(0,buff,sizeof(buff));
		write(fdw,buff,strlen(buff));

		semop(semid_mutex,&sopp,1);//mutex shm
		semop(semid,&sopvw,1);
		memset(p,0,SIZE_MEM);
		memcpy(p,buff,strlen(buff)-1);
	//	printf("B-read semid=%d-semid_mutex=%d:sem0 %d|sem1 %d|mutex %d\n",semid,semid_mutex,semctl(semid,0,GETVAL),semctl(semid,0,GETVAL),semctl(semid_mutex,0,GETVAL));
	//	semop(semid_mutex,&sopv,1);//mutex shm
	}
	}
}



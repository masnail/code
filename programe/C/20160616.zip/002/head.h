#ifndef HEAD_H
#define HEAD_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 4096
#define CHMAX 30

typedef struct word
{
	char name[30];
	int cnt;//ͷ����д洢����
	struct word *next;
}wd,*wdlist;

static long int characnt = 0;
void list_word(wdlist);
void File_read(char[]);
void count_chara(char*);
void insert_wdlist(wdlist*, char[], int);
void word_div_func(wdlist*, char[]);
int Get_chara_count();
int Get_col_count(wdlist);
int Get_word_count(wdlist);
int compare(const void*, const void*);
void sort_word(wdlist*);


#endif
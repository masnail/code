/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月27日 星期三 08时14分22秒
* File Name: queue.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

class Queue
{
    public:
	Queue(int capa);
	~Queue();
	void EnQueue(int a);
	void DelQueue();
	int front();
	int back();
	bool empty();
	bool full();
    private:
	int _head;
	int _tail;
	int _capacity;
	int * _Arr;
};

Queue::Queue(int capa=10)
    :_head(-1)
     ,_tail(-1)
     ,_capacity(capa)
{   
    _Arr=new int[_capacity];
}

Queue::~Queue()
{
    delete [] _Arr;
}

void Queue::EnQueue(int a)
{
    if(_tail<_capacity)
    {
	 _Arr[++_tail]=a;
    }
    if(_head==-1)
	_head=0;
}

void Queue::DelQueue()
{
    if(_head!=-1&&_head<=_tail)
    {
	cout<<"DelQueue："<<_Arr[_head--]<<endl;
    }
}

int Queue::front()
{
    if(_head==-1)
	return (unsigned)-2147483647;
    cout<<"front:"<<_Arr[_head]<<endl;
    return _Arr[_head];
}

int Queue::back()
{
    if(_tail==-1)
	return (unsigned)-2147483647;
    cout<<"back："<<_Arr[_tail]<<endl;
    return _Arr[_tail];
}

bool Queue::empty()
{
    if(_head==-1)
	return true;
    return false;
}

bool Queue::full()
{
    if(_tail==_capacity-1)
	return true;
    return false;
}

int main(int argc,char *argv[])
{
    Queue que;
    que.EnQueue(12);
    que.EnQueue(34);
    que.front();
    que.back();
    return 0;
}


/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月22日 星期五 21时07分37秒
* File Name: point.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;


/*
 * 
 * 常量函数
 *
 *
 */
class point
{
public:
    point(int ix,int iy);
    void print();
    //运算符重载
    friend void operator -(const point &rhl,const point &rhr);//友元函数
    //复制构造函数
     point (const point &rhs)
	 :_ix(rhs._ix)
	  ,_iy(rhs._iy)
     {
	cout<<"already copy point"<<endl;
     }
     void show() const
     {
	 cout<<"this is const function"<<endl;
	 cout<<"只能访问const成员函数"<<endl;
     }

private:
    int _ix;
    int _iy;
};

point::point(int ix,int iy)
{
    _ix=ix;
    _iy=iy;
}
void point::print()
{
    cout<<"( "<<_ix
	<<","<<_iy
	<<" )"<<endl;
}

void operator -(const point &rhs,const point &rhr)
{
    cout<<"point & operator -"<<endl;
   int x= rhs._ix-rhr._ix;
   int y=rhs._iy-rhr._iy;
   cout<<"point  - pointi="<< x*x+y*y<<endl;
}
int main(int argc,char *argv[])
{
    point p1(2,4);
    point p2(4,5);
    p1.print();
    p2.print();
  //  p1-p2;
  //  cout<<p1-p2<<endl;
    point p3=p2;
    p3.print();
    p3.show();
    return 0;
}


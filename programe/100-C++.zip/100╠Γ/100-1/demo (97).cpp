#include <iostream>
#include <string>

using namespace std;

void fun(int n)
{
	double s = 0,index=1,low=0;
	while (index!=n+1)
	{
		low += index;
		s += 1 / low;
		index++;
	}
	cout << s << endl;
}

int main()
{
	cout << "100-1-097" << endl;
	cout << "input a count:";
	int n;
	cin >> n;
	fun(n);
	cin.get();
	cin.get();
	return 0;
}

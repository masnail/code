#include <iostream>
#include <string>

using namespace std;

void fun(int a,int n)
{
	int index = 1,sum=0,temp=a;
	while (index!=n+1)
	{
		sum += temp;
		index++;
		temp = temp + temp * 10;
	}
	cout << sum << endl;
}

int main()
{
	cout << "100-2-018" << endl;
	int n, a;
	cout << "digit:";
	cin >> a;
	cout << "number:";
	cin >> n;
	fun(a,n);
	cin.get();
	cin.get();
	return 0;
}

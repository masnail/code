#include <iostream>
#include <string>

using namespace std;

typedef struct node
{
	int data;
	struct node *prior;
	struct node *next;
}node,*linknode;

void fun(int n)
{
	linknode head = (linknode)malloc(sizeof(node)), p = head,q;//p->head

	head->next = head;
	head->prior = head;
	head->data = 1;

	while (n)
	{
		q = (linknode)malloc(sizeof(node));
		q->data = n % 10;
		//link
		p->next = q;
		q->prior = p;
		head->prior = q;
		q->next = head;
		p = q;
		n /= 10;
	}

	//////////////////////////////////////////////////////////////////////////
	
	q = head->next;
	p= head->prior;
	while (p!=q)
	{
		//cout << p->data <<":"<< q->data << endl;
		if (p->data!=q->data)
		{
			head->data = 0;
		}
		p = p->prior;
		q = q->next;
	}
	if (head->data)
	{
		cout << "YES!" << endl;
	}
	else
	{
		cout << "NOT!" << endl;

	}

	while (head->next!=head)
	{
	linknode pp = head;
	head->prior->next = head->next;
	head->next->prior = head->prior;
	head = head->next;
	delete pp;
	}
}

int main()
{
	cout << "100-2-030" << endl;
	cout << "input a count:";
	int a;
	cin >> a;
	fun(a);
	cin.get();
	cin.get();
	return 0;
}
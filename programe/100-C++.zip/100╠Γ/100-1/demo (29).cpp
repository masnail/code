#include <iostream>
#include <string>

using namespace std;

void fun(string ss)
{
	for (int i = 1; i < ss.length();i++, i++)
	{
		if (isalpha(ss[i]))
		{
			ss[i]=toupper(ss[i]);
		}
	}
	cout << ss << endl;
}

int main()
{
	cout << "100-1-029" << endl;
	cout << "input:";
	string ss;
	cin >> ss;
	fun(ss);
	cin.get();
	cin.get();
	return 0;
}

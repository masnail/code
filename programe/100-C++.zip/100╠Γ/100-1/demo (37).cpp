#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

typedef struct 
{
	char num[11];
	double sxs;
	double yys;
	double ehs;
	double hxs;
	double wls;
	double sws;
	double dls;
	double lss;
	double ave;
}student,*stu;

void fun(student *s)
{
	double sum = 0;
	sum = s->ehs + s->hxs + s->lss + s->sws + s->sxs + s->wls + s->yys + s->dls;
	s->ave = sum / 8;
}

int main()
{
	cout << "100-1-037" << endl;
	student *score = (stu)malloc(sizeof(student));
	*score = {"2011101111",89,87,87,96,90,75,82,80,0};
	fun(score);
	cout << setprecision(2)<<fixed << score->ave;
	cin.get();
	cin.get();
	return 0;
}

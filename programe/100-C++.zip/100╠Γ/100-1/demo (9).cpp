#include <iostream>

using namespace std;

double fun(int m,int n)
{
	int sub = m - n,mm=1,nn=1,ss=1;
	 while (m!=1)
	 {
		 mm *= m;
		 m--;
	 }
	 while (n != 1)
	 {
		 nn *= n;
		 n--;
	 }
	 while (sub != 1)
	 {
		 ss *= sub;
		 sub--;
	 }
	 return mm / (sub*nn);
}
int main()
{
	cout << "����M��N����ֵ��";
	int m, n;
	cin >> m >> n;
	if (m>n)
	{
		cout << "p=m!/n!(m-n)!" << fun(m, n) << endl;;
	} 
	else
	{
		cout << "��ȷ��M��ֵ����N��ֵ��" << endl;
		main();
	}
	getchar();
	return 0;
}
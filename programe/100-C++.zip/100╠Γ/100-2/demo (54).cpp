#include <iostream>
#include <string>

using namespace std;

void fun(int a,int b,int c)
{
	int temp;

	if (a>b)
	{
		temp = a;
		a = b;
		b = temp;
	}

	if (a > c)
	{
		temp = a;
		a = c;
		c = temp;
	}
	
	if (b > c)
	{
		temp = b;
		b = c;
		c = temp;
	}

	cout << a << ":" << b << ":" << c << endl;
}

int main()
{
	cout << "100-2-066" << endl;
	cout << "input three count:";
	int a, b, c;
	cin >> a >> b >> c;
	fun(a,b,c);
	cin.get();
	cin.get();
	return 0;
}

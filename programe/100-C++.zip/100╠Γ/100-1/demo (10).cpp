#include <iostream>
#include <cmath>
using namespace std;

double fun()
{
	double x0 = 0;
	double x1 = cos(x0);
	while (fabs(x1 - x0)>0.000001)
	{
		x0 = x1;
		x1 = cos(x0);
	}
		return x0;
}

int main()
{
	cout << "root="<<fun();
	getchar();
	return 0;
}
#include <iostream>
#include <fstream>
#include <numeric>

#define MAX 256
using namespace std;

void fun()
{
	cout << "��̻���100-001" << endl;
	ifstream cin("aaa.txt");
	int score[MAX], below[MAX], a, index = 0, temp = 0, sum = 0;
	while (cin >> a)
	{
		score[index++] = a;
	}

	accumulate(score, score + index, sum);

	for (int i = 0; i < index; i++)
	{
		if (score[i] < double(sum / index))
		{
			below[temp++] = score[i];
		}
	}


}
int main()
{
	fun();
	system("pause");
	return 0;
}
#include <iostream>
#include <string>

using namespace std;

void fun(double a[])
{
	double sum = 0;
	for (int i = 0; i != 8; i++)
	{
		sum += sqrt((a[i]+a[i+1])/2);
	}
	cout << sum << endl;
}

int main()
{
	cout << "100-1-096" << endl;
	double a[9] = {12,34,4,23,34,45,18,3,11};
	fun(a);
	cin.get();
	cin.get();
	return 0;
}

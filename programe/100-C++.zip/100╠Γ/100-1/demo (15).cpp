#include <iostream>
#include <cmath>

using namespace std;


unsigned  fun(unsigned  w)
{
	if (w<10)
	{
		cout << "Error!" << endl;
	}
	else
	{
		int temp = 0;
		while (w)
		{
			temp++;
			w /=10;
		}
		temp = pow(10, temp - 1);
		return temp;

	}
}

int main()
{
	cout << "100-1-015" << endl;
	int w;
 	cin >> w;
	//cout<< fun(w);
	cout << w%fun(w) << endl;
	cin.get();
	return 0;
}
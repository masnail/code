#include "Search_Student.h"



//ѧ������ѧ�š����䡢�ɼ���

void Search_Compare_Num(const void *p, const void *q)//��ѧ����ѧ������
{
	stulist *pw = (stulist*)p;
	stulist *qw = (stulist*)q;
	return (*pw)->num-(*qw)->num;
}

void Search_Compare_Age(const void *p, const void *q)//��ѧ������������
{
	stulist *pw = (stulist*)p;
	stulist *qw = (stulist*)q;
	int page = atoi((*pw)->age);
	int qage = atoi((*qw)->age);
	return page-qage;
}

void Search_Compare_Score(const void *p, const void *q)//ѧ���ĵ��Ƴɼ�����
{
	stulist *pw = (stulist*)p;
	stulist *qw = (stulist*)q;

	return ((*pw)->score[one_score] < (*qw)->score[one_score]) ?1:- 1;
}

void Search_Compare_Score_All(const void *p, const void *q)//ѧ�����ܳɼ�����
{
	stulist *pw = (stulist*)p;
	stulist *qw = (stulist*)q;
	int fr = 0, se = 0;
	for (int i = 0; i < 5;i++)
	{
		fr += (*pw)->score[i];
		se += (*qw)->score[i];
	}
		
	return fr<se?1:-1;
}

void Search_Student_Show(int num, int score)//������ʾѧ������Ϣ
{
	stulist head = Get_stu_Head();
	//1-num 2-age 3-score(0---4) 4-scoreALL
	int length = head->num;
	const char *sort_show[] = {
		"first course sort",
		"second course sort",
		"third course sort",
		"fourth course sort",
		"fifth course sort",
		"all course sort"
	};

	stulist *p = (stulist *)malloc(length*sizeof(stulist)), pArr = head->next;

	int index = 0;
	while (pArr)
	{
		*(p + index++) = pArr;
		pArr = pArr->next;
	}

	//�����������
	switch (num)
	{
	case 1:/*qsort(p, length, sizeof(stulist *), Search_Compare_Num);*/ break;
	case 2:qsort(p, length, sizeof(stulist*), Search_Compare_Age); break;
	case 3:one_score = score; qsort(p, length, sizeof(stulist*), Search_Compare_Score); break;
	case 4:qsort(p, length, sizeof(stulist*), Search_Compare_Score_All); break;
	}



	if (num==3)
	{
		printf("\t%s:\n", sort_show[score]);
	}else if (num==4){
		printf("\t%s:\n", sort_show[5]);
	}
	printf(STU_HEAD);
	for (int i = 0; i < length; i++)
	{
		printf(STU_FORMAT_IN, STU_FORMAT);
	}
	free(p);
}
/*
*
*
* ѧ�����ң�ѧ�š����䡢�ɼ���
*
*
*/

void Search_Student_Num()//��ѧ����ѧ�Ų���
{
	int num=0;
	stulist head = Get_stu_Head();
	stulist p = head->next;

	printf("Input a num: ");
	scanf("%d", &num);
	
	printf(STU_HEAD);
	while (p)
	{
		if (num==p->num)
		{
			printf(STU_FORMAT_IN, STU_FORMAT_OUT);
			return;
		}
		p = p->next;
	}
	printf("\tsorry,I have not this information!\n");
}

int Search_StudentNum(int num)//��ѧ����ѧ�Ų���
{
	stulist head = Get_stu_Head();
	stulist p = head->next;

	printf(STU_HEAD);
	while (p)
	{
		if (num == p->num)
		{
			printf(STU_FORMAT_IN, STU_FORMAT_OUT);
			return 1;
		}
		p = p->next;
	}
	return 0;
}

void Search_Student_Name()//��ѧ������������
{
	char name[20] = { 0 };
	stulist head = Get_stu_Head();
	stulist p = head->next;
	int index = 0;

	printf("\tInput a name: ");
	scanf("%s", name);
	
	printf(STU_HEAD);
	while (p)
	{
		if (0 == strcmp(name,p->name))
		{
			printf(STU_FORMAT_IN, STU_FORMAT_OUT);
			index = 1;
			//return;
		}
		p = p->next;
	}
	if (0==index)
	{
		printf("\tsorry,I have not this information!\n");
	}
}

void Search_Student_All()//��ѧ�����������
{
	stulist head = Get_stu_Head();
	stulist p = head->next;
	int index = 0;
	
	printf(STU_HEAD);
	while (p)
	{
		printf(STU_FORMAT_IN, STU_FORMAT_OUT);
		index = 1;
		//return;
		p = p->next;
	}
	if (0 == index)
	{
		printf("\tsorry,I have not this information!\n");
	}
}

void Search_Student_Score( int num, int score)//ѧ���ĵ��Ƴɼ�����
{
	stulist head = Get_stu_Head();
	stulist p = head->next;
	int index = 0;

	printf(STU_HEAD);
	while (p)
	{
		if (score == p->score[num])
		{
			printf(STU_FORMAT_IN, STU_FORMAT_OUT);
			index = 1;
			//return;
		}
		p = p->next;
	}
	if (0 == index)
	{
		printf("\tsorry,I have not this information!\n");
	}
}
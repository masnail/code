#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NUM 5

typedef struct student
{
	char num[20];
	char name[20];
	double score1;
	double score2;
	double score3;
	double allscore;
}student; 

void ShowStudent(student stu[],int num,int rank)
{
	int count = 0;
	while (count<num)
	{
		if (rank==0)
		{
		printf("%s\t%s\t%5.2f\t%5.2f\t%5.2f\n", stu[count].num, stu[count].name, stu[count].score1, stu[count].score2, stu[count].score3);
		}else if (rank==1)
		{
			printf("��%d  %s\t%s\t%5.2f\t%5.2f\t%5.2f\n",count+1, stu[count].num, stu[count].name, stu[count].score1, stu[count].score2, stu[count].score3);
		}
		count++;
	}
}

void SortStudent(student stu[],int num)
{
	for (int i = 0; i < num;i++)
	{
		for (int j = i; j < num;j++)
		{
			if (strcmp(stu[j].num,stu[i].num)==1)
			{
				student stemp = stu[j];
				stu[j] = stu[i];
				stu[i] = stemp;
			}
		}
	}
	ShowStudent(stu, num,0);
}

void GetTheScore1(student stu[], int num)
{
	student st = stu[0];
	for (int i = 1; i < num; i++)
	{
		if (st.score1<stu[i].score1)
		{
			st = stu[i];
		}
	}
	ShowStudent(&st, 1, 0);
}

void GetTheScore2(student stu[], int num)
{
	student st = stu[0];
	for (int i = 1; i < num; i++)
	{
		if (st.score2 < stu[i].score2)
		{
			st = stu[i];
		}
	}
	ShowStudent(&st, 1, 0);
}

void GetTheScore3(student stu[], int num)
{
	student st = stu[0];
	for (int i = 1; i < num; i++)
	{
		if (st.score3 < stu[i].score3)
		{
			st = stu[i];
		}
	}
	ShowStudent(&st, 1, 0);
}

void GetTheScore(student stu[], int num, void (*func)(student[], int))
{
	func(stu, num);
}

void GetAveScore(student stu[], int num)
{
	 int s1 = 0, s2 = 0, s3 = 0;
	for (int i = 0; i < num;i++)
	{
		s1 += stu[i].score1;
		s2 += stu[i].score2;
		s3 += stu[i].score3;
	}

	s1 /= num;
	s2 /= num;
	s3 /= num;
	printf("score1 ave is %d\n", s1);
	printf("score2 ave is %d\n", s2);
	printf("score3 ave is %d\n", s3);
}

void GetOrderScore(student stu[], int num)
{
	for (int i = 0; i < num;i++)
	{
		stu[i].allscore = stu[i].score1 + stu[i].score2 + stu[i].score3;
	}

	for (int i = 0; i < num; i++)
	{
		for (int j = i; j < num; j++)
		{
			if (stu[i].allscore<stu[j].allscore)
			{
				student stemp = stu[j];
				stu[j] = stu[i];
				stu[i] = stemp;
			}
		}
	}
	ShowStudent(stu, num,1);
}
void MenuInfo(student stu[])
{
	printf("************************************************\n");
	printf("**    1��ѧ�ŵ������ѧ����Ϣ                     \n");
	printf("**    2���γ���߷ֵ�ѧ����Ϣ                     \n");
	printf("**    3��ÿ�ſγ̵�ƽ����                        \n");
	printf("**    4��ѧ������                               \n");
	printf("**    5���˳�                                  \n");
	printf("**                                            \n");
	printf("************************************************\n");
	printf("**    ���������ѡ��");
	int cnt;
	scanf("%d", &cnt);
	switch (cnt)
	{
	case 1:
		SortStudent(stu, NUM);
		MenuInfo(stu);
		break;
	case 2:
		GetTheScore(stu, NUM, GetTheScore1);
		GetTheScore(stu, NUM, GetTheScore2);
		GetTheScore(stu, NUM, GetTheScore3);
		MenuInfo(stu);
		break;
	case 3:
		GetAveScore(stu, NUM);
		MenuInfo(stu);
	case 4:
		GetOrderScore(stu, NUM);
		MenuInfo(stu);
	default:
		exit(-1);
		break;
	}
}
int main()
{
	int count = 0;
	student stu[5]; /*= {
		{ "1000", "121",435,545,45  },
		{ "1001", "122",4534,56,67},
		{ "1002", "123",545,54,54 },
		{ "1003", "124",33,324,234 },
		{ "1004", "125",4345,53,532 }
		};*/
	printf("\t\t\t��������ѧ������Ϣ\n");
	while (count<=NUM-1)
	{
		printf("����� %d ��ѧ������Ϣ��\n",count+1);
		scanf("%s", stu[count].num);
		//getchar();
		scanf("%s", stu[count].name);
		scanf("%lf%lf%lf",&stu[count].score1, &stu[count].score2, &stu[count].score3);
		count++;
	}
	////stu[0].score1 = 323.4;
	//printf("%lf ��ѧ������Ϣ��\n",stu[3].score1);
	MenuInfo(stu);
	

	getchar();
	getchar();
	return 0;
}
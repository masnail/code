#include <iostream>
#include <string>

using namespace std;

void fun(int p[],int index)
{
	int length = 8;
	if (index>length||index<0)
	{
		return;
	}
	for (int i = 0; i != index;i++)
	{
		int temp = p[0];
		for (int j = 0; j != length-1;j++)
		{
			p[j] = p[j + 1];
		}
		p[length - 1] = temp;
	}
	
}

int main()
{
	cout << "100-1-0" << endl;
	int p[] = { 45454, 2256, 555, 541, 366, 2, 8998, 96 };
	fun(p,2);
	for (int i = 0; i != sizeof(p) / sizeof(int); i++)
	{
		
		cout<<p[i]<<"\t";
	}
	cin.get();
	cin.get();
	return 0;
}
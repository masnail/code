#include <iostream>

using namespace std;

void fun()
{
	double index=1,pre = 0, next = 0,temp=1;
	pre = index;
	next = index * 2 + 1;
	while (pre / next>0.0005)
	{
		temp += (pre / next);
		index++;
		pre *= index;
		next *= (index * 2 + 1);
	}
	cout << temp*2 << endl;
}

int main()
{
	fun();
	cin.get();
	cin.get();
	return 0;
}
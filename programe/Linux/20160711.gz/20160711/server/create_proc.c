/*************************************************************************
 Author:0054
 Created Time: 2016年07月11日 星期一 19时22分29秒
 File Name: create_proc.c
 Description: 
 ************************************************************************/
#include "head.h"

void create_proc(pproc p,int n)
{
	int fds[2];
	int pid;
	for(int i=0;i<n;i++)
	{
		socketpair(AF_LOCAL,SOCK_STREAM,0,fds);
		pid=fork();
		if(0 == pid)
		{
			close(fds[0]);
			send_file(fds[1]);
		}
		close(fds[1]);
		p[i].pid=pid;
		p[i].fdw=fds[0];
		p[i].busy=0;
	}

}

void send_file(int fd)
{
	int sock_fd;
	int ret;
	sendata  *data=(sendata*)malloc(sizeof(sendata));
	while(1)
	{
		recv_msg(fd,&sock_fd);//sock_fd
		data->len=strlen(FILENAME);
		if(data->len<=0)
		{
			printf("file name is short\n");
			continue;
		}
		memcpy(data->buff,FILENAME,data->len);
		ret = send(sock_fd,data,4+data->len,0);
		if(0 >= ret)
		{
			printf("send file name is faild\n");
			continue;
		}
		int fdr=open(FILENAME,O_RDONLY);
		
		if(-1 == fdr )
		{
			perror("open");
			continue;
		}
		int flag=1;
		printf("send_file\n");
		while(memset(data,0,sizeof(data)),(data->len=read(fdr,data->buff,sizeof(data->buff)))>0 )
		{
			send(sock_fd,data,4+data->len,0);

		}
		write(fd,&flag,sizeof(int));
		close(sock_fd);	
	}
}

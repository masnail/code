#include <iostream>
#include <string>

using namespace std;

void fun()
{
	system("color 05");
}

int main()
{
	cout << "100-2-035" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月21日 星期四 19时11分41秒
* File Name: point_init.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

class point
{   
public:
    point(float x=0,float y=1):_x(x),_y(y)
    {}

    void print()
    {	
	cout<<"x="<<_x
	    <<":y="<<_y
	    <<endl;
    }

    ~point()
    {
	cout<<"~point()"<<endl;
    }

private:
    float _x;
    float _y;
};

int main(int argc,char *argv[])
{
    point p;
    p.print();

    point p1(12,34);
    p1.print();
    return 0;
}


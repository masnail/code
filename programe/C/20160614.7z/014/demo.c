#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct nd
{
	int data;
	struct nd *next;
}node,*nodelist;

void list_show(nodelist head)
{
	nodelist p = head->next;
	while (p)
	{
		printf("%d ", p->data);
		p = p->next;
	}
	printf("\n");
}

void list_div(nodelist phead, nodelist *Lo, nodelist *Le)
{
	nodelist head = (phead)->next,po=(*Lo),qe=(*Le);

	while (head)
	{
		po->next = head;
		po = head;
		head = head->next;
		if (head)
		{
			qe->next = head;
			qe = head;
			head = head->next;
		}
	}
	po->next = NULL;
	qe->next = NULL;
}

void list_head_insert(nodelist *head,int num)
{
	nodelist p = (nodelist)malloc(sizeof(node));
	memset(p, 0, sizeof(node));
	p->data = num;
	p->next = (*head)->next;
	(*head)->next = p;
}

int main(int argv,char *argc[])
{
	srand((unsigned)time(NULL));
	nodelist head = (nodelist)malloc(sizeof(node));
	memset(head, 0, sizeof(node));

	for (int i = 0; i < 11; i++)
	{
		list_head_insert(&head, rand() % 100);
	}
	list_show(head);

	nodelist oddp = (nodelist)malloc(sizeof(node)), evep = (nodelist)malloc(sizeof(node));
	memset(oddp, 0, sizeof(node));
	memset(evep, 0, sizeof(node));

	list_div(head, &oddp, &evep);
	list_show(oddp);
	list_show(evep);

	getchar();
	getchar();
	return 0;

}
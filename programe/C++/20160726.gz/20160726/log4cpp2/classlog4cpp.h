/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月26日 星期二 19时55分06秒
* File Name: classlog4cpp.h
* * Description: C++ file
* 单例模式中是类的对象在内存中只有一份
************************************************************************/

#ifndef __CLASSLOG4CPP_H_
#define __CLASSLOG4CPP_H_

#include <iostream>
#include <string>
#include <sstream>

#include "log4cpp/Category.hh"
#include "log4cpp/Priority.hh"
#include "log4cpp/PatternLayout.hh"
#include "log4cpp/RollingFileAppender.hh"
#include "log4cpp/OstreamAppender.hh"


using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::ostringstream;
using std::stringstream;
using namespace log4cpp;


class myLog
{
private:
    myLog();//构造函数
   // ~myLog();
public:
    static myLog * getInstance();
    static void close();
    void warn(const char *msg);
    void error(const char *msg);
    void debug(const char *msg);
    void info(const char *msg);
    void fatal(const char *msg);
    void alert(const char *msg);
private:
    Category &_root;
   static myLog * _mylog;
};


#endif


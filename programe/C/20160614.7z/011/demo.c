#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct nd
{
	int num;
	struct nd *next;
}node,*nodelist;

void list_rec(nodelist phead)
{
	nodelist p = phead, q = p;
	while (p)
	{
		q = p->next;
		while (q)
		{
			if (q==p)
			{
				printf("This list have rec \n");
				return;
			}
			q = q->next;
		}
		p = p->next;
	}
	printf("This list not have rec \n");
}

int main()
{
	nodelist head = (node *)malloc(sizeof(node)),tail=head;
	memset(head, 0, sizeof(node));

	head->next = head;

	/*for (int i = 1; i < 5; i++)
	{
		nodelist q = (nodelist)malloc(sizeof(node));
		q->num = i;
		q->next=head->next;
		head->next = q;
		if (i == 1)
			tail = q;
	}
	nodelist q = (nodelist)malloc(sizeof(node));
	q->num = 10;
	q->next = head;
	tail->next = q;
	tail = q;*/

	list_rec(head);

	getchar();
	return 0;
}
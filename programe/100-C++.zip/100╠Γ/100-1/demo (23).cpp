#include <iostream>
#include <string>

using namespace std;

int fun(string s)
{
	for (int i = 0; i < s.length();i++)
	{
		if (s[i] != s[s.length()-i-1])
		{
			return 0;
		}
	}
	return 1;
}

int main()
{
	cout << "100-1-023" << endl;
	string s;
	cin >> s;
	if (fun(s))
	{
		cout << "yes" << endl;
	}
	else
	{
		cout << "no" << endl;
	}
	cin.get();
	cin.get();
	return 0;
}
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define MAX 256

/*
*
*�ּ𵥴�
*
*
*
*/
void ChooseWord(char ch[])
{
	//ͳһǰ�ո�󵥴�
	int cnt = 0, index = 0;
	printf("\n");
	printf("Output:\n");

	if (ch[0] == 0)
		goto label;

	if (ch[0] != 32)
	{//�ҵ���ʼ��ĸ
		cnt++;
		
		while (ch[index] != 32&&ch[index])
		{
			printf("%c", ch[index]);
			if (ch[index]){
				index++;
			}
			/*else{
				goto label;
			}*/
			
		}
	}


	//���ӡ�ո�
	while (ch[index] && ch[index + 1])
	{
		if (ch[index] == 32 && ch[index + 1] != 32){//
			cnt++;
			printf("\n");
		}
		if (ch[index] != 32)
		{//�ַ�
			printf("%c", ch[index]);
		}
		index++;
	}

label:	printf("\nall the worldid : %d\n", cnt);
}

int main()
{
	char ch[MAX] = { 0 };
	while (gets(ch) != EOF){
		ChooseWord(ch);
	}

	getchar();
	getchar();
	return 0;
}
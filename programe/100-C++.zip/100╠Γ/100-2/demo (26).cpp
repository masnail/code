#include <iostream>
#include <string>

using namespace std;

int fun(int n)
{
	if (n==1)
	{
		return 1;
	}
	else
	{
		return fun(n - 1)*n;
	}
}

int main()
{
	cout << "100-2-026" << endl;
	cout<<fun(5);
	cin.get();
	cin.get();
	return 0;
}
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

double fun(double score[])
{
	double sum = 0;
	for (int i = 0; i != 5;i++)
	{
		sum += score[i];
	}
	return sum / 5;
}

int main()
{
	cout << "100-1-082 " << endl;
	double score[5] = { 90.5, 72, 80, 61.5, 55 };
	cout<<setprecision(2)<<fixed<<fun(score);
	cin.get();
	cin.get();
	return 0;
}

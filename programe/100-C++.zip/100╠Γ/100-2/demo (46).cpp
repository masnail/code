#include <iostream>
#include <string>

#define GHOST 

using namespace std;

void fun()
{
	int a = 0,b=0;

#ifdef GHOST
	a = 123;
#else
	a=456;
#endif // GHOST

#ifndef LOL
	b = 789;
#else
	b = 111;
#endif

	cout << "a=" << a << endl;
	cout << "b=" << b << endl;
}

int main()
{
	cout << "100-2-049" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

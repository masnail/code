/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月22日 星期五 21时44分34秒
* File Name: inline.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

class a
{
    public:
	int min(int a,int b);
};

int a::min(int a,int b)
{
    return a<b?a:b;
}
int main(int argc,char *argv[])
{
    a mina;
    int ax=90,by=4;
    cout<<"ax= "<<ax
	<<"by= "<<by
	<<" : min="<<mina.min(ax,by)
	<<endl;
    return 0;
}


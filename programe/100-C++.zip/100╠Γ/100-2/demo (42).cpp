#include <iostream>
#include <string>

using namespace std;

void fun()
{
	auto index=0;
	for (int i = 1; i != 11; i++)
	{
		index += i;
	}
	cout << index << endl;
}

int main()
{
	cout << "100-2-042" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

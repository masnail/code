#include <iostream>
#include <string>

using namespace std;

void fun()
{
	int old = 10;
	for (int i = 0; i != 4;i++)
	{
		old += 2;
	}
	cout << old << endl;
}

int main()
{
	cout << "100-2-028" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
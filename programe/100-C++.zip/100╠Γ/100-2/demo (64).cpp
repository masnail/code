#include <iostream>
#include <string>

using namespace std;

void fun()
{
 char *s[] = { "man", "woman", "girl", "boy", "sister" };
	char **q=new char *;
	int k;
	for (k = 0; k < 5; k++)
	{
		*q = s[k];/*������дʲô���*/
		cout << *q << endl;
	}
}

int main()
{
	cout << "100-2-077" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
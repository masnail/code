#include <iostream>
#include <string>
#include <cmath>

using namespace std;

int fun(string str)
{
	int count = 0,sum=0;
	for (int i = str.length() - 1; i >= 0; i--)
	{
		switch (str[i])
		{
		case '0':
			count = 0;
			break;
		case '1':
			count = 1;
			break;
		case '2':
			count = 2;
			break;
		case '3':
			count = 3;
			break;
		case '4':
			count = 4;
			break;
		case '5':
			count = 5;
			break;
		case '6':
			count = 6;
			break;
		case '7':
			count = 7;
			break;
		case '8':
			count = 8;
			break;
		case '9':
			count = 9;
			break;
		default:
			break;
		}
		sum = sum + count*pow(10, i);
	}
	return sum;
}

int main()
{
	cout << "100-1-024" << endl;
	string str;
	cin >> str;
	cout<<fun(str);
	cin.get();
	cin.get();
	return 0;
}
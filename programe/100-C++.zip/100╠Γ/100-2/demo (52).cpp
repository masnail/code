#include <iostream>
#include <string>

#define MAX 10

using namespace std;

void fun()
{
	cout << "���������" << endl;
	int h[MAX] = { 1 }, temp=1,ctemp=0;
	int index = 0;
	for (int i = 0; i != MAX;i++)
	{
		
		temp = 1;
		for (int j = 0; j != index;j++)
		{
				ctemp = h[j+1];
				h[j+1] += temp;
				temp = ctemp;
		}
		for (int i = 0; i != index+1; i++)
		{
			cout << h[i] << "\t";
		}
		index++;
		cout << endl;
	}

}

int main()
{
	cout << "100-2-061" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
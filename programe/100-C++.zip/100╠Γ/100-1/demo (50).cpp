#include <iostream>
#include <string>

using namespace std;

typedef struct 
{
	string num;
	int score;
}student;

student fun(student stu[])
{
	student s;
	s.num = "";
	s.score = 0;
	for (int i = 0; i != 5;i++)
	{
		if (s.score<stu[i].score)
		{
			s = stu[i];
		}
	}
	return s;
}

int main()
{
	cout << "100-1-050" << endl;
	student stu[5] = {
		{ "2011",85 },
		{ "2012", 98 },
		{ "2013", 63 },
		{ "2014", 93 },
		{ "2015", 100 }
	};
	cout<<fun(stu).num<<":"<<fun(stu).score;
	cin.get();
	cin.get();
	return 0;
}
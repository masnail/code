#include <iostream>
#include <string>

using namespace std;

int fun(int p[2][5])
{
	int max=0;
	for (int i = 0; i < 2;i++)
	{
		for (int j = 0; j < 5;j++)
		{
			if (max<p[i][j])
			{
				max = p[i][j];
			}
		}
	}
	
	return max;
}
int main()
{
	cout << "100-1-030" << endl;
	int p[][5]=
	{
		{11,1,51,15,8},
		{9,889,7,2,52}
	};
	cout<<fun(p);
	cin.get();
	cin.get();
	return 0;
}

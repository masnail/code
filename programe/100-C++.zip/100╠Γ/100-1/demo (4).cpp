#include <iostream>
#include <string>

#define MAX 26

using namespace std;

void fun(char *tt,int pp[])
{
	if (*tt>='a'||*tt<='z')
	{
	pp[*tt - 97] += 1;
	}
}
int main()
{
	cout << "��̻���100-004" << endl;
	char *tt = new char; 
	int pp[MAX] = { 0 };
	string str;

	getline(cin,str);
	while (!str.empty())
	{
		for (int i = 0; i != str.length(); i++)
		{
			fun(&str[i], pp);
		}
		getline(cin, str);
	}
	for (int i = 0; i != MAX;i++)
	{
		cout << char(97+i)<<":"<<pp[i] << "\t";
	}
	system("pause");
	return 0;
}
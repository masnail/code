#include <iostream>
#include <string>

using namespace std;

void fun(int a[][3],int l[])
{
	for (int i = 0; i !=3;i++)
	{
		for (int j = 0; j!= 2;j++)
		{
			l[2 * i + j] = a[j][i];
		}
	}
}

int main()
{
	cout << "100-1-075" << endl;
	int arr[2][3] = {
		{12,15,5},
		{454,4,8}
	};
	int lineArr[6] ;
	fun(arr,lineArr);

	for (int i = 0; i != 6; i++)
	{
		
			 cout<<lineArr[i]<<"\t";
	}
	cin.get();
	cin.get();
	return 0;
}

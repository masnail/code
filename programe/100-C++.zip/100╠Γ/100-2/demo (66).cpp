#include <iostream>
#include <string>

using namespace std;

void fun(string s[])
{
	string str ;
	int index ;
	for (int i = 0; i != 5;i++)
	{
		str = s[i];
		index = i;
		for (int j = i; j != 5; j++)
		{
			if (s[j] < str)
			{
				str = s[j];
				index = j;
			}
		}
		s[index] = s[i];
		s[i] = str;
	}

	for (int k = 0; k != 5;k++)
	{
		cout << s[k] << endl;
	}
}

int main()
{
	cout << "100-2-079" << endl;
	string s[] = { "DFgfd", "dfgdfg", "fdgdfgd", "dfgdfgs", "gdfgd" };
	fun(s);
	cin.get();
	cin.get();
	return 0;
}
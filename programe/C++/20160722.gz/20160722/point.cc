/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月22日 星期五 21时07分37秒
* File Name: point.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;


/*
 *  运算符的重载
 *
 *  重载的时候，不声明friend的时候只能传递
 *  一个或者零个参数
 *
 *  友元函数（friend）可以多个
 *
 *
 * /
class point
{
public:
    point(int ix,int iy);
    void print();
    //运算符重载
    friend void operator -(const point &rhl,const point &rhr);//友元函数

private:
    int _ix;
    int _iy;
};

point::point(int ix,int iy)
{
    _ix=ix;
    _iy=iy;
}
void point::print()
{
    cout<<"( "<<_ix
	<<","<<_iy
	<<" )"<<endl;
}

void operator -(const point &rhs,const point &rhr)
{
    cout<<"point & operator -"<<endl;
   int x= rhs._ix-rhr._ix;
   int y=rhs._iy-rhr._iy;
   cout<<"point  - pointi="<< x*x+y*y<<endl;
}
int main(int argc,char *argv[])
{
    point p1(2,4);
    point p2(4,5);
    p1.print();
    p2.print();
    p1-p2;
  //  cout<<p1-p2<<endl;
    return 0;
}


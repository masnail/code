/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月27日 星期三 07时54分05秒
* File Name: stack.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

class stack
{
    public:
	stack(int len,int capa);
	~stack();
	void push(int a);
	void pop();
	int top();
	bool empty();
	bool full();
    private:
	int _length;
	int _capacity;
	int *_Arr;
};

stack::stack(int len=-1,int capa=10)
    :_length(len)
     ,_capacity(capa)
{  
    _Arr=new int[_capacity];
}
stack::~stack()
{
    delete [] _Arr;
}
void stack::push(int a)
{
    if(_length<_capacity)
	 _Arr[++_length]=a;
}

void stack::pop()
{
    if(_length>=0)
	cout<<"pop:"<<_Arr[_length--]<<endl;
}

int stack::top()
{
    cout<<"top:"<<_Arr[_length]<<endl;
}

bool stack::empty()
{
    if(_length==-1)
	return true;
    return false;
}

bool stack::full()
{
    if(_length==_capacity-1)
	return true;
    return false;
}

int main(int argc,char *argv[])
{
    stack s;
    s.push(10);
    s.push(12);
    s.push(14);
    s.top();
    s.pop();
    s.top();
    return 0;
}


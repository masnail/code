/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月21日 星期四 19时26分08秒
* File Name: mem_func.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

const int a=0;

int main(int argc,char *argv[])
{
    int pa=78;
    const int b=0;
    int *p=&pa;
    /* char* 这样的时候c++中的string和c中的char产生冲突，所以需要const指明是c的char* */
    const char *pch="hello,world";
    static int st=12;
    int *dch=new int[3];
    dch[0]=123123;


    cout<<"pa="<<&pa<<endl;//栈
    cout<<"a="<<&a<<endl;//文字常量区
    cout<<"b="<<&b<<endl;//栈
    cout<<"p="<<p<<endl;//栈
    cout<<"pch="<<&pch<<endl;//pch在栈区，字符在文字常量区
    cout<<"st="<<&st<<endl;//静态区
    cout<<"dch="<<&dch<<endl;//堆


    return 0;

}


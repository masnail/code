#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define M 256
#define N 2

/*
*
*С��û�п��ǵ�
*/

int main()
{
	int n,m=0;
	int count[M], index = 0;
	int temp = 0;
	while (scanf("%d", &n) != EOF)
	{
		index = 0;
		temp = 0;
		if (n < 0)
		{
			m = 1;
			n = ~(n);
		}
		while (n != 0)
		{
			count[index] = n % N;
			n /= N;
			index++;
		}
		if (index < M)
		{
			for (int i = index - 1; i >= 0; i--)
			{
				if (count[i])
					temp++;
			}
			if (m)
				printf("1�ĸ�����%d\n", sizeof(m)*8-temp);
			else
				printf("1�ĸ�����%d\n", temp);
			
		}
		else{
			printf("��Ҫת���ɵĶ�������̫���ˣ�\n");
		}
	}
	getchar();
	getchar();
	return 0;
}
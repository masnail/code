#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct nd
{
	int data;
	struct nd *next;
}node, *nodelist;

void list_show(nodelist head)
{
	nodelist p = head->next;
	while (p)
	{
		printf("%d ", p->data);
		p = p->next;
	}
	printf("\n");
}

void list_find_node(nodelist phead, nodelist qhead)
{
	nodelist p= phead->next,q=qhead->next;
	int pcnt = 0, qcnt = 0;
	while (p)
	{
		pcnt++;
		p = p->next;
	}
	while (q)
	{
		qcnt++;
		q = q->next;
	}
	p = phead ->next;
	q = qhead->next;

	if (pcnt > qcnt)
	{
		int cnt = pcnt - qcnt;
		while (cnt&&p!=NULL)
		{
			p = p->next;
			cnt--;
		}
	}
	else{
		int cnt = qcnt - pcnt;
		while (cnt&&q!=NULL)
		{
			q = q->next;
			cnt--;
		}
	}

	while (p&&q)
	{
		if (q->data != p->data)
		{
			q = q->next;
			p = p->next;
		}
		else{
			printf("The list have same count: %d\n", q->data);
			return;
		}
	}
	if (p==NULL||q==NULL)
	{
		printf("The list NOT have same count\n");
	}
}

void list_head_insert(nodelist *head, int num)
{
	nodelist p = (nodelist)malloc(sizeof(node));
	memset(p, 0, sizeof(node));
	p->data = num;
	p->next = (*head)->next;
	(*head)->next = p;
}

void list_init(nodelist *phead, nodelist *qhead)
{

	for (int i = 100; i < 110; i++)
	{
		list_head_insert(phead, i);
	}

	for (int i = 121; i < 127; i++)
	{
		list_head_insert(qhead, i);
	}

	nodelist p = (*phead)->next, q = (*qhead)->next;

	for (int i = 0; i < 4; i++)
	{
		p = p->next;
	}
	while (q->next)
	{
		q = q->next;
	}
	q->next = p;

	list_show(*phead);
	list_show(*qhead);
}

int main(int argv, char *argc[])
{
	srand((unsigned)time(NULL));
	nodelist phead = (nodelist)malloc(sizeof(node));
	memset(phead, 0, sizeof(node));

	nodelist qhead = (nodelist)malloc(sizeof(node));
	memset(qhead, 0, sizeof(node));

	list_init(&phead, &qhead);

	list_find_node(phead, qhead);
	
	getchar();
	getchar();
	return 0;

}
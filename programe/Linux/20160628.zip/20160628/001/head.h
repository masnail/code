/*************************************************************************
 Author:MASnail
 Created Time: 2016年06月28日 星期二 10时22分58秒
 File Name: head.h
 Description: 
 ************************************************************************/
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <dirent.h>
#include <fcntl.h>
#include <string.h>
#include <sys/select.h>
#include <sys/time.h>
#include <stdlib.h>
//#include "fd.h"

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define M 256
#define N 16

/*
*
*С��û�п��ǵ�
*/

int GetChara(char ch)
{
	if (ch >= '0'&&ch >= '9')
		return ch - 48;
	else if (ch >= 'A'&&ch >= 'F')
		return ch - 71;
}

int main()
{
	char ch;
	int  sum = 0,index=0;

	char ch;

	/*while (scanf("%d", &ch) != EOF)
	{
		index = 0;
		sum = GetChara(ch);

		while (scanf("%d", &ch) != EOF)
		{
			index++;
			sum += pow(N, index)*GetChara(ch);
		}
		printf("shijinzhi=%d\n", sum);
	}*/
	getchar();
	getchar();
	return 0;
}
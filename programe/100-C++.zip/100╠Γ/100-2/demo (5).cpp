#include <iostream>
#include <string>

using namespace std;

void fun()
{
	int a, b, c;
	cout << "input three count:";
	cin >> a >> b >> c;

	int temp;
	if (a>b)
	{
		temp = a;
		a = b;
		b = temp;
	}
	if (a>c)
	{
		temp = a;
		a = c;
		c = temp;
	}
	if (b>c)
	{
		temp = c;
		c = b;
		b = temp;
	}
	cout << a << "\t" << b << "\t" << c << endl;
}

int main()
{
	cout << "100-2-005" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
#include <iostream>
#include <string>

using namespace std;

void fun(int n)
{
	double sum = 1,sn=1,temp=1;
	while (sum!=n+1)
	{
		sn += (1/temp);
		temp *= (temp++);
		sum++;
		//cout << sum << endl;
	}
	cout << sn << endl;
}

int main()
{
	cout << "100-1-068" << endl;
	int n;
	cout << "input a int:";
	cin >> n;
	fun(n);
	cin.get();
	cin.get();
	return 0;
}
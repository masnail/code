/*************************************************************************
 Author:0054
 Created Time: 2016年07月11日 星期一 18时41分26秒
 File Name: head.h
 Description: 
 ************************************************************************/

#ifndef HEAD_H
#define HEAD_H


#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#define FILENAME "test"
#define NUM 10
#define BUFF_SIZE 1024

typedef struct
{
	int pid;
	int fdw;
	short busy;
}pro,*pproc;

typedef struct
{
	int len;
	char buff[BUFF_SIZE];
}sendata;

//msg
void send_msg(int,int);
void recv_msg(int,int*);

//proccess
void create_proc(pproc,int);
void send_file(int);

#endif

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/*
*
**
*����������һ���еĵڼ���
*
*/
void Old(int year,int month,int day)
{
	int leap = 28, sum = 0;
	if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0)
	{
		leap = 29;
	}

	switch (month)
	{
	case 1:
		sum = day;
		break;
	case 2:
		sum = 31 + day;
		break;
	case 3:
		sum = 31 + leap + day;
		break;
	case 4:
		sum = 62 + leap + day;
		break;
	case 5:
		sum = 92 + leap + day;
		break;
	case 6:
		sum = 123 + leap + day;
		break;
	case 7:
		sum = 153 + leap + day;
		break;
	case 8:
		sum = 184 + leap + day;
		break;
	case 9:
		sum = 215 + leap + day;
		break;
	case 10:
		sum = 245 + leap + day;
		break;
	case 11:
		sum = 275 + leap + day;
		break;
	case 12:
		sum = 305 + leap + day;
		break;
	}
	printf("this is %d day!\n", sum);
}

int New(int year, int month, int day)
{
	int sum = 0;
	int today[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	for (int i = 0; i < month-1; i++)
	{
		sum += today[i];
	}

	if ((year % 4 == 0 && year % 100 != 0 || year % 400 == 0) &&(month>2))
	{
	sum += 1;
	}
	sum += day;
	printf("today is %d day\n",sum);
	return sum;
}

int main()
{
	int year, month, day;
	while (scanf("%d%d%d", &year, &month, &day)!=EOF)
	{
		New(year, month, day);
	}
	//Old(year,month,day);
	
	system("pause");
	return 0;
}
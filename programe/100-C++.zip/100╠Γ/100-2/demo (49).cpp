#include <iostream>
#include <string>

using namespace std;

void fun(string n)
{
	if (n.length()<7||n.length()<0)
	{
		return;
	}
	for (int i = 3; i < 7;i++)
	cout << n[i] ;
}

int main()
{
	cout << "100-2-054" << endl;
	cout << "input a count:";
	string n;
	cin >> n;
	fun(n);
	cin.get();
	cin.get();
	return 0;
}

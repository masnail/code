#include "main.h"


/*
 *
 *
 * setjmp 
 * longjmp
 *
 */
int main(int argc,char *argv[])
{
	Log();
	return 0;
}
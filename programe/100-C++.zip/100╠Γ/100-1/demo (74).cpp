#include <iostream>
#include <string>

using namespace std;

typedef struct
{
	string num;
	int score;
}student;

void fun(student s[], student *h,int *k)
{
	int index = 0,min=100;
	while (index!=4)
	{
		//cout << s[index].score << endl;
		if (s[index].score <min )
		{
			//cout << s[index].score << endl;
			min = s[index].score;
		}
		index++;
	}
	//cout << min << endl;
	index = 0;
	int count = 0;
	while (index != 4)
	{
		if (s[index].score == min)
		{
			//cout << s[index].score << endl;;
			//h[count].num=s[index].num;
			//h[count].score = s[index].score;
			count++;
			*h = s[index];
			h++;
		}
		index++;
	}
	*k = count;
}

int main()
{
	cout << "100-1-074" << endl;
	student s[] = {
		{ "2011", 98 },
		{ "2012", 89 },
		{ "2013", 90 },
		{ "2014", 91 }
	};
	student *h=new student;
	int *k = new int;
	fun(s, h,k);

	int index = 0;
	while (index!=*k)
	{
		cout << h[index].num
			<< ":"
			<< h[index].score << endl;
		index++;
	}
	cin.get();
	cin.get();
	return 0;
}
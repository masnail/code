#include <iostream>

using namespace std;

void fun(char ch[7])
{
	for (int i = 1; i < 6;i++)
	{
		for (int j = i + 1; j < 6;j++)
		{
			if (ch[i]<ch[j])
			{
				int temp = ch[i];
				ch[i] = ch[j];
				ch[j] = temp;
			}
		}
	}
}

int main()
{
	char ch[] = "fsgratw";
	fun(ch);
	for (int i = 1; i < 6; i++)
		cout << ch[i];
	getchar();
	return 0;
}
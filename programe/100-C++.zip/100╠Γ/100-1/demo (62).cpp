#include <iostream>
#include <string>

using namespace std;

int fun(string s)
{
	int count = 0,alphacount=0; 
	for (int i = 0; i != s.length();i++)
	{
		if (isalpha(s[i]))
		{
			alphacount++;
		}
		else if (isspace(s[i]))
		{
			if (alphacount)
			{
				count++;
			}
			alphacount = 0;
		}
	}
	if (isalpha(s[s.length()-1]))
	{
		if (alphacount)
		{
			count++;
		}
		alphacount = 0;
	}
	//cout << count <<endl;
	return count;
}

int main()
{
	cout << "100-1-062" << endl;
	string str;
	getline(cin, str);
	cout<<fun(str);
	cin.get();
	cin.get();
	return 0;
}
#include <iostream>
#include <string>

using namespace std;

int GetStringLen(string s)
{
	int index = 0;
	while (s[index])
	{
		index++;
	}
	return index;
}

void fun(string s,int n)
{
	int length = GetStringLen(s);
	string strtemp = "";
	bool choose = false;
	int index = 0;
	for (int i = 0; i != length; i++)
	{
		if (choose)
		{
				strtemp += s[i];
		}
		else
		{
			if (index < n)
			{
				strtemp += s[i];
				index++;
			}
			if (s[i] != '*')
			{
				choose = true;
			}
		}
	}
	cout << strtemp << endl;
}

int main()
{
	cout << "100-1-095" << endl;
	cout << "input a string:" << endl;;
	string s;
	cin >> s;
	cout << "input a count:";
	int n;
	cin >> n;
	fun(s,n);
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <string>

using namespace std;

void fun()
{
	static int index_static = 0;
	int index = 0;
	cout << "index:" << index << endl;
	cout << "index_static:" << index_static << endl;
	index++;
	index_static++;
}

int main()
{
	cout << "100-2-041" << endl;
	for (int i = 0; i != 4; i++)
	{
		fun();
	}
	cin.get();
	cin.get();
	return 0;
}

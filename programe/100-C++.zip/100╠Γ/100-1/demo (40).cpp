#include <iostream>
#include <string>

using namespace std;

string fun(string s,int m)
{
	return s.substr(m, s.length() - m) + s.substr(0, m);
}

int main()
{
	cout << "100-1-0" << endl;
	string s;
	int m;
	cin >> s >> m;
	cout<<fun(s,m);
	cin.get();
	cin.get();
	return 0;
}
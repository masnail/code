/*************************************************************************
* Author: MASnail
* Created Time: 2016年08月03日 星期三 22时51分45秒
* File Name: queue_template.cc
* Description: C++ file
************************************************************************/
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

template <typename T,int NUM>
class Queue
{
    public:
	Queue();
	bool enqueue(T);
	bool delqueue(T &);
	bool full();
	bool empty();
    private:
	int _head;
	int _tail;
	T _arr[NUM+1];
};

template <typename T,int NUM>
Queue<T,NUM>::Queue()
    :_head(0)
     ,_tail(0)
{   }

template <typename T,int NUM>
bool Queue<T,NUM>::enqueue(T t)
{
    if(!full())
    {
	_arr[_tail]=t;
	_tail=(_tail+1)%(NUM+1);
	return true;
    }
    return false;
}

template <typename T,int NUM>
bool Queue<T,NUM>::delqueue(T &t)
{
    if(!empty())
    {
	t= _arr[_head];
	_head=(_head+1)%(NUM+1);
	return true;
    }
    return false;
}

template <typename T,int NUM>
bool  Queue<T,NUM>::full()
{
    if((_tail+1)%(NUM+1)==_head)
	return true;
    return false;
}

template <typename T,int NUM>
bool Queue<T,NUM>::empty()
{
    if(_head==_tail)
	return true;
    return false;
}

#include <iostream>
#include <string>

using namespace std;

void fun(int year,int month,int day)
{
	bool ruinian = false;
	if (year%4==0||year%100==0)
	{
		ruinian = true;
	}
	int countday = 0,rnmonth=28;
	if (ruinian)
	{
		rnmonth = 29;
	}

	switch (month)
	{
	case 1:
		countday = day;
		break;
	case 2:
		countday = 31 + day;
		break;
	case 3:
		countday = 31 + day;
		break;
	case 4: 
		countday = 31 * 2 +  day;
		break;
	case 5:
		countday = 31 * 2 + 30 + day;
		break;
	case 6:
		countday = 31 * 3 + 30  + day;
		break;
	case 7:
		countday = 31 * 3 + 30 * 2  + day;
		break;
	case 8:
		countday = 31 * 4 + 30 * 2  + day;
		break;
	case 9:
		countday = 31 * 5 + 30 * 2  + day;
		break;
	case 10:
		countday = 31 * 5 + 30 * 3 + day;
		break;
	case 11:
		countday = 31 * 6 + 30 * 3  + day;
		break;
	case 12:
		countday = 31 * 6 + 30 * 4  + day;
		break;
	default:
		break;
	}
	if (month>2)
	{
		countday += rnmonth;
	}
	cout <<year<<"/"<<month<<"/"<<day<< "��һ���еĵ�" << countday<<"��" << endl;
}

int main()
{
	cout << "100-2-004" << endl;
	int year, month, day;
	cout << "year:";
	cin >> year;
	cout << "month:";
	cin >> month;
	cout << "day:";
	cin >> day;
	fun(year,month,day);
	cin.get();
	cin.get();
	return 0;
}
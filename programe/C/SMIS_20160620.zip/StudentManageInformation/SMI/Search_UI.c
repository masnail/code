#include "Search_UI.h"


void Search_Show()//��ʾsearch����
{
	if (9 == Get_Power())
	{
		Search_Show_Root();
	}else{
		Search_Show_Com();
	}
}

void Search_Show_Root()//��ʾsearch����
{
	Print_Welcome();

	printf("\t---------------------sort----------------------\n");
	printf("\t1��	num\n");
	printf("\t2��	age\n");
	printf("\t3��	score\n");
	printf("\t--------------------search---------------------\n");
	printf("\t4��	num\n");
	printf("\t5��	name\n");
	printf("\t6��	all\n");
	printf("\t7��	return\n");
	printf("\t8��	exit\n");
	Search_Input_Root();
}

void Search_Input_Root()//search������
{
	int getin =0;
	printf("\tInput you choose: ");
	scanf("%d", &getin);

	Print_Welcome();

	switch (getin)
	{
	case 1:Search_Student_Show(getin,0); 
		break;
	case 2:Search_Student_Show(getin, 0);
		break;
	case 3:Search_Show_SortScore();//two
		break;
	case 4:Search_Student_Num();
		break;
	case 5:Search_Student_Name(); 
		break;
	case 6:Search_Student_All(); 
		break;
	case 7:Main_Show_User();
	case 8:exit(-1);
	default:
		printf("input have error!\n");
	}
	printf("\t");
	system("pause");
	Search_Show_Root();//ret Search_Show_Root()
}
//����
void Search_Show_SortScore()
{
	Print_Welcome();

	printf("\t---------------------score---------------------\n");
	printf("\t1��	first	score\n");
	printf("\t2��	second	score\n");
	printf("\t3��	third	score\n");
	printf("\t4��	fourth	score\n");
	printf("\t5��	fifth	score\n");
	printf("\t6��	all	score\n");
	printf("\t7��	return\n");
	printf("\t8��	exit\n");
	Search_Input_SortScore();
}

void Search_Input_SortScore()//����������
{
	int getin = 0;
	printf("\tInput you choose: ");
	scanf("%d", &getin);

	Print_Welcome();

	if (1 <= getin &&5 >= getin)
	{
		Search_Student_Show(3,getin-1);
	}else if (getin==6){
		Search_Student_Show(4, 0);
	}else if (getin == 7){
		Search_Show_Root();
	}
	else if (getin == 8){
		exit(-1);
	}else{
		printf("input have error!\n");
	}
	printf("\t");
	system("pause");
	Search_Show_SortScore();
}

void Search_Show_Com()//��ʾsearch����
{
	system("CLS");
	Print_Welcome();

	printf("\t----------------------sort---------------------\n");
	printf("\t1��	num\n");
	printf("\t2��	age\n");
	printf("\t---------------------search--------------------\n");
	printf("\t3��	num\n");
	printf("\t4��	name\n");
	printf("\t5��	return\n");
	printf("\t6��	exit\n");
	Search_Input_Com();
}

void Search_Input_Com()//search������
{
	int getin = 0;

	printf("\tInput you choose: ");
	scanf("%d", &getin);

	Print_Welcome();

	switch (getin)
	{
	case 1:Search_Student_Show(getin, 0);
		break;
	case 2:Search_Student_Show(getin, 0);
		break;
	case 3:Search_Student_Num(); 
		break;
	case 4:Search_Student_Name(); 
		break;
	case 5:Main_Show_Student();

	case 6:exit(-1);
	default:
		printf("input have error!\n");
	}
	printf("\t");
	system("pause");
	Search_Show_Com();
}

//�û�
void Search_User_Show()
{
	Print_Welcome();

	printf("\t---------------------search--------------------\n");
	printf("\t1��	name\n");
	printf("\t2��	power\n");
	printf("\t3��	all\n");
	printf("\t4��	return\n");
	printf("\t5��	exit\n");
	Search_User_Input();
}

void Search_User_Input()
{
	int getin = 0;

	printf("\tInput you choose: ");
	scanf("%d", &getin);

	Print_Welcome();

	switch (getin)
	{
	case 1:Search_User_Name(); break;
	case 2:Search_User_Power(); break;
	case 3:Search_User_All(); break;
	case 4:Main_Show_User(); break;
	case 5:exit(-1);
	default:
		Search_User_Show();
		break;
	}
	printf("\t");
	system("pause");
	Search_User_Show();
}

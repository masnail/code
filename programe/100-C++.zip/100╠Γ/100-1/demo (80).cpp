#include <iostream>
#include <string>

using namespace std;

void fun(int a[][3],int n)
{
	for (int i = 0; i != 3;i++)
	{
		for (int j = 0; j != i+1;j++)
		{
			a[i][j] *= n;
		}
	}
}

int main()
{
	cout << "100-1-080" << endl;
	int a[][3] = {
		{1,9,7},
		{2,3,8},
		{4,5,6}
	};
	int n;
	cout << "input a int:";
	cin >> n;
	fun(a,n);
	for (int i = 0; i != 3; i++)
	{
		for (int j = 0; j != 3; j++)
		{
			cout<<a[i][j] <<"\t";
		}
		cout << endl;
	}
	cin.get();
	cin.get();
	return 0;
}

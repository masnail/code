#include <iostream>
#include <string>

using namespace std;

void fun(string s[])
{
	string str = "";
	for (int i = 0; i != 3;i++)
	{
		str += s[i];
	}
	cout << str;
}

int main()
{
	cout << "100-1-059" << endl;
	string s[] = { "5151212", "gfhjfghjhfgd", "dfgdfgsdf" };
	fun(s);

	cin.get();
	cin.get();
	return 0;
}

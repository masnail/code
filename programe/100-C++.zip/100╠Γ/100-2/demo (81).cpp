#include <iostream>
#include <string>
#include <fstream>

using namespace std;

void fun()
{
	string s;
	ofstream fout("abcd.txt");
	cin >> s;
	while (s!="#")
	{
		fout<<s;
		cin >> s;
	}
	cout << "game over" << endl;
}

int main()
{
	cout << "100-2-097" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
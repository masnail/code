#include <iostream>
#include <string>

using namespace std;

string fun(string s)
{
	string str = "";
	for (int i = 0; i !=s.length();i++)
	{
		if (!isspace(s[i]))
		{
			str += s[i];
		}
	}
	return str;
}

int main()
{
	cout << "100-1-035" << endl;
	string s;
	getline(cin,s);
	cout<<fun(s);
	cin.get();
	cin.get();
	return 0;
}

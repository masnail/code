#include <iostream>
#include <string>

using namespace std;

void fun()
{
	int a, b, c;
	for (int i = 100; i != 1000;i++)
	{
		a = i / 100;
		//cout << pow(4, 3) << endl;
		b = i /10%10;
		c = i % 10;
		if (pow(a, 3) + pow(b, 3) + pow(c, 3)==i)
		{
			cout << i << endl;
		}
	}
}

int main()
{
	cout << "100-2-013" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

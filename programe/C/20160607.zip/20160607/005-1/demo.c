#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main()
{
	int n[101] = { 0 };

	int index = 0;

	for (int i = 0; i < 98; i++)
		n[i] = i % 50;
	n[98]=50;
	n[99] = 48;
	n[100] = 49;
	for (int i = 0; i < 101; i++)
	{
		index = 0;
		for (int j = 0; j < 101; j++)
		{
			if (n[i]==n[j])
			{
				//printf("%d:%d->%d\n", n[i], n[j], n[i] ^ n[j]);
				//break;
				index++;
			}
		}
		if (index == 1)
		{
			printf("%d\n", n[i]);
		}
	}


	getchar();
	getchar();
	return 0;
}
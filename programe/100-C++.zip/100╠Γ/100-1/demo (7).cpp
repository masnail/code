#include <iostream>

using namespace std;

int fun(int *s, int t, int *k)
{
	int max = 0;
	for (int i = 0; i < t;i++)
	{
		if (*s>max)
		{
			max = *s;
			*k = i;
		}
		s++;
	}
	return max;
}
int main()
{
	int arr[7] = { 1545, 1, 15, 48, 5, 5245,545 };
	int *s=arr,*k=new int,max=0;


	max = fun(s, sizeof(arr) / sizeof(int), k);
	cout << *k<<"::"<<max;
	delete k;
	delete s;
	getchar();
	return 0;
}
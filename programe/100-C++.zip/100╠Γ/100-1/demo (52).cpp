#include <iostream>
#include <string>

using namespace std;

string  fun(string p1,string p2)
{
	string stemp = "";
	for (int i = 0; i != p1.length();i++)
	{
		stemp += p1[i];
	}

	for (int j = 0; j != p2.length(); j++)
	{
		stemp += p2[j];
	}
	return stemp;
}

int main()
{
	cout << "100-1-052" << endl;
	cout << "input two string:";
	string p1, p2;
	cin >> p1 >> p2;
	cout<<fun(p1,p2);
	cin.get();
	cin.get();
	return 0;
}
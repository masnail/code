#include <iostream>
#include <string>

using namespace std;

void fun(int a[], int n)
{
	if (a[0] > a[1])
	{
		//esc
		for (int i = 0; i!=5;i++)
		{
			if (n>a[i])
			{
				for (int j = 4; j != i;j--)
				{
					a[j] = a[j - 1];
				}
				a[i] = n;
				break;
			}
		}
	}
	else
	{
		//desc
		for (int i = 0; i != 5; i++)
		{
			if (n < a[i])
			{
				for (int j = 4; j != i; j--)
				{
					a[j] = a[j - 1];
				}
				a[i] = n;
				break;
			}
		}
	}
	for (int i = 0; i != 5; i++)
		cout << a[i];
}

int main()
{
	cout << "100-2-039" << endl;
	int a[5] = {9,7,4,3,0};
	cout << "input a count:";
	int n;
	cin >> n;
	fun(a,n);
	cin.get();
	cin.get();
	return 0;
}

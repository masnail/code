#include <iostream>
#include <string>

using namespace std;

void fun(int n)
{
	if (n>=90)
	{
		cout << "A" << endl;
	}
	else if (n<90&&n>=60)
	{
		cout << "B" << endl;
	}
	else
	{
		cout << "c" << endl;
	}
}

int main()
{
	cout << "100-2-015" << endl;
	cout << "input a count:";
	int n;
	cin >> n;
	fun(n);
	cin.get();
	cin.get();
	return 0;
}

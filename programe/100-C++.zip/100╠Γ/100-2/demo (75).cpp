#include <iostream>
#include <string>

using namespace std;

void fun()
{
	int n;
	cin >> n;
	while (n!=-1)
	{
		for (int i = 0; i < n; i++)
		{
			cout << "*";
		}
		cout << endl;
		cin >> n;
	}
}

int main()
{
	cout << "100-2-088" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

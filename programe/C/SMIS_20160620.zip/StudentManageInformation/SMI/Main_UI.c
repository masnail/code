#include "Main_UI.h"

//��½��֤
void Log()
{
	File_System_Load();
	
	char name[20] = { 0 }, pwd[20] = { 0 },ch=0;
	int index = 0;

	Print_Head();
	printf("\tEnter name:");
	while ((ch = getch()) != 13)
	{
		fflush(stdin);
		if (ch == 8)
		{
			if (index > 0 && index <= 19)
			{
				name[index--] = 0;
				printf("\b \b");
			}
		}
		else if(ch!=32){
			if (index < 19)
			{
				name[index++] = ch;
				putchar(ch);
			}
		}
	}

	memcpy(pwd,Get_Password(),20);

	fflush(stdin);

	
	File_Loging();//������ʼ��
	Log_User(name,pwd);
}

void Log_User(char* name, char* pwd)//��½��֤
//void Log(char* name, char* pwd)//��½��֤
{
	if (Get_user_Head() == NULL)
	{
		printf("\tthe system not have any information!\n");
		printf("\t");
		system("pause");
		exit(-1);
	}
	userlist p = Get_user_Head()->next;

	while (p)
	{
		if (0 == strcmp(name,p->name) && 0 == strcmp(pwd,p->pwd))
		{
			if ('7'==p->power)
			{
				Log_Info = 9;
			}
			else
			{
				Log_Info = 2;
			}
			memcpy(log_name, p->name,20);
			break;
		}
		p = p->next;
	}
	if (NULL == p)
	{
		printf("\n\tthe system is close!\n\t");
		system("pause");
		exit(-1);
	}

	if (Log_Info == 9){
		Main_Show_User();
	}
	else if (Log_Info == 2){
		Main_Show_Student();
	}
}

int Get_Power()//�鿴Ȩ��
{
	return Log_Info;
}

char* Get_Name()
{
	return log_name;
}

//��ӭ����
void Print_Welcome()
{
	system("CLS");
	Print_Head();
	printf("\t\tWelcome  user\t%s\t\n\n\n", toupper(Get_Name()));
}

void Print_Head()
{
	for (int i = 0; i < CNT; i++)
	{
		printf("*");
	}
	printf("\n");
	printf("\n");

	printf("\t\t Student\tInformation\tManage\tSystem");

	printf("\n");
	printf("\n");
	for (int i = 0; i < CNT; i++)
	{
		printf("*");
	}
	printf("\n");
}

//������
void Print_Student_Head()
{
	printf(STU_HEAD);
}

void Print_User_Head()
{
	printf(USER_HEAD);
}

//��½������
void Main_Show_Student()//com
{
	system("CLS");
	Print_Welcome();

	printf("\t--------------------student--------------------\n");

	printf("\t1��	Search	student	information\n");
	printf("\t2��	Exit\n");
	Main_Input();
}

void Main_Show_User()//root
{
	system("CLS");
	Print_Welcome();

	printf("\t--------------------student--------------------\n");
	printf("\t1��	Search	student	information\n");
	printf("\t2��	Add	student	information\n");
	printf("\t3��	Update	student	information\n");
	printf("\t4��	Delete	student information\n");
	printf("\t----------------------user---------------------\n");
	printf("\t5��	Search	user	count\n");
	printf("\t6��	Add	user	count\n");
	printf("\t7��	Update	user	count\n");
	printf("\t8��	Delte	user	count\n");
	printf("\t9��	exit\n");
	Main_Input();

}

//��������
void Main_Input()
{
	 int getin = 0;
	 fflush(stdin);
		printf("\tInput you choose: ");
		scanf("%d", &getin);
		if (getin>Get_Power())
		{
			printf("\tYou choose is error!\n\n");
			goto label_end;
			//goto label;
		}

		if (getin == Get_Power())
		{
			exit(-1);
		}

		switch (getin)
		{
		case 1:Search_Show();
			break;
		case 2:Add_Student_Show(); 
			break;
		case 3:Update_Student_Show();
			break;
		case 4:Delete_Student();
			break;
		case 5:Search_User_Show(); 
			break;
		case 6:Add_User_Show();
			break;
		case 7: Update_User_Show(); 
			break;
		case 8:Delete_USer();
			break;
		case 9:exit(-1);
		default:
			printf("\tinput have error!\n");
		}
		printf("\t");
		system("pause");
label_end:		Main_Show_User();//ret

}

//���봦��
char* Get_Password()
{
	int index = 0;
	char pwd[20] = { 0 },ch=0;

	printf("\n\tEnter password:");
	//getchar();
	while ((ch = getch()) != 13)
	{
		fflush(stdin);
		if (ch == 8)
		{
			if (index > 0 && index <= 19)
			{
				pwd[index--] = 0;
				printf("\b \b");
			}
		}
		else if(ch!=32){
			if (index < 19)
			{
				pwd[index++] = ch;
				printf("*");
			}
		}
	}
	return pwd;
}
/*************************************************************************
* Author: MASnail
* Created Time: 2016年08月01日 星期一 20时07分28秒
* File Name: singleton_v1.cc
* Description: C++ file
************************************************************************/
#include <iostream>
#include <pthread.h>
#include <stdlib.h>

using std::cout;
using std::cin;
using std::endl;
/*
 *
 * 单例模式
 *
 * 自动释放版本V3.0
 *
 * 实现形式：pthread_once()
 *
 * 原理:give the function only run once
 *
 * 线程间是安全的，在多线程中，可以防止多个线程同时产生多个对象
 *
 */
class Factory
{
    public:
	static Factory* getInstance()
	{
	    pthread_once(&_once,initFactory);
	    return _fac;
	}
	static void initFactory()
	{
	    atexit(destroy);
	    _fac=new Factory;
	}
	static void destroy() 
	{
	    delete _fac;
	}
	void create_a()
	{
	    cout<<"A CPU"<<endl;
	}
    private:
	Factory()
	{ 
	    cout<<"Factory"<<endl;
	}
	~Factory()
	{ cout<<"~Factory"<<endl;}
    private:
	static Factory * _fac;
	static pthread_once_t _once;
};
Factory*  Factory::_fac=NULL;
pthread_once_t Factory::_once=PTHREAD_ONCE_INIT;


int main(int argc,char *argv[])
{
    Factory::getInstance()->create_a();
    Factory::getInstance()->create_a();
    return 0;


    
}


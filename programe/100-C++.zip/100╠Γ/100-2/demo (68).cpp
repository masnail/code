#include <iostream>
#include <string>

using namespace std;

void fun()
{
	for (int i = 10; i != 100;i++)
	{
		if (/*809*i==800*i+9*i+1*/8*i>9&&8*i<100&&9*i>99&&9*i<1000)
		{
			cout << i << endl;
			cout << "809*?? = " << 809 * i << endl;
		}
	}
}

int main()
{
	cout << "100-2-081" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
#include <iostream>
#include <string>

using namespace std;

typedef struct
{
	string num;
	int score;
}student;

void fun(student s[],int length)
{
	for (int i = 0; i != length;i++)
	{
		student stud = s[i];
		int index = i;
		for (int j = i; j != length; j++)
		{
			if (stud.score<s[j].score)
			{
				stud = s[j];
				index = j;
			}
		}
		s[index] = s[i];
		s[i] = stud;
	}
}
int GetLength(student s[])
{
	int index = 0;
	while (s[index].num!="0")
	{
		index++;
	}
	return index;
}

int main()
{
	cout << "100-1-046" << endl;
	//"0"��Ϊ������
	student stu[] = {
		{"2011",80},
		{"2012",90},
		{"2013",87},
		{"2014",75},
		{"2015",100},
		{ "0", 100 }
	};
	fun(stu,GetLength(stu));
	for (int j = 0; j != GetLength(stu); j++)
	{
		cout << stu[j].num << "\t" << stu[j].score << endl;;
	}
	cin.get();
	cin.get();
	return 0;
}
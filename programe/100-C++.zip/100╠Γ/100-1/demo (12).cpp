#include <iostream>

using namespace std;

double fun(int a[5][5])
{
	double sum = 0;
	for (int i = 0; i < 5;i++)
	{
		sum += a[0][i];
		sum += a[4][i];
		if (i>1 && i < 5)
		{
			sum += a[i][0];
			sum += a[i][4];
		}
	}
	return sum/16;
}

int main()
{
	int a[5][5]={
		{ 1, 23, 1, 1, 2 },
		{ 1, 1, 1, 1, 1 },
		{ 1, 1, 1, 1, 1 },
		{ 1, 1, 1, 1, 1 },
		{ 1, 1, 1, 1, 1 },
	};
	double s = fun(a);
	cout << s << endl;
	getchar();
	return 0;
}
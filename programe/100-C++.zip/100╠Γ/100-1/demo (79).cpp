#include <iostream>
#include <string>

using namespace std;

typedef struct
{
	string num;
	int score;
}student;

void fun(student s[], student *stu)
{
	int index = 0;
	while (index!=4)
	{
		if (s[index].score <stu->score)
		{
			stu[0]=s[index];
		}
		index++;
	}
}

int main()
{
	cout << "100-1-079" << endl;
	student s[] = {
		{ "2011", 98 },
		{ "2012", 89 },
		{ "2013", 90 },
		{ "2014", 91 }
	};
	student *stu=new student;
	stu->num = "";
	stu->score = 100;
	fun(s, stu);
	cout << stu->num<<":"<<stu->score;
	cin.get();
	cin.get();
	return 0;
}
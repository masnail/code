#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define MAX 256

/*
 *
 *�ּ𵥴�
 *
 *
 *
 */
void ChooseWord(char ch[])
{
	//ͳһǰ�ո�󵥴�
	int cnt = 0,index=0;

	if (ch[0] == 0)
		goto label;
	if (ch[0] != 32)
	{
		cnt++;
		while (ch[index] != 32 && ch[index])
		{
			if (ch[index]){
				index++;
			}
		}
	}

	while (ch[index]&&ch[index+1])
	{
		if (ch[index] == 32 &&ch[index + 1] != 32){
			cnt++;
		}
		index++;
	}

label:	printf("Output��%d\n", cnt);
}

int main()
{
	char ch[MAX] = { 0 };
	while (gets(ch) != EOF){
		ChooseWord(ch);
	}

	getchar();
	getchar();
	return 0;
}
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define M 256
#define N 10

/*
*
*С��û�п��ǵ�
*/
int main()
{
	int n;
	int index = 0, sum = 0;
	while (scanf("%d", &n) != EOF)
	{
		index = 0; sum = 0;
		while (n != 0)
		{
			
			sum += pow(2, index)*(n % N);
			n /= N;
			index++;
		}
		printf("shijinzhi=%d\n", sum);
	}
	getchar();
	getchar();
	return 0;
}
#include <iostream>
#include <string>

using namespace std;

void fun()
{
	cout << " *******************" << endl;
	cout << " *******************" << endl;
	cout << " *******************" << endl;
	cout << "***" << endl;
	cout << "***" << endl;
	cout << "***" << endl;
	cout << "***" << endl;
	cout << "***" << endl;
	cout << "***" << endl;
	cout << "***" << endl;
	cout << "***" << endl;
	cout << "***" << endl; 
	cout << "***" << endl;
	cout << "***" << endl;
	cout << "***" << endl;
	cout << "***" << endl;
	cout << "********************" << endl;
	cout << "********************" << endl;
	cout << " *******************" << endl;
}

int main()
{
	cout << "100-2-006" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
} 
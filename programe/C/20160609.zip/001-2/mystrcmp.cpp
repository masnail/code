#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/*
*
* copy
*
*
*/
void mystrcmp(char str1[], char str2[])
{
	int index = 0,temp=0;
	while (str1[index]&&str2[index])
	{
		if (str1[index]>str2[index])
		{
			temp = 1;
			break;
		}else if (str1[index]<str2[index])
		{
			temp = -1;
			break;
		}
		index++;
	}
	if (temp==0)
	{
		if (str1[index])
		{
			temp = 1;
		}
		else if (str2[index])
		{
			temp = -1;
		}
	}
	printf("%d\n",temp);
}

int main()
{
	char str1[] = { "1234" };
	char str2[] = { "123456" };
	mystrcmp(str1,str2);
	mystrcmp(str2,str2);
	mystrcmp(str2,str1);
	getchar();
	getchar();
	return 0;
}
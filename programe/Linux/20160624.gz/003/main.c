#include <stdio.h>

void show(char*);

int main(int argc,char *argv[])
{

	char ch[20]="hello world!";

	show(ch);
	

	return 0;
}


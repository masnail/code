#include <iostream>
#include <string>

using namespace std;

bool Primer(int n)
{
	for (int i = 2; i <=n / 2; i++)
	{
		if (n%i == 0)
			return false;
	}
	return true;
}

void fun(int n)
{
	double sum = 0;
	for (int i = 3; i <=n; i++)
	{
		if (Primer(i))
		{
			//cout << i<<endl;
			sum += sqrt(double(i));
		}
	}
	cout << sum << endl;
}

int main()
{
	cout << "100-1-099" << endl;
	cout << "input a count(2-100):";
	int n;
	cin >> n;
	fun(n);
	cin.get();
	cin.get();
	return 0;
}

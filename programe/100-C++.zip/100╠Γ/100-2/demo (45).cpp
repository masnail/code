#include <iostream>
#include <string>

#define pp(x) x*x
#define PI 3.141592

#define EQUAL =

#define swap(a,b){\
	int t = a;\
	a = b;\
	b = t;\
}

using namespace std;

void fun()
{
	int a = 888, b = 33;
	cout << "#define pp(x) x*x: " <<pp(99)<< endl;
	cout << "#define PI 3.141592: " <<PI << endl;

	cout << "#define EQUAL =: "<<(a EQUAL b)<<endl;
	
	swap(a,b);
	cout << "#define swap(a,b): " << "a="<<a<<"b="<<b<< endl;

}

int main()
{
	cout << "100-2-046-47-48" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <string>

#define MAX 9999999

using namespace std;

void fun()
{
	for (int i = 1; i != MAX;i++)
	{
		int a = sqrt(i + 100);
		int b = sqrt(i + 168);
		if (a*a==i+100&b*b==i+168)
		{
			cout << i<<endl;
		}
	}
}

int main()
{
	cout << "100-2-003" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
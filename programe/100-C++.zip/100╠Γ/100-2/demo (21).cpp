#include <iostream>
#include <string>

using namespace std;

void fun()
{
	int index = 1;
	for (int i = 0; i != 9;i++)
	{
		index = (index + 1) * 2;
	}
	cout << index << endl;
}

int main()
{
	cout << "100-2-021" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

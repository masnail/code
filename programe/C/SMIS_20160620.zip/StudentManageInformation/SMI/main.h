#ifndef MAIN_H
#define MAIN_H

//function
#include "Add_Student_User.h"
#include "Delete_Student_User.h"
#include "File_RW.h"
//#include "Search_Student.h"
#include "Search_User.h"
#include "Update_Student_User.h"

//UI
//#include "Main_UI.h"
#include "Search_UI.h"
#include "Add_UI.h"
#include "Update_UI.h"
#include "Delete_UI.h"


#endif
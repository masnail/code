#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

void fun(int n)
{
	double index = 1,sum = 0;
	while (index!=2*n+1)
	{
		sum += (1/index-1/(index+1));
		index+=2;
	}
	cout <<setprecision(6)<<fixed<< sum << endl;
}

int main()
{
	cout << "100-1-090" << endl;
	cout << "input a count(0-100):";
	int n;
	cin >> n;
	fun(n);
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <cstdlib>
#include <string>

using namespace std;

extern int sum = 0;
void fun()
{
	register int i ;
	for (i = 0; i != 10;i++)
	{
		sum += i;
	}
	cout << sum << endl;
}

int main()
{
	cout << "100-2-044-45" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

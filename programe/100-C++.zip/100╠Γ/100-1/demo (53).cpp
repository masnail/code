#include <iostream>
#include <string>

using namespace std;

void fun(int a[][3],int b[][3])
{
	for (int i = 0; i != 3;i++)
	{
		for (int j = 0; j != 3;j++)
		{
			b[i][j] = a[i][j] + a[j][i];
		}
	}
}

int main()
{
	cout << "100-1-053" << endl;
	int a[][3] = {
		{212,15,21},
		{15,15,485},
		{999,774,1}
	};
	int b[][3] = { 0 };
	fun(a,b);
	for (int i = 0; i != 3; i++)
	{
		for (int j = 0; j != 3; j++)
		{
			cout<<b[i][j]<<"\t" ;
		}
		cout << endl;
	}
	cin.get();
	cin.get();
	return 0;
}
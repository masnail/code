#include <iostream>
#include <string>

using namespace std;

typedef struct node
{
	int data;
	struct node *next;
}node,*linknode;

void fun(linknode f,linknode s)
{
	linknode p = f;
	while (p->next)
	{
		p = p->next;
	}
	p->next = s;


	int index = 0;
	p = f;
	while (p/*&&index<21*/)
	{
		index++;
		cout << p->data << endl;
		p = p->next;
	}
}

int main()
{
	cout << "100-2-074" << endl;

	linknode first = (linknode)malloc(sizeof(node)), p = first,
		second = (linknode)malloc(sizeof(node)),q=second;
	first->data = 0;
	first->next = NULL;
	second->data = 0;
	second->next = NULL;
	for (int i = 1; i != 10; i++)
	{
		linknode pp = (linknode)malloc(sizeof(node));
		linknode ppp = (linknode)malloc(sizeof(node));
		pp->data = i;
		pp->next = p->next;
		p->next = pp;
		p = pp;

		ppp->data = i + 10;
		ppp->next = q->next;
		q->next = ppp;
		q = ppp;
		//cout << i;
	}
	//p->next=NULL;
	//q->next=NULL;

	
	fun(first,second);
	cin.get();
	cin.get();
	return 0;
}
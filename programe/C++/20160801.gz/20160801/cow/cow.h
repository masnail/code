/*************************************************************************
* Author: MASnail
* Created Time: 2016年08月01日 星期一 21时27分48秒
* File Name: cow.h
* Description: HEAD File
*************************************************************************/
#ifndef __COW_H_
#define __COW_H_

#include <iostream>
#include <string.h>

using std::cout;
using std::ostream;
using std::endl;

class String
{
    public:
	String();
	String(const String &);
	String(const char *);
	String(const char);
	~String();
	String & operator=(const String &);
	char &operator[](int);
	char &operator[](int)const;
	friend ostream & operator<<(ostream &,const String &);
	int length()const;
	int getRefCnt()const;
//	char * c_str();

    private:
	void initRefCnt();
	void descRefCnt();
	void increaseRefCnt();
    private:
	char *_pstr;
};
#endif

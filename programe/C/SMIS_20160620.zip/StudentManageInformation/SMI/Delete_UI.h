#include "head.h"


//ѧ��
void Delete_Student();

//�û�
void Delete_USer();
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#define NLEAP 365


/*
*
*�������  ��ӡ����
*
*
*/
int CountDay(int year, int month, int day)
{//from 1.1->now 
	int sum = 0;
	int today[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	for (int i = 0; i < month - 1; i++)
	{
		sum += today[i];
	}

	if ((year % 4 == 0 && year % 100 != 0 || year % 400 == 0) && (month>2))
	{//ע����ŵ����ȼ�
		sum += 1;
	}
	sum += day;
	//printf("today is %d day\n", sum);
	return sum;
}
int ISLeapYear(int year)
{//is leap?
	if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int TheDay(int fyear, int fmonth, int fday, int syear, int smonth, int sday)
{
	//ʱ��Ĳ�ֵ
	int count = 0;//the day
	if (fyear == syear)
	{
		count = CountDay(syear, smonth, sday) - CountDay(fyear, fmonth, fday);
	}
	else{
		count = NLEAP + ISLeapYear(fyear) - CountDay(fyear, fmonth, fday) + CountDay(syear, smonth, sday);
	}

	//printf("****** %d%d%d---%d%d%d day is %d\n", fyear, fmonth, fday, syear, smonth, sday, count);
	for (int i = fyear + 1; i < syear; i++)
	{
		count += NLEAP + ISLeapYear(i);
	}


	//printf("%d%d%d---%d%d%d day is %d", fyear, fmonth, fday, syear, smonth, sday, count);
	return count;
}
int TheWeek(int fyear, int fmonth, int fday, int syear, int smonth, int sday)
{//��������
	int days;//between syear and syear
	if (fyear > syear || fyear == syear&&fmonth < smonth || fyear == syear&&fmonth == smonth&&fday < sday)
	{
		//before
		days = TheDay(syear, smonth, sday, fyear, fmonth, fday);
		days = (7 - days % 7) % 7;
	}
	else{
		//behind
		days = TheDay(fyear, fmonth, fday, syear, smonth, sday);
		days %= 7;
	}

	//printf("%d\n", days);
	return days;
}
int main()
{
	//2000-1-2 ����

	int fyear = 2000, fmonth = 1, fday = 2, syear, sday = 1;

	printf("input second:");
	scanf("%d", &syear);

	int wdayL/* = TheWeek(fyear, fmonth, fday, syear, 1, sday)*/;//left ��
	int wdayR /*= TheWeek(fyear, fmonth, fday, syear, 7, sday)*/;//right ��

	int monthL = 1;
	int monthR = 7;

	int mdayL = 1;
	int mdayR = 1;

	int today[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	today[1] += ISLeapYear(syear);

	//main() left and right
	//////////////////////////////////////////////////////////////////////////
	
	for (int i = 0; i < 8; i++)
	{
		if (i==0)
		{//top
			for (int i = 0; i < 26;i++)
			{
				printf("--");
			}
			printf("The Calender of Year %d", syear);
			for(int i = 0; i < 26; i++)
			{
				printf("--");
			}
			printf("\n");
		}else if (i==7)
		{//base
			for (int i = 0; i < 40; i++)
			{
				printf("--");
			}
		}
		else{//mid
			//�˴����ֲ�����  ���� �����
		printf("| %d\tSUN\tMON\tTUE\tWED\tTHU\tFRI\tSAT\t%d\tSUN\tMON\tTUE\tWED\tTHU\tFRI\tSAT\t\t|\n", monthL, monthR);

			//get week
			wdayL = TheWeek(fyear, fmonth, fday, syear, monthL, sday);
			wdayR = TheWeek(fyear, fmonth, fday, syear, monthR, sday);
			//printf("%d", wdayL);
			while (mdayL <= today[monthL - 1] || mdayR <= today[monthR - 1])
			{
				//printf("%d\tSUN\tMON\tTUE\tWED\tTHU\tFRI\tSAT\n", monthL);
				printf("|");
				for (int j = 0; j <= wdayL; j++)
				{
					printf("\t");
				}
				while (wdayL <= 6)
				{
					if (mdayL <= today[monthL - 1])
					{
						printf("%d", mdayL++);
					}
					printf("\t");
					wdayL++;
				}

				//////////////////////////////////////////////////////////////////////////
				//printf("%d\tSUN\tMON\tTUE\tWED\tTHU\tFRI\tSAT\n", monthR);
				for (int j = 0; j <= wdayR; j++)
				{
					printf("\t");
				}
				while (wdayR <= 6)
				{
					if (mdayR <= today[monthR - 1])
					{
						printf("%d", mdayR++);
					}
					printf("\t");
					wdayR++;
				}

				//printf("::%d\tSUN\tMON\tTUE\tWED\tTHU\tFRI\tSAT\n", mdayL);

				wdayL = 0;
				wdayR = 0;
				printf("|\n");
			}//one month

			mdayL = 1;
			mdayR = 1;
			monthL++;
			monthR++;

		}
	}//six month 


	getchar();
	getchar();
	return 0;
}
/*************************************************************************
* Author: MASnail
* Created Time: 2016年08月03日 星期三 23时33分47秒
* File Name: singleton_template.cc
* Description: C++ file
************************************************************************/

#ifndef __SINGLETON_TEMPLATE_H_
#define __SINGLETON_TEMPLATE_H_

#include <iostream>
#include <stdlib.h>

using std::cout;
using std::cin;
using std::endl;

template <typename T>
class Earth 
{
    public:
	static T * getInstance();
	static void destroy();
	void show();
    private:
	Earth();
	~Earth();
    private:
      static  T *_psingle;
      T *_pt;
};

template <typename T>
T * Earth<T>::_psingle=getInstance();

template <typename T>
Earth<T>::Earth()
{
    cout<<"Earth()"<<endl;
}

template <typename T>
Earth<T>::~Earth()
{
    cout<<"~Earth()"<<endl;
}

template <typename T>
T* Earth<T>::getInstance()
{
    if(_psingle==NULL)
    {
	atexit(destroy);
	_psingle=new T;
    }
    return _psingle;
}

template <typename T>
void Earth<T>::destroy()
{
    if(_psingle!=NULL)
	delete _psingle;
}

template <typename T>
void Earth<T>::show()
{
    cout<<"we have only one EARTH!"<<endl;
}


#endif

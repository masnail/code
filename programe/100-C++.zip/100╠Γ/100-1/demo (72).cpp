#include <iostream>
#include <string>

using namespace std;

void fun(string s,char *t)
{
	for (int i = 1; i < s.length(); i+=2,t++)
	{
		if (s[i]!=NULL)
		{
			*t = s[i];
		}
	}
}

int main()
{
	cout << "100-1-072" << endl;
	string str;
	char *t=new char;
	cout << "input a string��";
	cin >> str;
	
	fun(str,t);

	while (*t)
	{
		cout << *t;
		t++;
	}
	cin.get();
	cin.get();
	return 0;
}
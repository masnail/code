/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月26日 星期二 16时45分22秒
* File Name: log4cpp.cc
* Description: C++ file
************************************************************************/
#include <iostream>
#include <sstream>

#include "log4cpp/Category.hh"
#include "log4cpp/OstreamAppender.hh"
#include "log4cpp/Priority.hh"
#include "log4cpp/BasicLayout.hh"
#include "log4cpp/PatternLayout.hh"
#include "log4cpp/StringQueueAppender.hh"
#include "log4cpp/FileAppender.hh"
#include "log4cpp/RollingFileAppender.hh"

using std::cout;
using std::cin;
using std::endl;
using std::queue;
using std::string;
using std::ostringstream;
using namespace log4cpp;


/*
 * test user
 * default layout
 */
int test(void)
{
    OstreamAppender  *osAppender=new OstreamAppender("osAppender",&cout);
    osAppender->setLayout(new BasicLayout());
    Category &root=Category::getRoot();
    root.addAppender(osAppender);
    root.setPriority(Priority::DEBUG);
    root.error("system error");
    root.warn("system warn");
    root.fatal("system fatal");
    root.crit("system crit");
    Category::shutdown();
    return 0;
}

/*
 *patternlayout
 */
int test1()
{
    OstreamAppender *osAppender=new OstreamAppender("osAppender" ,&cout);

    PatternLayout *pLayout=new PatternLayout();
    pLayout->setConversionPattern("%d: %p %c %x :%m%n");
    osAppender->setLayout(pLayout);

    Category &root=Category::getRoot();
    root.addAppender(osAppender);
    root.setPriority(Priority::DEBUG);
    root.error("system error");
    root.warn("system warn");
    root.fatal("system fatal");
    root.crit("system crit");
    Category::shutdown();
    return 0;
}

/*
 * StringQueueAppender
 *
 */
int test2()
{
    StringQueueAppender *strQueueAppender=new StringQueueAppender("strQueueAppender");
    PatternLayout *pLayout=new PatternLayout();
    pLayout->setConversionPattern("%d:%p %c %x:%m%n");
    strQueueAppender->setLayout(pLayout);
    Category &root=Category::getRoot();
    root.addAppender(strQueueAppender);
    root.setPriority(Priority::DEBUG);
    root.error("system error");
    root.warn("system warn");
    root.fatal("system fatal");
    root.crit("system crit");
    cout<<"------------------------------------"<<endl;
    queue <string> & mystr=strQueueAppender->getQueue();
    while(!mystr.empty())
    {
	cout<<mystr.front()<<endl;
	mystr.pop();
    }

    Category::shutdown();
    return 0;

}

/*
 * RollingFileAppender/FileAppender
 *
 */
int test3()
{
    PatternLayout *pLayout1=new PatternLayout();
    pLayout1->setConversionPattern("%d:%p %c %x:%m%n");

    PatternLayout *pLayout2=new PatternLayout();
    pLayout2->setConversionPattern("%d:%p %c %x:%m%n");
    
    FileAppender *fAppender=new FileAppender("fAppender","flog");
    fAppender->setLayout(pLayout1);

    RollingFileAppender *rfAppender=new RollingFileAppender("rfAppender","rflog",5*1024,1);
	rfAppender->setLayout(pLayout2);

    Category &root=Category::getRoot();
    root.addAppender(fAppender);
    root.addAppender(rfAppender);
    root.setPriority(Priority::DEBUG);

    for(int i=0;i<2000;i++)
    {
	string strError;
	ostringstream oss;
	oss<<i<<"test msg"<<endl;
	strError=oss.str();
	root.error(strError);
    }

    Category::shutdown();
    return 0;
}

/*
 * getInstance
 */
int test4()
{
    PatternLayout *pLayout1=new PatternLayout();
    pLayout1->setConversionPattern("%d:%p %c %x:%m%n");

    PatternLayout *pLayout2=new PatternLayout();
    pLayout2->setConversionPattern("%d:%p %c %x:%m%n");
    
    OstreamAppender *ostringstream1=new OstreamAppender("ostringstream1",&cout);
    ostringstream1->setLayout(pLayout1);

    OstreamAppender *ostringstream2=new OstreamAppender("ostringstream2",&cout);
	ostringstream2->setLayout(pLayout2);

    Category &root=Category::getRoot();
    root.setPriority(101);

    Category &root1=root.getInstance("root1");
    root1.addAppender(ostringstream1);
    root1.error("system error");
    root1.warn("system warn");
    root1.fatal("system fatal");
    root1.crit("system crit");

    Category &root2=root.getInstance("root3");
    root2.addAppender(ostringstream2);
    root2.setPriority(Priority::DEBUG);
    root2.error("system error");
    root2.warn("system warn");
    root2.fatal("system fatal");
    root2.crit("system crit");

    
    Category::shutdown();
    return 0;
}

int main()
{
    test3();
    return 0;
}


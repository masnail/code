#include <iostream>
#include <string>

using namespace std;

void fun()
{

}

int main()
{
	cout << "100-2-094" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <string>

using namespace std;

void fun(int a)
{
	double money = 0;
	switch (a/10)
	{
	case 0:
		money = 0;
		break;
	case 1:
		money = 10*0.1+(a - 10)*0.075;
		break;
	case 2:
		money = 10 * 0.1 + 10 * 0.075 + (a - 20)*0.05;
		break;
	case 3:
		money = 10 * 0.1 + 10 * 0.075 + (a - 20)*0.05;
		break;
	case 4:
		money = 10 * 0.1 + 10 * 0.075 + 20*0.05+(a-40)*0.03;
		break;
	case 5:
		money = 10 * 0.1 + 10 * 0.075 + 20 * 0.05 + (a - 40)*0.03;
		break;
	case 6:
		money = 10 * 0.1 + 10 * 0.075 + 20 * 0.05 + 20*0.03+(a-60)*0.015;
		break;
	case 7:
		money = 10 * 0.1 + 10 * 0.075 + 20 * 0.05 + 20 * 0.03 + (a - 60)*0.015;
		break;
	case 8:
		money = 10 * 0.1 + 10 * 0.075 + 20 * 0.05 + 20 * 0.03 + (a - 60)*0.015;
		break;
	case 9:
		money = 10 * 0.1 + 10 * 0.075 + 20 * 0.05 + 20 * 0.03 + (a - 60)*0.015;
		break;
	default:
		money = 10 * 0.1 + 10 * 0.075 + 20 * 0.05 + 20 * 0.03 +40*0.015 +(a - 100)*0.01;
		break;
	}
	cout << money << endl;
}

int main()
{
	cout << "100-2-002" << endl;
	cout << "input a count(��):";
	int a;
	cin >> a;
	fun(a);
	cin.get();
	cin.get();
	return 0;
}
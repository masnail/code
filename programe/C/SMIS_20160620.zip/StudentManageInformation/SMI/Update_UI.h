#include "head.h"
#include "Update_Student_User.h"
#include "Main_UI.h"

//ѧ��
void Update_Student_Show();

void Update_Choose_Show();


//�û�
void Update_Student_Show();
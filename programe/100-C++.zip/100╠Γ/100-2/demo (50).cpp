#include <iostream>
#include <string>

using namespace std;

void fun()
{
	cout << "��λȡ����" << endl;
	int a = 111;
	cout << ~a << endl;
}

int main()
{
	cout << "100-2-055" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

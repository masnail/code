#include "Delete_Student_User.h"

/*
*
*
* ѧ����Ϣ��ɾ��
*
*/

void Delete_Student_Info(int ptemp)//ɾ��ѧ������Ϣ���������ļ�
{
	stulist head = Get_stu_Head();

	stulist p = (head)->next,pre=(head);
	
	while (p)
	{
		if (p->num==ptemp)
		{
			pre->next = p->next;
			head->num -= 1;
			free(p);
			File_Write_Student();
			printf("\tthe student information already is delete!\n");
			return;
		}
		pre = p;
		p = p->next;
	}

	printf("\terror,the student is not have!\n");
	
}

/*
*
*
* �û���Ϣ��ɾ��
*
*/

void Delete_User_Info( char *ptemp)//ɾ���û�����Ϣ���������ļ�
{
	userlist head = Get_user_Head();
	userlist p = (head)->next, pre = (head);

	while (p)
	{
		if (strcmp(p->name, ptemp) == 0)
		{
			if (strcmp(p->name, "admin") == 0 || strcmp(p->name, Get_Name()) == 0)
			{
				printf("\tyou permission denied!\n");
				return;
			}
			pre->next = p->next;
			free(p);
			File_Write_User();
			printf("\tthe user information already is delete!\n");
			return;
		}
		pre = p;
		p = p->next;
	}

	printf("\terror,the user is not have!\n");

}
#include <iostream>

using namespace std;

void fun(int p[],int *max,int *index,int lenp)
{
	for (int i = 0; i < lenp;i++)
	{
		if (*max<p[i])
		{
			*max = p[i];
			*index = i;
		}
	}
}
int main()
{
	cout << "100-1-028" << endl;
	int  x[15] = {54,145,15,1,2,42,15,1,5,1,2,5,854,55545,4},n=15;
	int *max = new int, *index = new int;
	fun(p, max, index, n);
	cout << *index <<":" <<*max << endl;
	cin.get();
	cin.get();
	return 0;
}
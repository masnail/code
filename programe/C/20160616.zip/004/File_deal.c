#include "head.h"

void stulist_show(stuinfolist head)
{
	stuinfolist pstu = head->next;
	stu s;
	while (pstu!=NULL)
	{
		s = *pstu->s;
		printf("%s %s %c %5.2f %5.2f %5.2f\n",s.num, s.name, s.sex, s.score1, s.score2, s.score3);
		pstu = pstu->next;
	}
	printf("\n");
}

void File_Read(char *ReadName, stuinfolist *head)
{
	FILE *fp;

	stu stud;
	stuinfolist p = (*head);
	stuinfolist q;

	if ((fp=fopen(ReadName,"rb"))!=EOF)
	{
		while (fscanf(fp, "%s\t%s\t%c\t%f\t%f\t%f", stud.num, stud.name, &stud.sex, &stud.score1, &stud.score2, &stud.score3) >0)
		{
			//ͷ�巨
			q = (stuinfolist)malloc(sizeof(studinfo));
			*q->s = stud;
			q->next = p->next;
			p->next = q;
			stucnt+=1;
			printf("%s %s %c %f %f %f\n", stud.num, stud.name, stud.sex, stud.score1, stud.score2, stud.score3);
			memset(&stud, 0, sizeof(stud));
		}
		
	}else{
		printf("��ȡ�ļ���ʱ�����\n");
		exit(-1);
	}
}

void File_Write(char *writename, stu *s)
{
	FILE *fp;

	if ((fp=fopen(writename,"a"))!=NULL)
	{
		if(fwrite(&s,sizeof(stu),1,fp))
		//if (fputs(s, fp) == EOF)
		{
			printf("д���ļ���ʱ������\n");
			exit(-1);
		}		
	}else{
		printf("д���ļ���ʱ����ļ�������\n");
			exit(-1);
	}
	fclose(fp);
}

int compare(const void *p, const void *q)
{
	stu *ps = (stu*)p;
	stu *qs = (stu*)q;
	return ((qs)->score1 + (qs)->score2 + (qs)->score3) - ((ps)->score1 + (ps)->score2 + (ps)->score3);
}
void sort_stuinfo(char *writename,stuinfolist head)
{
	int index = 0;

	stu *s = (stu*)malloc(stucnt*sizeof(stu));
	stuinfolist pstu = head->next;

	while (pstu)
	{
		*(s+index++)=*pstu->s;
		pstu = pstu->next;
	}
	qsort(s,stucnt,sizeof(stu), compare);

	FILE *fp;

	if ((fp = fopen(writename, "w")) != NULL)
	{
		fseek(fp, 0, SEEK_SET);
		for (int i = 0; i < stucnt; i++)
		{
			//printf("%d : %s %s %c %5.2f %5.2f %5.2f\n", i, s[i].num, s[i].name, s[i].sex, s[i].score1, s[i].score2, s[i].score3);
			if (fprintf(fp, "%s\t%s\t%c\t%f\t%f\t%f\n", s[i].num, s[i].name, s[i].sex, s[i].score1, s[i].score2, s[i].score3));
				//if (fputs(s, fp) == EOF)
			/*{
				printf("д���ļ���ʱ������\n");
				exit(-1);
			}*/
		}
	}else{
		printf("д���ļ���ʱ����ļ�������\n");
		exit(-1);
	}
	fclose(fp);

	/*for (int i = 0; i < stucnt;i++)
	{
		printf("%d : %s %s %c %5.2f %5.2f %5.2f\n",i, s[i].num, s[i].name, s[i].sex, s[i].score1, s[i].score2, s[i].score3);
		File_Write(writename, &s[i]);
	}*/
}
int Get_stulist_length()
{
	return stucnt;
}
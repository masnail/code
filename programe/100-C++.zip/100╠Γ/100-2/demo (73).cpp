#include <iostream>
#include <string>

using namespace std;

void fun()
{
	char s[] = "djkkdshksfk";
	char h[] = "i9likionklhiko";
	string str = "";
	for (int i = 0; s[i]; i++)
	{
		str += s[i];
	}
	for (int j = 0;h[j]; j++)
	{
		str += h[j];
	}
	cout << str << endl;
}

int main()
{
	cout << "100-2-086" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

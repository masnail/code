#include <iostream>
#include <string>

using namespace std;

void fun(string s,int n)
{
	if (n==0)
	{
		cout << s[n];
		return;
	}
	else
	{
		cout << s[n];
		fun(s,n-1);
	}
}

int main()
{
	cout << "100-2-027" << endl;
	cout << "input a string:";
	string s;
	cin >> s;
	fun(s,s.length());
	cin.get();
	cin.get();
	return 0;
}
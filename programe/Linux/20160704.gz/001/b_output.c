/*************************************************************************
 Author:MASnail
 Created Time: 2016年07月04日 星期一 21时03分01秒
 File Name: b_output.c
 Description 
 ************************************************************************/
#include "head.h"
#include "func_shm.h"
#include "func_sem.h"
#include "func_pipe.h"


int main()
{
	//b_input to show
	int shmid;
	char *p;
	char *buff_time=(char*)malloc(TIME_MEM*sizeof(char));//time

	//shm
	create_shmb(&shmid,&p);

	//sem id
	int semid = create_semb();
	struct sembuf soppw,soppr;
	create_sembufp(&soppr,&soppw);	

	int semid_mutex = create_semb_mutex();
	struct sembuf sopp,sopv;
	create_sembufpv(&sopp,&sopv);
		//	printf("\nsemid=%d-semid_mutex=%d:sem0 %d|sem1 %d|mutex %d\n",semid,semid_mutex,semctl(semid,0,GETVAL),semctl(semid,1,GETVAL),semctl(semid_mutex,0,GETVAL));


	while(1)
	{
		if(0 < semctl(semid,0,GETVAL))
		{
			 semop(semid,&soppr,1);
			//receive data 
			memset(buff_time,0,sizeof(buff_time));
			create_timebuff(&buff_time);
			printf("Rece->A %s\n",buff_time);
			puts(p);
			semop(semid_mutex,&sopv,1);
		}
		if(0 < semctl(semid,1,GETVAL))
		{
			semop(semid,&soppw,1);
			//send data
			memset(buff_time,0,sizeof(buff_time));
			create_timebuff(&buff_time);
			printf("Send->B %s\n",buff_time);
			puts(p);
			semop(semid_mutex,&sopv,1);
		}
		if(-1 == semctl(semid,1,GETVAL))
		{
			if(!buff_time)
				free(buff_time);
			exit(0);
		}
	}
		return 0;
}


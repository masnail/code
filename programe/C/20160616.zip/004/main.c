#include "head.h"

int main()
{
	stuinfolist head = (stuinfolist)malloc(sizeof(studinfo));
	memset(head, 0, sizeof(stu));
	head->next = NULL;
	char stuinfo[] = "stu_info.txt", stuwrite[] = "stu_sort.txt";

	File_Read(stuinfo, &head);
	stulist_show(head);
	sort_stuinfo(stuinfo, head);
	//stulist_show(head->next);
	//File_Write(stuwrite, &head);
	getchar();
	getchar();
	return 0;
}
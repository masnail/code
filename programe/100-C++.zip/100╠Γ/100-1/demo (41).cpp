#include <iostream>
#include <string>

using namespace std;

string fun(char arr[5][3])
{
	string str = "";
	for (int i = 0; i < 3;i++)
	{
		for (int j = 0; j < 5;j++)
		{
			str += arr[j][i];
		}
	}
	return str;
}

int main()
{
	cout << "100-1-041" << endl;
	char s[5][3] = {
		{'12','12','5'},
		{'7','25','14'},
		{'0.1','87','5'},
		{'454','23','21'},
		{'2','1','21'}
	};
	cout<<fun(s);
	cin.get();
	cin.get();
	return 0;
}
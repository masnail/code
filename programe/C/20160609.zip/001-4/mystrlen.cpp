#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/*
*
* copy
*
*
*/
int mystrlen(char str1[])
{
	int index = 0;
	while (str1[index]){
		index++;
	}

	return index;
}

int main()
{
	char str1[] = { "1234" };
	char str2[] = { "123456" };
	printf("%d\n",mystrlen(str1));
	printf("%d\n", mystrlen(str2));

	getchar();
	getchar();
	return 0;
}
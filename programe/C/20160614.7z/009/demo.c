#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct node
{
	int data;
	struct node *next;
}nd, *nodelist;

void list_sort_insert(nodelist *head, nodelist *tail, int data)
{
	nodelist p = (*head)->next, pre = *head;

	while (p != NULL)
	{
		if (p->data < data)
		{
			pre = p;
			p = p->next;
		}
		else{
			break;
		}
	}
	nodelist pnow = (nodelist)malloc(sizeof(nd));
	memset(pnow, 0, sizeof(nd));
	pnow->data = data;
	(*head)->data += 1;
	pnow->next = pre->next;
	pre->next = pnow;

	if (p == NULL)
	{
		*tail = pnow;
	}
}

void list_find_last_four(nodelist *phead,int num)
{
	nodelist p = (*phead)->next, q=p;

	for (int i = 0; i < num;i++)
	{
		p = p->next;
	}

	while (p)
	{
		q = q->next;
		p = p->next;
	}
	printf("%d\n", q->data);
}

void list_show(nodelist head)
{
	nodelist p = head->next;
	while (p)
	{
		printf("%d\t", p->data);
		p = p->next;
	}
	printf("\n");
}

int main()
{
	srand((unsigned)(time(NULL)));

	nodelist phead = (nodelist)malloc(sizeof(nd)), ptail = phead;
	memset(phead, 0, sizeof(nd));
	for (int i = 0; i < 6; i++)
	{
		list_sort_insert(&phead, &ptail, rand() % 100);
	}
	list_show(phead);

	list_find_last_four(&phead,4);

	getchar();
	return 0;

}
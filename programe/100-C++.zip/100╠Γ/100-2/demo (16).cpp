#include <iostream>
#include <string>

using namespace std;

void fun(int a,int b)
{
	int ys = 1;
	for (int i = 2; i != (a + b) / 2+1;i++)
	{
		if (a%i==0&&b%i==0)
		{
			ys = i;
		}
	}
	cout << "���Լ����" << ys<< endl;
	cout << "��С��������" <<a*b/ys << endl;
}

int main()
{
	cout << "100-2-016" << endl;
	cout << "input two count:";
	int a, b;
	cin >> a >> b;
	fun(a, b);
	cin.get();
	cin.get();
	return 0;
}

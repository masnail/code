#include <iostream>
#include <string>

using namespace std;

int fun(int a,int b)
{
	return  a / 10 + a % 10 * 100 + b / 10 * 10 + b % 10 * 1000;
}

int main()
{
	cout << "100-1-077" << endl;
	int a, b;
	cout << "input two count:";
	cin >> a >> b;
	cout<<fun(a,b);
	cin.get();
	cin.get();
	return 0;
}

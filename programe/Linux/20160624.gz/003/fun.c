#include <stdio.h>

void show(char *ch)
{
	int index=0;

	while(*(ch+index))
	{
		printf("%c\n",*(ch+index));
		index++;
	}
}

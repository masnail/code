#include <iostream>
#include <string>

using namespace std;

void fun()
{
	long long int a = 0, b = 1,temp=0;
	for (int i = 1; i != 10;i++)
	{
		cout << "in " << i << " month the count is:" << b << endl;
		temp = b;
		b+=a;
		a=temp;
	}
}

int main()
{
	cout << "100-2-011" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

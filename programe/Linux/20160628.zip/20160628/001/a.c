/*************************************************************************
 Author:MASnail
 Created Time: 2016�?6�?8�?星期�?14�?7�?9�?
 File Name: a.c
 Description: 
 ************************************************************************/

#include "head.h"

int main()
{
/*	int fdr=fd_ReadONLY("2");
	int fdw=fd_WriteONLY("1");
	int max=(fdr>fdw?fdr:fdw)+1;*/

	int fdr=open("1",O_RDONLY);
	if(-1 == fdr)
	{
		perror("open dr");
		return -1;

	}
	int fdw=open("2",O_WRONLY);
	if(-1 == fdw)
	{
		perror("open dw");
		return -1;
	}
	char buff[20];
	int max=((fdr>fdw)?fdr:fdw)+1;
	fd_set set;
	while(1)
	{
		FD_ZERO(&set);
		FD_SET(fdr,&set);
		FD_SET(0,&set);

		memset(buff,0,sizeof(buff));
		int ret=select(max,&set,NULL,NULL,NULL);
		if(FD_ISSET(fdr,&set))
		{
			read(fdr,buff,sizeof(buff));
			puts(buff);
		}
		
		if(FD_ISSET(0,&set))
		{
			read(0,buff,sizeof(buff));
		//	scanf("%s",buff);
			write(fdw,buff,strlen(buff)-1);
		}

	}
	close(fdr);
	close(fdw);

	return 0;

}

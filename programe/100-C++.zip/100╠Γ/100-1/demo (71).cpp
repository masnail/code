#include <iostream>
#include <string>

using namespace std;

int fun(int a,int b)
{
	return a / 10 * 10 + a % 10 * 1000 + b / 10 * 100 + b % 10;
}

int main()
{
	cout << "100-1-071" << endl;
	int a, b;
	cout << "input two count:" << endl;
	cin >> a >> b;
	cout<<fun(a,b);
	cin.get();
	cin.get();
	return 0;
}
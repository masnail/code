#include <iostream>
#include <string>

using namespace std;

void fun(string s)
{
	int ac = 0, sc = 0, dc = 0, oc = 0,index=0;
	while (s[index])
	{
		if (isalpha(s[index]))
		{
			ac++;
		}
		else if (isspace(s[index]))
		{
			sc++;
		}
		else if (isdigit(s[index]))
		{
			dc++;
		}
		else
		{
			oc++;
		}
		index++;
	}
	cout << "alpha:" <<ac << endl;
	cout << "space:" <<sc << endl;
	cout << "digit:" <<dc << endl;
	cout << "other:" <<oc << endl;
}

int main()
{
	cout << "100-2-017" << endl;
	string str;
	cout << "input a line string" << endl;
	getline(cin, str); 
	fun(str);
	cin.get();
	cin.get();
	return 0;
}

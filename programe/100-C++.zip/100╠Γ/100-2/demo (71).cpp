#include <iostream>
#include <string>

using namespace std;

bool ISPrmer(int n)
{
	for (int i = 2; i < n/2 + 1;i++)
	{
		if (n%i==0)
		{
			return false;
		}
	}
	return true;
}

void fun(int count)
{
	for (int i = 1; i != count/2+1;i++)
	{
		if (ISPrmer(i)&&ISPrmer(count-i))
		{
			cout << count << "=" << i << "+" << count - i << endl;
		}
	}
}

int main()
{
	cout << "100-2-084" << endl;
	cout << "input a odd count:";
	int nn;
	cin >> nn;
	fun(nn);
	cin.get();
	cin.get();
	return 0;
}

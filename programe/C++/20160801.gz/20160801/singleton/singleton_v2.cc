 
/*************************************************************************
* Author: MASnail
* Created Time: 2016年08月01日 星期一 20时07分28秒
* File Name: singleton_v1.cc
* Description: C++ file
************************************************************************/
#include <iostream>
#include <stdlib.h>

using std::cout;
using std::cin;
using std::endl;

/*
 *
 * 单例模式
 *
 * 自动释放版本V2.0
 *
 * 实现形式：atexit()
 *
 * 原理：give the function will be called at the normal process termination
 *
 */
class Factory
{
    public:
	static Factory* getInstance()
	{
	    if(_fac==NULL)
	    {
		 atexit(destory);//atexit()--该条件下对象的生命周期中只会调用一次
		 _fac=new Factory;
	    }
	    return _fac;
	}

	static void destory()
	{
	    if(_fac!=NULL)
		delete _fac;
	}

    	void create_a()
	{
	    cout<<"A CPU"<<endl;
	}
    private:
	Factory()
	{  
	   // atexit(destory);//atexit()--只是初始化一次，可用
	    cout<<"Factory"<<endl; 
	}

	~Factory()
	{ cout<<"~Factory"<<endl;}
    private:
	static Factory * _fac;
};
Factory*  Factory::_fac=getInstance();

int main(int argc,char *argv[])
{
    Factory::getInstance()->create_a();
    Factory::getInstance()->create_a();
    
    return 0;


    
}


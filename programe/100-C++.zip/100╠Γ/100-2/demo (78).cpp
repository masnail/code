#include <iostream>
#include <string>
#include <ctime>

using namespace std;

void fun()
{
	cout <<time(0);
}

int main()
{
	cout << "100-2-091-92-93" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

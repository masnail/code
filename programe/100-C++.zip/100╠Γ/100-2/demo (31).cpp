#include <iostream>
#include <string>

using namespace std;

void fun(char ch)
{
	if (ch=='m')
	{
		cout << "1" << endl;
	}
	else if (ch=='t')
	{
		cout << "input again:";
		cin >> ch;
		if (ch=='u')
		{
			cout << "2" << endl;
		}
		else if (ch=='h')
		{
			cout << "4" << endl;
		}
	}
	else if (ch=='w')
	{
		cout << "3" << endl;
	}
	else if (ch=='f')
	{
		cout << "5" << endl;
	}
	else if (ch == 's')
	{
		cout << "input again:";
		cin >> ch;
		if (ch == 'a')
		{
			cout << "6" << endl;
		}
		else if (ch == 'u')
		{
			cout << "7" << endl;
		}
	}
	else
		cout << "ERROR!" << endl;
}

int main()
{
	cout << "100-2-031" << endl;
	cout << "input a char:";
	char ch;
	cin >> ch;
	fun(ch);
	cin.get();
	cin.get();
	return 0;
}
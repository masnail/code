#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#define NLEAP 365//������

/*
*
*������ݺ��·�   ��ӡ���µ�����
*
*/
int CountDay(int year, int month, int day)
{//from 1.1->now 
	int sum = 0;
	int today[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	for (int i = 0; i < month - 1; i++)
	{
		sum += today[i];
	}

	if ((year % 4 == 0 && year % 100 != 0 || year % 400 == 0) && (month>2))
	{//ע����ŵ����ȼ�
		sum += 1;
	}
	sum += day;
	//printf("today is %d day\n", sum);
	return sum;
}
int ISLeapYear(int year)
{//is leap?
	if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int TheDay(int fyear, int fmonth, int fday, int syear, int smonth, int sday)
{//���ڵĲ�ֵ
	int count = 0;//the day
	if (fyear == syear)
	{
		count = CountDay(syear, smonth, sday) - CountDay(fyear, fmonth, fday);
	}
	else{
		count = NLEAP + ISLeapYear(fyear) - CountDay(fyear, fmonth, fday) + CountDay(syear, smonth, sday);
	}

	//printf("****** %d%d%d---%d%d%d day is %d\n", fyear, fmonth, fday, syear, smonth, sday, count);
	for (int i = fyear + 1; i < syear; i++)
	{
		count += NLEAP + ISLeapYear(i);
	}


	//printf("%d%d%d---%d%d%d day is %d", fyear, fmonth, fday, syear, smonth, sday, count);
	return count;
}
int TheWeek(int fyear, int fmonth, int fday, int syear, int smonth, int sday)
{
	int days;//between syear and syear
	if (fyear > syear || fyear == syear&&fmonth < smonth || fyear == syear&&fmonth == smonth&&fday < sday)
	{
		//before
		days = TheDay(syear, smonth, sday, fyear, fmonth, fday);
		days = (7 - days % 7) % 7;
	}
	else{
		//behind
		days = TheDay(fyear, fmonth, fday, syear, smonth, sday);
		days %= 7;
	}

	//printf("%d\n", days);
	return days;
}
int main()
{
	//2000-1-2 ����

	int fyear = 2000, fmonth = 1, fday = 2, syear, smonth, sday=1;

	printf("input second:");
	scanf("%d%d", &syear, &smonth);

	int wday=TheWeek(fyear, fmonth, fday, syear, smonth, sday);
	int today[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	int mday = 1;


	printf("%d\tSUN\tMON\tTUE\tWED\tTHU\tFRI\tSAT\n", smonth);
	for (int i = 0; i <= ceil(today[smonth-1] / 7); i++)
	{
		for (int j = 0; j <=wday; j++)
		{
			printf("\t");
		}
		for (int j = wday; j <= 6; j++)
		{
			if (mday <= today[smonth - 1])
			{
				printf("%d", mday++);
			}
				printf("\t");
		}
		printf("\n");
		
		wday = 0;
	}
	getchar();
	getchar();
	return 0;
}
#include <iostream>

using namespace std;

void fun(int tt[3][2], int pp[2])
{
	int min = 0;

	for (int i = 0; i < 2;i++)
	{
		min = tt[0][i];
		for (int j = 1; j < 3; j++)
		{
			if (tt[j][i]<min)
			{
				min = tt[j][i];
			}
		}
		pp[i] = min;
	}
}

int main()
{
	int tt[3][2] = {
		{ 2, 3},
		{ 848, 2},
		{ 15, 454}
	};
	int p[2] = {0};
	fun(tt,p);
	for (int i = 0; i < 2; i++)
	{
		cout <<p[i]<< endl;
	}
	getchar();
	return 0;
}
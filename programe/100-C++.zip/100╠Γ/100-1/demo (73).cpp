#include <iostream>
#include <string>

using namespace std;

int GetStringLen(string s)
{
	int index = 0;
	while (s[index])
	{
		index++;
	}
	return index;
}

void fun(string s,char *h,char *p)
{
	int length = GetStringLen(s);
	string stemp = "";
	for (int i = 0; i != length;i++)
	{
		if (s[i]!='*')
		{
			stemp += s[i];
		}
	}
	length = GetStringLen(stemp);
	*h = stemp[0];
	*p = stemp[length - 1];
}

int main()
{
	cout << "100-1-073" << endl;
	string str;
	cout << "input a string:";
	cin >> str;
	char *h = new char, *p = new char;
	fun(str,h,p);
	cout << *h << ":" << *p;
	cin.get();
	cin.get();
	return 0;
}
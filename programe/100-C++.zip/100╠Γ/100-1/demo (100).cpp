#include <iostream>
#include <string>

using namespace std;

void fun(int n)
{
	double index = 1,s=0,ss = 0;
	while (index!=n+1)
	{
		s += sqrt(index);
		ss += s;
		index += 1;
	}
	cout << ss << endl;
}

int main()
{
	cout << "100-1-100" << endl;
	cout << "input a count(1-100):";
	int n;
	cin >> n;
	fun(n);
	cin.get();
	cin.get();
	return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct nd{
	int num;
	struct nd *next;
}node, *nodelist;

void list_delete_same_count(nodelist *head,int cnt)
{
	nodelist p = (*head)->next, ppre = *head;
	while (p)
	{
		if (p->num == cnt)
		{
			ppre->next = p->next;
			free(p);
		}else{
			ppre = p;
		}
		p = ppre->next;
	}
}

void list_insert_tail(nodelist *head, nodelist *tail, int i)
{
	//for (int i = 0; i < 10; i++)
	{
		nodelist q = (node*)malloc(sizeof(node));
		memset(q, 0, sizeof(node));
		q->num = i + 1;
		q->next = (*tail)->next;
		(*tail)->next = q;
		(*tail) = q;
		(*head)->num += 1;
	}
}

void list_show(nodelist head)
{
	nodelist p = head->next;
	while (p)
	{
		printf("%d\t", p->num);
		p = p->next;
	}
	printf("\n");
}

int main()
{
	srand((unsigned)(time(NULL)));

	nodelist phead = (nodelist)malloc(sizeof(node)), ptail = phead;
	memset(phead, 0, sizeof(node));
	for (int i = 0; i < 11; i++)
	{
		list_insert_tail(&phead, &ptail, rand() % 10);
	}
	list_show(phead);

	int cnt;
	printf("input a count of you will delete:");
	scanf("%d", &cnt);
	list_delete_same_count(&phead,cnt);
	list_show(phead);

	getchar();
	getchar();
	return 0;
}
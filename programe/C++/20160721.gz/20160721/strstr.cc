/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月21日 星期四 17时06分02秒
* File Name: strstr.cc
* Description: C++ file
************************************************************************/

#include <stdio.h>

#include <iostream>
#include <string>

using std::cout;
using std::cin;
using std::endl;
using std::string;

int main(int argc,char *argv[])
{
    string name="i love china,are you from";
    string des="you";
    cout<<"substr="<<name.substr(2,4)<<endl;
    cout<<"find string of des"<<name.find(des)<<endl;
    cout<<"the name length="<<name.length()<<endl;
    const char *p=name.c_str();
    puts(p);
    return 0;
}


#include <iostream>
#include <string>

using namespace std;

void fun(int h[],int m)
{
	for (int i = 0; i != m; i++)
	{
		int temp = h[9];
		for (int j = 9; j != -1;j--)
		{
			h[j] = h[j - 1];
		}
		h[0] = temp;
	}

	for (int j = 0; j != 10; j++)
	{
		cout<<h[j] <<"\t";
	}
}

int main()
{
	cout << "100-2-068" << endl;
	int ch[10] = { 4556, 55, 66, 5, 1112, 555, 55, 66, 4, 52 };
	cout << "input a count(0-10):";
	int n;
	cin >> n;
	fun(ch,n);
	cin.get();
	cin.get();
	return 0;
}

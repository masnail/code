#include <stdio.h>

int main(int argc,char *argv[])
{
	int *a[4]={NULL};

	for(int i=3;i>=-1;i--)
	{
		printf("a[%d]= %d\n",i,*a[i]);
	}

	return 0;
}

#include <iostream>
#include <string>

using namespace std;

typedef struct student
{
	int num;
	int age;
}student,*stud;

void fun()
{
	student *stu = (stud)malloc(sizeof(student));
	stu->num = 2011;
	stu->age = 25;
}

int main()
{
	cout << "100-2-087" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

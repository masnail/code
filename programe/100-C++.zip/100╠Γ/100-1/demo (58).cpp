#include <iostream>
#include <string>
#include <cmath>

using namespace std;

double fun(int  n)
{
	double sum = 0;
	for (int i = 0; i != n;i++)
	{
		if (i%3==0||i%7==0)
		{
			sum += i;
		}
	}
	cout << sum << endl;
	sum = sqrt(sum);
	return sum;
}

int main()
{
	cout << "100-1-058" << endl;
	cout << "input a count:";
	int n;
	cin >> n;
	cout<<fun(n);
	cin.get();
	cin.get();
	return 0;
}

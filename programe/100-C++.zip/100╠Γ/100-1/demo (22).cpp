#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

typedef struct node
{
	struct node *next;
	double score;
}node,*linknode;

double random(double start, double end)
{
	return start + (end - start)*rand() / (RAND_MAX + 1.0);
}

int fun(linknode p)
{
	int max = 0;
	p = p->next;
	//cout <<":"<< p->score<<endl;
	while (p)
	{
	//cout << p->score << endl;
	if (max<p->score)
	{
	max = p->score;
	}
	p = p->next;
	}
	return max;
}

int main()
{
	cout << "100-1-022" << endl;

	srand(unsigned(time(0)));
	linknode stu = (linknode)malloc(sizeof(node));
	stu->next = NULL;
	for (int i = 0; i < 10;i++)
	{
		linknode p = (linknode)malloc(sizeof(node));
		int temp = random(0, 100);
		p->score = temp;
		cout << temp << endl;
		p->next = stu->next;
		stu->next = p;
	}
	cout<<"MAX:"<<fun(stu);
	getchar();
	return 0;
}
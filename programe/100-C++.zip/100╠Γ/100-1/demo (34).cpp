#include <iostream>
#include <string>

using namespace std;

typedef struct  
{
	int num;
	int score;
	
}student;

 int fun(student *s,student *h)
{
	 int count = 0,max=0;
	 for (int i = 0; i < 5;i++)
	 {
		 if (s[i].score>max)
		 {
			 max = s[i].score;
		 }
	 }

	 for (int i = 0; i < 5; i++)
	 {
		 if (s[i].score==max)
		 {
			 h[count].num = s[i].num;
			 h[count].score = s[i].score;
			 count++;
		 }
	 }

	 return count;
}

int main()
{
	cout << "100-1-034" << endl;
	student *h=new student,s[5] = { 
		{ 101, 52 }, 
		{102,89}, 
		{103,89}, 
		{110,85}, 
		{111,36} 
	};
	cout << fun(s, h) << endl;
	for (int i = 0; i < fun(s, h);i++)
	{
		cout << h[i].num << ":" << h[i].score << endl;
	}
	cin.get();
	cin.get();
	return 0;
}

#include "Search_User.h"

/*
*
*
* �û�����
*
*
*/

/*
*
*
* �û�����
*
*
*/

void Search_User_Name()//���û�����������
{
	char name[20];
	printf("\tInput name: ");
	scanf("%s", name);

	userlist head = Get_user_Head();
	userlist p = head->next;
	int index = 0;
	printf(USER_HEAD);
	while (p)
	{
		if (0 == strcmp(name, p->name))
		{
			index = 1;
			printf(USR_FORMAT_IN, USR_FORMAT_OUT);
			return;
		}
		p = p->next;
	}
	if (0 == index)
	{
		printf("\tsorry,I have not this information!\n");
	}
}
int  Search_UserName(char* name)
{
	userlist head = Get_user_Head();
	userlist p = head->next;
	while (p)
	{
		if (0==strcmp(name, p->name))
		{
			printf(USER_HEAD);
			printf(USR_FORMAT_IN, USR_FORMAT_OUT);
			return 1;
		}
		p = p->next;
	}
	return 0;
}
void Search_User_Power()//���û���Ȩ�޲���
{
	char power;
	fflush(stdin);
	printf("\tInput power(4/7): ");
	scanf("%c", &power);

	userlist head = Get_user_Head();
	userlist p = head->next;
	int index = 0;
	printf(USER_HEAD);
	while (p)
	{
		if (power == p->power)
		{
			index = 1;
			printf(USR_FORMAT_IN, USR_FORMAT_OUT);
		}
		p = p->next;
	}
	if (0 == index)
	{
		printf("\tsorry,I have not this information!\n");
	}
}


void Search_User_All()//�������û�
{
	userlist head = Get_user_Head();
	userlist p = head->next;
	int index = 0;
	printf(USER_HEAD);
	while (p)
	{
		index = 1;
		printf(USR_FORMAT_IN, USR_FORMAT_OUT);
		p = p->next;
	}
	if (0 == index)
	{
		printf("\tsorry,I have not this information!\n");
	}
}
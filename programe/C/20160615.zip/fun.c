#include "head.h"

//��������
void swap(int *a, int *b)
{
	*a = *a^*b;
	*b = *a^*b;
	*a = *a^*b;
}

void sort_show(int *arr,int num)
{
	int cnt= 0;
	for (int j = 0; j < num; j++)
	{
		cnt++;
		printf("%d ", *(arr+j));
		if (cnt%10==0)
		{
			cnt = 0;
			printf("\n");
		}
	}
	printf("\n");
}

//ð�ݽ���
void sort_bubble_desc(int *arr,int num)
{
	for (int i = 0; i < num;i++)
	{
		for (int j = i; j < num;j++)
		{
			if (*(arr + j)<*(arr + i))
			{
				swap((arr + j), (arr + i));
			}
		}
	}
}

//ð������
void sort_bubble_esc(int *arr, int num)
{
	for (int i = 0; i < num; i++)
	{
		for (int j = i; j < num; j++)
		{
			if (*(arr + j) > *(arr + i))
			{
				swap((arr + j), (arr + i));
			}
		}
	}
}

//��������--C���Դ�
int compare_esc(const void *a, const void *b)
{
	int *x = (int)a;
	int *y = (int)b;
	return *y - *x;
}

//���Ž���--C���Դ�
int compare_desc(const void *a, const void *b)
{
	int *x = (int)a;
	int *y = (int)b;
	return *x- *y;
}

//��������
int sort_quick_partition_esc(int *a, int begin, int end)
{
	int i = begin, j = end, key = a[begin];

	while (i != j)
	{
		while (*(a + j) >= key&&i<j){
			j--;
		}
		swap((a + j), (a + i));

		while (*(a + i) <= key&&i<j){
			i++;
		}
		swap((a + j), (a + i));
	}
	return i;
}

void sort_quick_esc(int *a, int begin, int end)
{
	if (begin >= end)
	{
		return;
	}
	else if (begin == end - 1)
	{
		if (*(a + begin) > *(a + end))
		{
			swap((a + begin), (a + end));
		}
		return;
	}
	int i = sort_quick_partition_esc(a, begin, end);
	sort_quick_esc(a, begin, i - 1);
	sort_quick_esc(a, i + 1, end);
}

//���Ž���
int sort_quick_partition_desc(int *a, int begin, int end)
{
	int i = begin, j = end, key = a[begin];

	while (i != j)
	{
		while (*(a + j) <= key && i<j){
			j--;
		}
		swap((a + j), (a + i));

		while (*(a + i) >= key && i<j){
			i++;
		}
		swap((a + j), (a + i));
	}
	return i;
}

void sort_quick_desc(int *a, int begin, int end)
{
	if (begin >= end)
	{
		return;
	}
	else if (begin == end - 1)
	{
		if (*(a + begin) < *(a + end))
		{
			swap((a + begin), (a + end));
		}
		return;
	}
	int i = sort_quick_partition_desc(a, begin, end);
	sort_quick_desc(a, begin, i - 1);
	sort_quick_desc(a, i + 1, end);
}

//��������
void sort_insert_esc(int *arr, int num)
{
	int inser_num;
	for (int i = 1; i < num;i++)
	{
		for (int j = 0; j < i;j++)//order
		{
			if (*(arr+i) < *(arr+j))
			{
				inser_num = *(arr + i);
				while (j<i)
				{
					*(arr + i) = *(arr + i-1);
					i--;
				}
				*(arr + j) = inser_num;
			}
		}
	}
}

//���뽵��
void sort_insert_desc(int *arr, int num)
{
	int inser_num;
	for (int i = 1; i < num; i++)
	{
		for (int j = 0; j < i; j++)//order
		{
			if (*(arr + i) > *(arr + j))
			{
				inser_num = *(arr + i);
				while (j < i)
				{
					*(arr + i) = *(arr + i - 1);
					i--;
				}
				*(arr + j) = inser_num;
			}
		}
	}
}

//ѡ������
void sort_select_esc(int *arr, int num)
{
	int select_pos;
	for (int i = 0; i < num;i++)
	{
		select_pos = i;
		for (int j = i; j < num;j++)
		{
			if (*(arr+select_pos) > *(arr+j))
			{
				select_pos = j;
			}
		}
		swap((arr+ select_pos), (arr + i));
	}
}

//ѡ����
void sort_select_desc(int *arr, int num)
{
	int select_pos;
	for (int i = 0; i < num; i++)
	{
		select_pos = i;
		for (int j = i; j < num; j++)
		{
			if (*(arr + select_pos) < *(arr + j))
			{
				select_pos = j;
			}
		}
		swap((arr + select_pos), (arr + i));
	}
}

//�鲢����
void sort_merge_part_esc(int *arr, int begin,int mid,int end)
{
	int left[MAX] = { 0 }, right[MAX] = { 0 };

	for (int i = begin; i < mid+1;i++)
	{
		left[i - begin] = arr[i];
	}
	for (int i = mid; i < end; i++)
	{
		right[i - mid] = arr[i+1];
	}

	int p = 0, q = 0, left1 = mid-begin+1,right1=end-mid;

	while (p<left1&&q<right1)
	{
		if (left[p]>right[q])
		{
			arr[begin++] = right[q++];
		}else{
			arr[begin++] = left[p++];
		}
	}

	while (p < left1)
	{
		arr[begin++] = left[p++];
	}
	while (q < right1)
	{
		arr[begin++] = right[q++];
	}
}

void sort_merge_esc(int *arr, int begin,int end)
{
	if (begin < end)
	{
		sort_merge_esc(arr, begin, (begin + end) / 2);
		sort_merge_esc(arr, (begin + end) / 2+1, end);
		sort_merge_part_esc(arr, begin, (begin + end) / 2, end);
	}
}

//�鲢����
void sort_merge_part_desc(int *arr, int begin, int mid, int end)
{
	int left[MAX] = { 0 }, right[MAX] = { 0 };

	for (int i = begin; i < mid + 1; i++)
	{
		left[i - begin] = arr[i];
	}
	for (int i = mid; i < end; i++)
	{
		right[i - mid] = arr[i + 1];
	}

	int p = 0, q = 0, left1 = mid - begin + 1, right1 = end - mid;

	while (p < left1&&q<right1)
	{
		if (left[p]>right[q])
		{
			arr[begin++] = right[q++];
		}
		else{
			arr[begin++] = left[p++];
		}
	}

	while (p < left1)
	{
		arr[begin++] = left[p++];
	}
	while (q < right1)
	{
		arr[begin++] = right[q++];
	}
}

void sort_merge_desc(int *arr, int begin, int end)
{
	if (begin < end)
	{
		sort_merge_desc(arr, begin, (begin + end) / 2);
		sort_merge_desc(arr, (begin + end) / 2 + 1, end);
		sort_merge_part_desc(arr, begin, (begin + end) / 2, end);
	}
}

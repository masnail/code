/*************************************************************************
 Author:MASnail
 Created Time: 2016年07月04日 星期一 19时27分24秒
 File Name: func_shm.h
 Description: 
 ************************************************************************/
#include "head.h"

void create_shma(int*,char**);

void delete_shma(int);

void create_shmb(int*,char**);

void delete_shmb(int);

#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>

int main(int argc,char* argv[])
{
	if(2!=argc)
	{
		printf("error,the argc\n");
		return -1;
	}

	DIR *dir=opendir(argv[1]);

	if(NULL==dir)
	{
		printf("get dir is error\n");
		return -1;
	}
	
	struct dirent *dirname;

	while(NULL!=(dirname=readdir(dir)))
	{
		if(0 != strcmp(dirname->d_name,".") && 0 != strcmp(dirname->d_name,".."))
		{ 
			printf("%s\n",dirname->d_name);
		}
	}


	closedir(dir);

	return 0;
}





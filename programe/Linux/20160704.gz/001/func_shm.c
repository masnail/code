/*************************************************************************
 Author:MASnail
 Created Time: 2016年07月04日 星期一 18时55分54秒
 File Name: func_shm.c
 Description: 
 ************************************************************************/
#ifndef FUNC_SHM_H
#define FUNC_SHM_H

#include "func_shm.h"

void create_shma(int *shmida,char **p)
{
	*shmida = shmget(123,4096,IPC_CREAT|0666);
	if(-1 == *shmida)
	{
		perror("shmget_a");
		exit(0);
	}
	 *p=(char*)shmat(*shmida,NULL,0);
	/* printf("sdfasd%p\n",p);
	 int q=shmdt(*p);
	 if(q == -1)
	 {
		 perror("shmat_a");
		 exit(0);
	 }*/
}

void create_shmb(int *shmidb,char **p)
{
	*shmidb = shmget(456,4096,IPC_CREAT|0666);
	if(-1 == *shmidb)
	{
		perror("shmget_b");
		exit(0);
	}
	*p=(char*)shmat(*shmidb,NULL,0);
   /* int q=shmdt(*p);
	if(q == -1)
	 {
		 perror("shmat_b");
		 exit(0);
	 }*/
}

void delete_shma(int shmida)
{
	int ret = shmctl(shmida,IPC_RMID,NULL);
	if(-1 == ret)
	{
		perror("delete_shma");
		exit(0);
	}
}

void delete_shmb(int shmidb)
{
	int ret = shmctl(shmidb,IPC_RMID,NULL);
	if(-1 == ret)
	{
		perror("delete_shma");
		exit(0);
	}
}

#endif

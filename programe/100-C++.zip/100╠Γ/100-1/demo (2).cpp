#include <iostream>

using namespace std;

void fun()
{
	cout << "��̻���100-002" << endl;
	int n = 0, a[100];

	for (int i = 1; i < 100; i++)
	{
		if (i % 7 == 0 && i % 11 != 0)
		{
			a[n++] = i;
		}
		else if (i % 7 != 0 && i % 11 == 0)
		{
			a[n++] = i;
		}
	}

	for (int i = 0; i < n;i++)
	{
		cout << a[i] << " ";
	}
}

int main()
{
	fun();
	system("pause");
	return 0;
}
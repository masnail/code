#include <iostream>
#include <string>
#include <cmath>
#include <iomanip>

using namespace std;

void fun(double n,double x)
{
	double s = 1.0,index=1.0,low=index,up=pow(x,index);
	while (index!=n+1)
	{
		s += (up / low);
		index += 1;
		low *= index;
		up = pow(x, index);
		//cout << up<<":"<<low << endl;
	}
	cout <<setprecision(6)<<fixed<< s << endl;
}

int main()
{
	cout << "100-1-093" << endl;
	cout << "input a count-n:";
	double n;
	cin >> n;
	cout << "input a count-x:";
	double x;
	cin >> x;
	fun(n,x);
	cin.get();
	cin.get();
	cin.get();
	cin.get();
	return 0;
}

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#define NLEAP 365

/*
*
*��������  ��һ������n   
*����n��������
**
*/
int CountDay(int year, int month, int day)
{//from 1.1->now 
	int sum = 0;
	int today[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	for (int i = 0; i < month - 1; i++)
	{
		sum += today[i];
	}

	if ((year % 4 == 0 && year % 100 != 0 || year % 400 == 0) && (month>2))
	{//ע����ŵ����ȼ�
		sum += 1;
	}
	sum += day;
	//printf("today is %d day\n", sum);
	return sum;
}

int ISLeapYear(int year)
{//is leap?
	if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int TheDay(int fyear, int fmonth, int fday, int syear, int smonth, int sday,int n)
{
	int count = 0;//the day
	if (fyear == syear)
	{
		count = CountDay(syear, smonth, sday) - CountDay(fyear, fmonth, fday);
	}
	else{
		count = NLEAP + ISLeapYear(fyear) - CountDay(fyear, fmonth, fday) + CountDay(syear, smonth, sday);
	}

	//printf("****** %d%d%d---%d%d%d day is %d\n", fyear, fmonth, fday, syear, smonth, sday, count);
	for (int i = fyear + 1; i < syear; i++)
	{
		count += NLEAP + ISLeapYear(i);
	}

	/*if (n == count)
	{
		printf("%d%d%d---%d%d%d day is %d", fyear, fmonth, fday, syear, smonth, sday, count);
		return;
	}*/
	return count;
}

int main()
{
	int  syear, smonth, sday,n; 
	int today[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

	printf("input data:");
	while (scanf("%d%d%d%d", &syear, &smonth, &sday, &n) != EOF)
	{
		int index = 0, year = syear, month = smonth, day = sday;//day��¼ÿ���µ�����

		//������
		if (ISLeapYear(year))
		{
			today[1] = 29;
		}
		else{
			today[1] = 28;
		}

		while (index <n)
		{
			day++;
			if (day>today[month - 1])
			{
				month++;
				if (month>12)
				{
					year += 1;
					month = 1;
					
					//��ݱ仯  ������
					if (ISLeapYear(year))
					{
						today[1] = 29;
					}
					else{
						today[1] = 28;
					}
				}
				day = 1;
			}
			index++;
		}
		printf("%d %d %d\n",year, month,day);
	}
	getchar();
	getchar();
	return 0;
}
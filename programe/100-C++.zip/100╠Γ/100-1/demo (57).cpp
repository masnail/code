#include <iostream>
#include <string>

using namespace std;

typedef struct
{
	string num;
	double score;
}student;

double fun(student s[], student b[], int start,int end)
{
	int index = 0, c = 0;
	while (index != 3)
	{
		if (s[index].score < end || s[index].score>start)
		{
			b[c] = s[index];
			c++;
		}
		index++;
	}
	//cout << c <<endl;
	return c;
}

int main()
{
	cout << "100-1-054" << endl;
	student stu[] = {
		{ "2011", 89 },
		{ "2012", 69 },
		{ "2013", 8 },
		{ "2014", 78 }
	};
	student b[5] ;
	int start, end;
	cout << "input a start:";
	cin >> start;
	cout << "input a end:";
	cin >> end;
	cout << fun(stu, b,start,end) << endl;
	
	cin.get();
	cin.get();
	return 0;
}
/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月21日 星期四 15时33分57秒
* File Name: class.cc
* Description: C++ File
************************************************************************/

#include <iostream>
using namespace std;

class computer
{   
public:
    void print()
    {
	cout<<"Brand:"<<_brand<<endl;
	cout<<"price:"<<_price<<endl;
    }
    void setPrice(float price)
    {	
	_price=price;
    }
    void setBrand(string brand)
    {	
	_brand=brand;
    }
private:
    string _brand;
    float  _price;

};
int main(int argc,char *argv[])
{
    computer len;
    len.setPrice(32323);
    len.setBrand("LENOVO");
    len.print();

    return 0;
}


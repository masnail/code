#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node
{
	int data;
	struct node *next;
}node,*nodelist;

void list_show(nodelist head)
{
	nodelist p = head->next;
	while (p)
	{
		printf("%d ", p->data);
		p = p->next;
	}
}

void list_insert_tail(nodelist *head,nodelist *tail,int i)
{
	//for (int i = 0; i < 10; i++)
	{
		nodelist q = (node*)malloc(sizeof(node));
		memset(q, 0, sizeof(node));
		q->data = i + 1;
		q->next = (*tail)->next;
		(*tail)->next = q;
		(*tail) = q;
		(*head)->data += 1;
	}
}

int main()
{
	nodelist head = (node*)malloc(sizeof(node)),tail=head;//ͷ���
	head->data = 0; 
	head->next = NULL;

	for (int i = 0; i < 10; i++)
	{
		list_insert_tail(&head,&tail,i);
		
	}

	list_show(head);

	getchar();
	getchar();
	return 0;
}
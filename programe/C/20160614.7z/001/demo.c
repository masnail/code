//#include <stdio.h>
//#include <stdlib.h>
//
//int main()
//{
//
//}

#include <stdio.h>
#include <stdlib.h>


int cnt[512] = { 0 };//�洢·��
static int count = 0;

void Show(int cnt[],int n,int m,int x,int y)
{
	count++;
	int index = (x + y) * 2 + 2-(n + m) * 2;
	//int index = x*y * 2+2;
	for (int i = 0; i < index;i+=2)
	{
		printf("%d,%d", cnt[i], cnt[i + 1]);
		if (i<index-2)
		{
			printf("->");
		}
	}
	printf("  --->%d\n\n",count);
}

void fun(int startx,int starty,int n,int m,int x, int y)
{

	//printf("(%d,%d) ", n, m);
	int index = (n + m) * 2 - (startx + starty) * 2;
	cnt[index] = n;
	cnt[index + 1] = m;
	
	/*printf("index:%d\n",index);*/
	if (n==x&&m<y)
	{
		fun(startx,starty,n, m + 1, x, y);
	}
	else if (n < x&&m == y)
	{
		fun(startx,starty,n + 1, m, x, y);
	}
	else if (n == x&&m == y)
	{
		Show(cnt,startx,starty,x,y);
		//index -= 2;
		//fun(n-1, m , x, y);
		printf("\n");
	}
	else{
		//index = (x - n)*(y - m) + 1;
		//printf("%d,%d,%d,%d:%d\n", n, m, x, y, (x - n)*(y - m) + 1);
		fun(startx,starty,n + 1, m, x, y);
		//index -= (x - n)*(y - m) + 1;
		fun(startx,starty,n, m + 1, x, y);
		//index -= 2;
	}
	

}

int main()
{
	int statx,starty,n, m;
	printf("the start point:\n");
	while (scanf("%d%d",&statx,&starty)!=EOF)
	{
		printf("the end point:\n");
		if (scanf("%d%d%d%d", &n, &m) != EOF)
		{
			count = 0;
			fun(statx,starty,statx,starty,n,m);

			printf("all the road is : %d\n\n", count);
		}
		printf("the start point:\n");
	}
	
	getchar();
	getchar();
	return 0;

}
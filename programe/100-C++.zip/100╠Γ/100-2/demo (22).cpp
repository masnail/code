#include <iostream>
#include <string>

using namespace std;

void VScore(int A[],int B[])
{
	bool ch = false;
	for (int x = 0; x != 3; x++)
	{
		for (int a = 0; a != 3; a++)
		{
			for (int c = 0; c != 3; c++)
			{
				for (int z = 0; z != 3; z++)
				{
						if (c != x&&c != z&&x != z&&a != x&&a!=c)
						{
							//a c  x
							A[0] = a;
							A[1] = 3 - a - c;
							A[2] = c;
							B[0] = x;
							B[1] = 3 - x - z;
							B[2] = z;
							//cout << a << 3-a-c << c << x << 3-x-z << z << endl;
							ch = true;
							//continue;
						}
				}
				if (ch)
				{
					break;
				}
			}
			if (ch)
			{
				break;
			}
		}
		if (ch)
		{
			break;
		}
	}

	
}

void VSindex()
{
	int A[3] = { 0, 0, 0 };
	char chA[3] = { 'a', 'b', 'c' };
	int B[3] = { 0, 0, 0 };
	char chB[3] = { 'x', 'y', 'z' };

	VScore(A, B);

	for (int i = 0; i != 3; i++)
	{
		for (int j = 0; j != 3; j++)
		{
			if (A[i] == B[j])
			{
				cout << chA[i] << " VS " << chB[j] << endl;
			}
		}
	}
}

int main()
{
	cout << "100-2-022" << endl;
	VSindex();
	cin.get();
	cin.get();
	return 0;
}

#include <pthread.h>
#include <stdio.h>
#include <string.h>

#define NUM 200000000000

long long  sum = 0;

pthread_mutex_t mutex;

void *func_pth(void *p)
{
	for(int i=0;i<NUM;i++)
	{
		pthread_mutex_lock(&mutex);
		sum+=1;
		pthread_mutex_unlock(&mutex);
	}
	pthread_exit(NULL);
}

int main()
{
	pthread_t pth;
	pthread_mutex_init(&mutex,NULL);
	pthread_create(&pth,NULL,func_pth,NULL);
	for(int i=0;i<NUM;i++)
	{
		pthread_mutex_lock(&mutex);
		sum+=1;
		pthread_mutex_unlock(&mutex);
	}
	pthread_join(pth,NULL);
	printf("the sum = %lld\n",sum);
	return 0;
}


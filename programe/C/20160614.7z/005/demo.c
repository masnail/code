#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct nod
{
	int data;
	struct nod *next;
}node, *nodelist;

void list_show(nodelist head)
{
	nodelist p = head->next;
	while (p)
	{
		printf("%d\t", p->data);
		p = p->next;
	}
	printf("\n");
}

void list_sort_insert(nodelist *head, nodelist *tail, int data)
{
	nodelist p = (*head)->next, pre = *head;

	while (p != NULL)
	{
		if (p->data < data)
		{
			pre = p;
			p = p->next;
		}
		else{
			break;
		}
	}
	nodelist pnow = (nodelist)malloc(sizeof(node));
	memset(pnow, 0, sizeof(node));
	pnow->data = data;
	(*head)->data += 1;
	pnow->next = pre->next;
	pre->next = pnow;

	if (p == NULL)
	{
		*tail = pnow;
	}
}

int main()
{
	int num;
	nodelist head = (nodelist)malloc(sizeof(node)), tail = head;
	memset(head, 0, sizeof(node));
	head->data = 0;
	while (scanf("%d", &num) != EOF)
	{

		list_sort_insert(&head, &tail, num);
	}
	list_show(head);

	getchar();
	return 0;
}
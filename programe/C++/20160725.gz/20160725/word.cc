/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月25日 星期一 21时41分48秒
* File Name: word.cc
* Description: C++ file
************************************************************************/
#include <iostream>
#include <string>
#include <fstream>

#include <string.h>
#include <stdlib.h>

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::ifstream;
using std::ofstream;

typedef struct wd
{
    char str[30];
    int cnt;
    struct wd *next;
}word,*wordlist;

class WordStatic 
{
    public:
	WordStatic();
    	void read_file(string filename);
	void write_file(string filename);
	~WordStatic();	

	void inserWord(string wordname);
	static int compare(const void *p,const void *q);
	void show();
    private:
	word *head;
};

void WordStatic::read_file(string filename)
{
    ifstream fsr(filename.c_str());
    if(!fsr.good())
    {
	cout<<"read file error"<<endl;
	return;
    }
    string str="";
    while(fsr>>str)
    {
//	cout<<str.c_str();
	inserWord(str);
    }
    fsr.close();
}

void WordStatic::write_file(string filename)
{
    ofstream fsw(filename.c_str());

    word *p=head->next;
    fsw<<"ALL THE WORD:"<<head->cnt<<endl;
    
    wordlist *wdarr=(wordlist*)calloc(head->cnt,sizeof(wordlist));
    for(int i=0;i<head->cnt;i++)
    {
	wdarr[i]=p;
	p=p->next;
    }

    qsort(wdarr,head->cnt,sizeof(wordlist),WordStatic::compare);

    for(int i=0;i<head->cnt;i++)
    {
	fsw<<wdarr[i]->str<< "  "<<wdarr[i]->cnt<<endl;
    
    }
    fsw.close();
#if 0
    while(p)
    {
	fsw<<p->str<<"  "<<p->cnt<<endl;
	p=p->next;
    }
#endif 

}

void WordStatic::inserWord(string wordname)
{
    word *p=head->next,*pre=head;
    while(p)
    {
	if(0 == strcmp(wordname.c_str(),p->str))
	{
	    p->cnt+=1;
	    break;
	}
	pre=p;
	p=p->next;
    }

    if(p==NULL)
    {
	word *q=(word*)calloc(1,sizeof(word));
	q->cnt=1;
	memcpy(q->str,wordname.c_str(),wordname.size());
	pre->next=q;
	head->cnt+=1;
    }
}

int WordStatic::compare(const void *p,const void *q)
{
    wordlist *pp=(wordlist*)p;
    wordlist *qq=(wordlist*)q;
  //  cout<<(*qq)->str<<":"<<(*pp)->str<<endl;
    return (*qq)->cnt-(*pp)->cnt;
}

void WordStatic::show()
{
    word *p=head->next;
    while(p)
    {
	cout<<p->str<<":"<<p->cnt<<endl;
	p=p->next;
    }
}

WordStatic::WordStatic()
{
     head=(word*)calloc(1,sizeof(word));
}

WordStatic::~WordStatic()
{
    word *p=head;
    while(p)
    {
	head=head->next;
	free(p);
	p=head;
    }
}

int main(int argc,char *argv[])
{

    WordStatic wds;
    wds.read_file("2");
 //   wds.show();
    wds.write_file("word");

    return 0;
}


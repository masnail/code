#include <iostream>
#include <string>

using namespace std;

int  fun(int c)
{
	int sum = 0;
	for (int i = 1; i <= c;i++)
	{
		if (c%i==0)
		{
			sum += i;
		}
	}
	return sum;
}

int main()
{
	cout << "100-1-063" << endl;
	cout << "input a count(max 1000):";
	int count;
	cin >> count;
	if (count>1000)
	{
		cout << "ERROR!" << endl;
		main();
	}
	cout << fun(count) << endl;;
	cin.get();
	cin.get();
	return 0;
}
/*************************************************************************
* Author: MASnail
* Created Time: 2016年08月01日 星期一 16时44分50秒
* File Name: test.cc
* Description: C++ file
************************************************************************/
#include <iostream>
#include <string.h>

using std::cout;
using std::cin;
using std::endl;
using std::string;

int main(int argc,char *argv[])
{
    string s("hello");
    string s1(s);
    string s2=s;
    string s3=s;
    s3[2]='w';
    string s4=s;
    s4[2]='l';

    const char *ps=s.c_str();
    const char *ps1=s.c_str();
    const char *ps2=s.c_str();
    const char *ps3=s.c_str();
    const char *ps4=s.c_str();
    cout<<&ps<<endl;
    cout<<&ps1<<endl;
    cout<<&ps2<<endl;
    cout<<&ps3<<endl;
    cout<<&ps4<<endl;
  //  cout<<s.c_str()<<endl;
    return 0;
}


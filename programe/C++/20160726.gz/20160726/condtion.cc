/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月27日 星期三 08时37分03秒
* File Name: condtion.cc
* Description: C++ file
************************************************************************/
#include <iostream>
#include <pthread.h>

using std::cout;
using std::cin;
using std::endl;

class MutexLock
{
    public:
	MutexLock()
	{
	    pthread_mutex_init(_mutex,NULL);
	}
	~MutexLock()
	{
	    pthread_mutex_destroy(_mutex);
	}
	void lock()
	{
	    pthread_mutex_lock(_mutex);
	}
	void unlock()
	{
	    pthread_mutex_unlock(_mutex);
	}
	pthread_mutex_t *getMutexptr()
	{
	    return _mutex;
	}
    private:
	pthread_mutex_t * _mutex;
};

class Condtion
{
    public:
	Condtion()
	{
	    pthread_cond_init(_cond,NULL);
	}
	~Condtion()
	{
	    pthread_cond_destroy(_cond);
	}
	void wait(MutexLock & mutex)
	{
	    pthread_cond_wait(_cond,mutex.getMutexptr());
	}
	void notify()
	{
	    pthread_cond_signal(_cond);
	}
	void notifyall()
	{
	    pthread_cond_broadcast(_cond);
	}
    private:
	pthread_cond_t * _cond;
};

int main(int argc,char *argv[])
{
//    Condtion cond;
    return 0;
}


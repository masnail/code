#include <iostream>
#include <string>

using namespace std;

typedef struct
{
	string num;
	int score;
}student;

double fun(student s[], int *num,student *b)
{
	int index = 0;
	double sum = 0,ave=0;
	while (s[index].num != "")
	{
		sum += s[index].score;
		index++;
	}
	ave= sum/(double)index;


	sum = 0;//������Ϊ������
	for (int i = 0; i < index; i++)
	{
		if (s[i].score >= ave)
		{
			*b = s[i];
			b++;
			sum++;
		}
	}
	*num = (int)sum;
	return ave;
}

int main()
{
	cout << "100-1-089" << endl;
	student s[] = {
		{ "2011", 98 },
		{ "2012", 89 },
		{ "2013", 90 },
		{ "2014", 91 },
		{ "", -1 } 
	};
	int *num=new int;
	student *b = new student;
	cout<<fun(s, num,b)<<endl;
	cout << *num << endl;
	cin.get();
	cin.get();
	delete num;
	return 0;
}
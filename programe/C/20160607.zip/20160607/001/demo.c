#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main()
{
	char ch;

	while (/*fflush(stdin)*/scanf("%c", &ch) != EOF)
	{
		if (ch<='z'&&ch>='a')
		{
			printf("%c", ch - 32);
		}else{
			printf("%c", ch);
		}
		
	}
	getchar();
	getchar();
	return 0;
}
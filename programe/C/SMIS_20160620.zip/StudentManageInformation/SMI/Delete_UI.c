#include "Delete_UI.h"


//ѧ��
void Delete_Student()
{
	
	Print_Welcome();
	Search_Student_All();

	int num;
	printf("\tinput a student num:");
	scanf("%d", &num);

	Print_Welcome();

	if (Search_StudentNum(num) == 1)
	{
		Delete_Student_Info(num);
	}else{
		printf("\tthe student is not exist!\n");
	}

	
	Search_Student_All();
}

//�û�
void Delete_USer()
{
	Print_Welcome();
	Search_User_All();

	char name[20];
	fflush(stdin);
	printf("\tinput a user name:");
	scanf("%s", name);

	Print_Welcome();

	if (Search_UserName(name) == 1)
	{
		Delete_User_Info(name);
	}
	else{
		printf("\tthe user is not exist!\n");
	}

	Search_User_All();
}
/*************************************************************************
 Author:MASnail
 Created Time: 2016年07月05日 星期二 00时02分57秒
 File Name: func_sem.h
 Description: 
 ************************************************************************/
#include "head.h"

int create_sema();

int create_sema_mutex();

int create_semb();

int create_semb_mutex();

void create_sembufp(struct sembuf*,struct sembuf*);

void create_sembufv(struct sembuf*,struct sembuf*);

void create_sembufpv(struct sembuf*,struct sembuf*);

void delete_sem(int);


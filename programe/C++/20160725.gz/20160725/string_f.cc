/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月25日 星期一 11时24分01秒
* File Name: string_f.cc
* Description: C++ file
************************************************************************/
#include <iostream>
#include <string>

using std::cout;
using std::cin;
using std::endl;
using std::string;

int main(int argc,char *argv[])
{
    const char *pch;
    string str="this is a test";
   pch= str.c_str();
   cout<<pch<<endl;
   cout<<str.find('i')<<endl;

}


/*************************************************************************
* Author: MASnail
* Created Time: 2016年07月26日 星期二 19时55分06秒
* File Name: classlog4cpp.cc
* Description: C++ file
************************************************************************/
#include "classlog4cpp.h"

myLog * myLog::_mylog=NULL;

myLog * myLog::getInstance()
{
    if(!_mylog)
	_mylog=new myLog;
    return _mylog;
}

myLog::myLog()
    :_root(Category::getRoot())
{
    OstreamAppender *osApender=new OstreamAppender("osApender",&cout);
    PatternLayout *pLayout=new PatternLayout();
    pLayout->setConversionPattern("%d:%p %c %x:%m%n");
    PatternLayout *pLayoutf=new PatternLayout();
    pLayoutf->setConversionPattern("%d:%p %c %x:%m%n");

    RollingFileAppender *rfAppender=new RollingFileAppender("rfAppender","rflog-1",5*1024,1);
    osApender->setLayout(pLayout);
    rfAppender->setLayout(pLayoutf);
    _root.addAppender(osApender);  
    _root.addAppender(rfAppender);
    _root.setPriority(Priority::DEBUG);
}

void myLog::close()
{
    delete _mylog;
    Category::shutdown();
}

void myLog::warn(const char *msg)
{
    ostringstream oss;
    oss<<msg<<"--"<<__FILE__<<": "<<__func__<<":"<<__LINE__;
    _root.warn(oss.str().c_str());
}

void myLog::error(const char *msg)
{
    ostringstream oss;
    oss<<msg<<"--"<<__FILE__<<": "<<__func__<<":"<<__LINE__;
    _root.error(oss.str().c_str());
}

void myLog::debug(const char *msg)
{
    ostringstream oss;
    oss<<msg<<"--"<<__FILE__<<": "<<__func__<<":"<<__LINE__;
    _root.debug(oss.str().c_str());
}

void myLog::info(const char *msg)
{
    ostringstream oss;
    oss<<msg<<"--"<<__FILE__<<": "<<__func__<<":"<<__LINE__;
    _root.info(oss.str().c_str());
}

void myLog::fatal(const char *msg)
{
    ostringstream oss;
    oss<<msg<<"--"<<__FILE__<<": "<<__func__<<":"<<__LINE__;
    _root.fatal(oss.str().c_str());
}

void myLog::alert(const char *msg)
{
    ostringstream oss;
    oss<<msg<<"--"<<__FILE__<<": "<<__func__<<":"<<__LINE__;
    _root.alert(oss.str().c_str());
}

#if 0 
string getAppend(const char *msg)
{
    ostringstream oss;
    oss<<msg<<"--"<<__FILE__<<": "<<__func__<<":"<<__LINE__;
    return oss.str();

}
#endif


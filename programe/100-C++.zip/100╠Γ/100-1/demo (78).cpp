#include <iostream>
#include <string>

using namespace std;

void fun(string s,char *t)
{
	for (int i = 0; i != s.length();i++)
	{
		if (s[i]%2==1)
		{
			*t = s[i];
			t++;
		}
	}
}

int main()
{
	cout << "100-1-078" << endl;
	string str;
	char *t = new char;
	cout << "input a string:";
	cin >> str;
	fun(str,t);

	while (*t)
	{
		cout << *t;
		t++;
	}

	cin.get();
	cin.get();
	return 0;
}

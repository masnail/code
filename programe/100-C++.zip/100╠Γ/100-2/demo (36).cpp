#include <iostream>
#include <string>

using namespace std;

void fun()
{
	bool ch = true;
	for (int i = 2; i != 100;i++)
	{
		ch = true;
		for (int j = 2; j != i / 2 + 1;j++)
		{
			if (i%j==0)
			{
				ch = false;
				break;
			}
		}
		if (ch)
		{
			cout << i << endl;
		}
	}
}

int main()
{
	cout << "100-2-0" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}
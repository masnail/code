#include <iostream>
#include <string>

using namespace std;

typedef struct  
{
	string num;
	int score;
}student;

int fun(student s[],string num)
{
	int index = 0;
	while (s[index].num!="")
	{
		if (s[index].num==num)
		{
			return s[index].score;
		}
		index++;
	}
	return -1;
}

int main()
{
	cout << "100-1-067" << endl;
	student s[] = {
		{ "2011",98 },
		{ "2012",89 },
		{ "2013",90 },
		{ "2014",91 }
	};
	string num;
	cout << "input a num:";
	cin >> num;
	cout<<"score:"<<fun(s,num);
	cin.get();
	cin.get();
	return 0;
}
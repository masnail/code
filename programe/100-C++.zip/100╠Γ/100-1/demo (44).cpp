#include <iostream>
#include <string>

using namespace std;

void fun(string s1,string s2)
{
	int index = 0;
	int i = 0;
	while (i<s1.length())
	{
		if (s2[0]==s1[i]&&s2[1]==s1[i+1])
		{
			index++;
			i += 2;
		}
		else
		{
			i += 1;
		}
	}
	cout << index;
}

int main()
{
	cout << "100-1-044" << endl;
	string s1, s2;
	cout << "input big string:";
	cin >> s1;
	cout << "input two char:";
	cin	>> s2;
	fun(s1,s2);
	cin.get();
	cin.get();
	return 0;
}
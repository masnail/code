#include <iostream>
#include <string>

using namespace std;

typedef struct node
{
	int data;
	struct node *next;
}node,*linknode;

void fun(int n)
{
	int index = 1;
	linknode h = (linknode)malloc(sizeof(node)),p=h,q=h;
	h->data = 1;
	h->next = h;
	while (index!=n+1)
	{
		p = (linknode)malloc(sizeof(node));
		p->data = index;
		p->next = h;
		q->next = p;
		q = p;
		index++;
	}

	p = h->next;
	q = h;
	index = 2;
	while (q!=p)
	{
		if (index%3==0)
		{
			linknode pt = p;
			p = p->next;
			q->next = p;
			delete pt;
		}
		else
		{
			p = p->next;
			q = p;
		}
		index++;
	}
	cout << p->data << endl;
}

int main()
{
	cout << "100-2-069" << endl;
	cout << "input a count:";
	int n;
	cin >> n;
	fun(n);
	cin.get();
	cin.get();
	return 0;
}

#include <iostream>
#include <string>

using namespace std;

void fun()
{
	int i, num;
	num = 2;
	for (i = 0; i < 3; i++)
	{
		cout << "The num equal :" << num << endl;
		num++;
		{//Ƕ��static
			static int num = 1;
			cout << "The internal block num equal:" << num << endl;
			num++;
		}
	}
}

int main()
{
	cout << "100-2-043" << endl;
	fun();
	cin.get();
	cin.get();
	return 0;
}

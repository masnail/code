#include "Add_UI.h"

//ѧ��
void Add_Student_Show()
{
	Print_Welcome();

	int num,pindex; 
	char name[20], sex,age[4],birth[10],phone[11]; 
	float score5,score1,score2,score3,score4;

	printf("\tinput a student num:");
	scanf("%d", &num);

	if (Search_StudentNum(num) == 0)
	{
		printf("\tyes you can insert this student!\n");
		printf("\tinput student information\n");
		/*Print_Student_Head();*/
		printf("\t%d\t",num);
		printf("\tname:");
		scanf("%s", name);
		printf("\tsex(f/m):"); fflush(stdin); scanf("%c", &sex);
		fflush(stdin); printf("\tage:"); scanf("%s", age);
		printf("\tphone:"); scanf("%s", phone);
		printf("\tbirth:"); scanf("%s", birth);
		printf("\tscore1:"); scanf("%f", &score1);
		printf("\tscore2:"); scanf("%f", &score2);
		printf("\tscore3:"); scanf("%f", &score3);
		printf("\tscore4:"); scanf("%f", &score4);
		printf("\tcore5:"); scanf("%f", &score5);

		Add_Student_Info(num, name, sex, age, phone, birth, score1, score2, score3, score4, score5);
	}else{
		printf("\tthe student is exist!\n");
	}
	Search_Student_All();
}


//�û�
void Add_User_Show()
{
	Print_Welcome();

	char name[20], password[20],power;

	printf("\tinput user name:");
	scanf("%s", name);
	if (Search_UserName(name)==0)
	{
		printf("\tYES,you can insert a user!\n");
		memcpy(password, Get_Password(), 20);
		fflush(stdin);
		printf("\n\tinput user power(4/7):");
		scanf("%c", &power);
		Add_User_Info(name, password, power);
	}else{
		printf("\tNO,user is exist!\n");
	}	
	printf("\t");
	system("pause");
	Print_Welcome();
	Search_User_All();
}
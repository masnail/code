#include "head.h"

int main(int argc, char* argv[])
{
	char readName[] = "The_Holy_Bible.txt", writeName[] = "The_Holy_Bible_Res.txt";
	wdlist head = (wdlist)malloc(sizeof(wd));
	memset(head, 0, sizeof(wd));

	File_read(readName, &head);

	printf("col is :%d\n", Get_col_count(head));
	printf("chara is :%d\n", Get_chara_count());
	printf("word is :%d\n", Get_word_count(head));

	/sort_word(&head);
	/list_word(head);

	printf("Scuess!\n");
	getchar();
	getchar();
	return 0;
}
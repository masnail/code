#include <iostream>
#include <string>

using namespace std;

bool Primer(int n)
{
	bool bo = true;
	for (int i = 2; i < n / 2 + 1; i++)
	{
		if (n%i == 0)
		{
			return false;
		}

	}
	return true;
}

int fun(int n)
{
	if (!Primer(n))
	{
		int index = 2,sum=1;
		while (index != 1)
		{
			if (n%index == 0 && Primer(index))
			{
				sum += index;
				if (n / index == 1)
				{
					index = 1;
				}
				else
				{
					n /= index;
					index = 2;
				}

			}
			else
			{
				index++;
			}
		}
		return sum;
	}
	else//primer
	{
		return 1 + n;;
	}
}

int main()
{
	cout << "100-2-019" << endl;
	cout << "wan shu:";
	for (int i = 1; i != 1000; i++)
	{
		if (fun(i)==i)
		{
			cout << i << endl;
		}
	}
	cin.get();
	cin.get();
	return 0;
}

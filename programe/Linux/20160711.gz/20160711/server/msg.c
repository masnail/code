/*************************************************************************
 Author:0054
 Created Time: 2016年07月11日 星期一 18时45分38秒
 File Name: msg.c
 Description: 
 ************************************************************************/
#include "../include/head.h"

int send_msg(int fdw,int fd)
{
	struct msghdr msg;
	struct cmsghdr *cmsg;
	struct iovec *iov=(struct iovec*)calloc(1,sizeof(struct iovec));
	char buff[5]="hello";

	memset(&msg,0,sizeof(msg));
	iov->iov_base=buff;
	iov->iov_len=5;
	msg.msg_iov=iov;
	msg.msg_iovlen=1;
	
	int len=CMSG_LEN(4);
	cmsg=(struct cmsghdr*)calloc(1,len);
	cmsg->cmsg_len=len;
	cmsg->cmsg_level=SOL_SOCKET;
	cmsg->cmsg_type=SCM_RIGHTS;
	*(int*)CMSG_DATA(cmsg)=fd;

	msg.msg_control=cmsg;
	msg.msg_controllen=len;
	int ret = sendmsg(fdw,&msg,0);
	if(-1 == ret)
	{
		perror("sendmsg");
		return -1;
	}
	return 0;
}

int recv_msg(int fdr,int *fd)
{
	struct msghdr msg;
	struct cmsghdr *cmsg;
	struct iovec *iov=(struct iovec*)calloc(1,sizeof(struct iovec));
	char buff[5]={0};

	memset(&msg,0,sizeof(msg));
	iov->iov_base=buff;
	iov->iov_len=5;
	
	int len=CMSG_LEN(4);
	cmsg=(struct cmsghdr*)calloc(1,len);
	cmsg->cmsg_len=len;
	cmsg->cmsg_level=SOL_SOCKET;
	cmsg->cmsg_type=SCM_RIGHTS;

	msg.msg_iov=iov;
	msg.msg_iovlen=1;
	msg.msg_control=cmsg;
	msg.msg_controllen=len;

	int ret = recvmsg(fdr,&msg,0);
	if(-1 == ret)
	{
		perror("recvmsg");
		return -1;
	}
	*fd=*(int*)CMSG_DATA(cmsg);//接受的时候再次赋值
	return 0;
}

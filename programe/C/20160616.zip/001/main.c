#include "head.h"

int main(int argc,char* argv[])
{
	char readName[] = "The_Holy_Bible.txt", writeName[] = "The_Holy_Bible_Res.txt";

	File_read(readName,writeName);

	printf("Scuess!\n");
	getchar();
	getchar();
	return 0;
}
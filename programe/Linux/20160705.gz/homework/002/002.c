#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

//clean funuc
void *func_clean(void *p)
{
	printf("coming clean func\n");
	free((char*)p);
}

void* func_pth(void *p)
{
	char *pch;
	pthread_cleanup_push(func_clean,(void*)pch);
	pch=(char*)malloc(50*sizeof(char));
	char buff[512];
	memset(buff,0,sizeof(buff));
	read(0,buff,sizeof(buff));
	puts(buff);

	pthread_exit(NULL);
	pthread_cleanup_pop(1);
}

int main()
{
	pthread_t pth;
	pthread_create(&pth,NULL,func_pth,NULL);
	printf("clean func\n");

	pthread_join(pth,NULL);
	return 0;
}


